from __future__ import annotations

from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


OUT = Path(r"E:\undergraduate\Web\PSM\docs\Public_Sentiment_Mirror_项目原理与复现说明.docx")

BLUE = RGBColor(28, 85, 130)
DEEP = RGBColor(15, 35, 55)
MUTED = RGBColor(88, 105, 125)
CYAN = RGBColor(22, 151, 172)
LIGHT_BLUE = "EAF5FA"
LIGHT_GRAY = "F5F7FA"
PALE_GOLD = "FFF6D8"
WHITE = "FFFFFF"
BORDER = "CBD7E5"


def set_run_font(run, size=None, bold=None, color=None, italic=None, font="Microsoft YaHei"):
    run.font.name = font
    run._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    run._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    run._element.rPr.rFonts.set(qn("w:eastAsia"), font)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if color is not None:
        run.font.color.rgb = color


def set_para_format(paragraph, before=0, after=6, line=1.25, align=None):
    paragraph.paragraph_format.space_before = Pt(before)
    paragraph.paragraph_format.space_after = Pt(after)
    paragraph.paragraph_format.line_spacing = line
    if align is not None:
        paragraph.alignment = align


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shading = tc_pr.find(qn("w:shd"))
    if shading is None:
        shading = OxmlElement("w:shd")
        tc_pr.append(shading)
    shading.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for m, v in [("top", top), ("start", start), ("bottom", bottom), ("end", end)]:
        node = tc_mar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(v))
        node.set(qn("w:type"), "dxa")


def set_cell_border(cell, color=BORDER, size="6"):
    tc_pr = cell._tc.get_or_add_tcPr()
    borders = tc_pr.first_child_found_in("w:tcBorders")
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tc_pr.append(borders)
    for edge in ("top", "left", "bottom", "right"):
        tag = f"w:{edge}"
        node = borders.find(qn(tag))
        if node is None:
            node = OxmlElement(tag)
            borders.append(node)
        node.set(qn("w:val"), "single")
        node.set(qn("w:sz"), size)
        node.set(qn("w:space"), "0")
        node.set(qn("w:color"), color)


def set_table_width(table, widths):
    table.autofit = False
    for row in table.rows:
        for idx, width in enumerate(widths):
            if idx >= len(row.cells):
                continue
            row.cells[idx].width = Inches(width)
            tc_pr = row.cells[idx]._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(int(width * 1440)))
            tc_w.set(qn("w:type"), "dxa")
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(int(sum(widths) * 1440)))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), "120")
    tbl_ind.set(qn("w:type"), "dxa")


def style_document(doc):
    section = doc.sections[0]
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Microsoft YaHei"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25

    for name, size, color, before, after in [
        ("Title", 24, DEEP, 0, 10),
        ("Subtitle", 12.5, MUTED, 0, 12),
        ("Heading 1", 16, BLUE, 18, 10),
        ("Heading 2", 13, BLUE, 14, 7),
        ("Heading 3", 12, DEEP, 10, 5),
    ]:
        style = styles[name]
        style.font.name = "Microsoft YaHei"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
        style.font.size = Pt(size)
        style.font.color.rgb = color
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.line_spacing = 1.25

    header = section.header.paragraphs[0]
    header.text = ""
    run = header.add_run("Public Sentiment Mirror | 项目原理与复现说明")
    set_run_font(run, size=9.5, color=MUTED)
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT

    footer = section.footer.paragraphs[0]
    footer.text = ""
    run = footer.add_run("用于课程讨论与项目答辩准备")
    set_run_font(run, size=9, color=MUTED)
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER


def add_paragraph(doc, text="", size=11, bold=False, color=None, italic=False, after=6, before=0, align=None):
    p = doc.add_paragraph()
    set_para_format(p, before=before, after=after, line=1.25, align=align)
    if text:
        run = p.add_run(text)
        set_run_font(run, size=size, bold=bold, color=color, italic=italic)
    return p


def add_heading(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    for run in p.runs:
        set_run_font(run, bold=True, color=BLUE if level <= 2 else DEEP)
    return p


def add_bullet(doc, text, level=0):
    p = doc.add_paragraph(style="List Bullet" if level == 0 else "List Bullet 2")
    set_para_format(p, after=4, line=1.25)
    run = p.add_run(text)
    set_run_font(run, size=10.7)
    return p


def add_number(doc, text):
    p = doc.add_paragraph(style="List Number")
    set_para_format(p, after=4, line=1.25)
    run = p.add_run(text)
    set_run_font(run, size=10.7)
    return p


def add_callout(doc, title, body, fill=LIGHT_BLUE, accent=CYAN):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    set_table_width(table, [6.35])
    cell = table.cell(0, 0)
    set_cell_shading(cell, fill)
    set_cell_border(cell, color="D6E6EE")
    set_cell_margins(cell, top=140, bottom=140, start=180, end=180)
    p = cell.paragraphs[0]
    set_para_format(p, after=4, line=1.2)
    r = p.add_run(title)
    set_run_font(r, size=11, bold=True, color=accent)
    p2 = cell.add_paragraph()
    set_para_format(p2, after=0, line=1.25)
    r2 = p2.add_run(body)
    set_run_font(r2, size=10.5, color=DEEP)
    add_paragraph(doc, after=8)


def add_table(doc, headers, rows, widths, header_fill=LIGHT_GRAY):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    set_table_width(table, widths)
    hdr = table.rows[0].cells
    for i, text in enumerate(headers):
        cell = hdr[i]
        set_cell_shading(cell, header_fill)
        set_cell_border(cell)
        set_cell_margins(cell)
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        p = cell.paragraphs[0]
        set_para_format(p, after=0, line=1.15)
        r = p.add_run(text)
        set_run_font(r, size=9.8, bold=True, color=DEEP)
    for row in rows:
        cells = table.add_row().cells
        for i, text in enumerate(row):
            cell = cells[i]
            set_cell_shading(cell, WHITE)
            set_cell_border(cell)
            set_cell_margins(cell)
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            p = cell.paragraphs[0]
            set_para_format(p, after=0, line=1.18)
            r = p.add_run(str(text))
            set_run_font(r, size=9.6, color=DEEP)
    add_paragraph(doc, after=8)
    return table


def add_process_band(doc):
    rows = [
        ["1 数据进入", "CSV / Excel / TXT / 粘贴文本 / 示例数据"],
        ["2 字段识别", "识别评论、时间、评分、点赞、平台或分析对象，并让用户确认映射"],
        ["3 清洗与标准化", "去空值、去重复、去噪、统一时间与数值字段"],
        ["4 NLP 分析", "关键词、情感、主题聚类、热度趋势、风险判断"],
        ["5 可视化工作台", "按步骤展示概览、清洗、关键词、情感、主题、趋势、仪表盘"],
        ["6 报告生成", "自动生成 Markdown / Word 报告，并把图表嵌入对应章节"],
    ]
    add_table(doc, ["流程", "作用"], rows, [1.55, 4.8], header_fill=LIGHT_BLUE)


def add_cover(doc):
    add_paragraph(doc, "课程项目说明 / 答辩复现材料", size=10.5, bold=True, color=CYAN, after=10)
    title = doc.add_paragraph()
    set_para_format(title, after=6, line=1.15)
    r = title.add_run("Public Sentiment Mirror")
    set_run_font(r, size=25, bold=True, color=DEEP)
    subtitle = doc.add_paragraph()
    set_para_format(subtitle, after=18, line=1.25)
    r = subtitle.add_run("网络舆情检索与智能分析平台：项目原理、落地流程与演示说明")
    set_run_font(r, size=14, color=MUTED)
    add_table(
        doc,
        ["项目项", "说明"],
        [
            ["项目定位", "面向微博、小红书、新闻评论、电影评论等文本数据的临时分析工作台"],
            ["当前版本", "无需登录、无需历史项目管理，重点跑通上传、分析、可视化和报告下载"],
            ["讨论用途", "帮助老师快速理解网页不是单纯展示页，而是一套可复现的数据分析流程"],
            ["整理日期", date.today().strftime("%Y年%m月%d日")],
        ],
        [1.45, 4.9],
        header_fill=LIGHT_BLUE,
    )
    add_callout(
        doc,
        "一句话介绍",
        "这个项目把非结构化评论数据转化为可阅读的舆情分析结果：用户上传数据后，系统自动识别字段、清洗文本、调用 NLP 分析模块，最后用可视化工作台和 Word 报告呈现结论。",
        fill=PALE_GOLD,
        accent=RGBColor(135, 92, 0),
    )


def build_document():
    doc = Document()
    style_document(doc)
    add_cover(doc)

    add_heading(doc, "1. 项目目标：为什么要做这个网页", 1)
    add_paragraph(
        doc,
        "Public Sentiment Mirror 的目标不是做一个普通后台页面，而是做一个“从原始文本到分析报告”的完整舆情分析工作流。它把用户原本需要在 Excel、Python、可视化工具和 Word 之间反复切换的过程，压缩到一个网页中完成。",
    )
    add_bullet(doc, "对课程作业而言，它体现了数据采集字段、批量清洗、文本挖掘、聚合统计、趋势分析和可视化表达。")
    add_bullet(doc, "对作品集而言，它展示的是一个完整产品：有用户入口、有数据处理、有模型服务、有交互式分析页面、有报告导出。")
    add_bullet(doc, "对未来扩展而言，它保留了后端模型服务、API 路由和报告生成结构，可以继续接入数据库、登录系统和更强的中文 NLP 模型。")

    add_heading(doc, "2. 当前版本的边界：做什么，不做什么", 1)
    add_table(
        doc,
        ["范围", "当前实现", "为什么这样设计"],
        [
            ["已实现", "数据上传、字段映射、清洗、关键词、情感、主题聚类、热度趋势、时间轴、仪表盘、报告下载", "先把闭环跑通，保证老师现场能复现"],
            ["暂不实现", "用户登录、注册、个人中心、管理员后台、历史项目长期保存", "这些属于平台化功能，会增加复杂度，但不是当前课程作业的核心"],
            ["数据保存", "当前主要是临时任务和本地下载报告", "减少隐私和部署负担，适合课堂展示和作品集演示"],
            ["模型策略", "Python NLP 服务优先，模型失败时自动降级为基础分析", "保证可运行性优先，不因为大型模型加载失败导致网页崩溃"],
        ],
        [1.15, 2.4, 2.8],
        header_fill=LIGHT_BLUE,
    )

    add_heading(doc, "3. 明天复现的演示路线", 1)
    add_callout(
        doc,
        "建议演示节奏",
        "先用一句话说明项目定位，然后按“上传数据 - 确认字段 - 开始分析 - 查看可视化 - 生成报告”的顺序演示。不要一开始讲太多代码，先让老师看到工作流闭环，再解释背后的技术。",
    )
    add_table(
        doc,
        ["步骤", "页面操作", "你可以这样解释"],
        [
            ["1", "打开首页，点击“开始分析”", "首页是入口，不是登录后台；当前版本面向一次性分析任务。"],
            ["2", "上传 DMSC.csv 或其他评论数据", "系统支持 CSV、TXT、Excel，也支持粘贴文本或示例数据。"],
            ["3", "进入字段映射确认", "系统会识别评论字段、时间字段、评分字段、点赞字段、分析对象字段；如果没有平台字段，不会强行显示平台来源。"],
            ["4", "点击开始分析", "前端把数据交给 Next.js API，API 再组织清洗、模型服务和基础算法。"],
            ["5", "逐步查看分析工作台", "每一步对应分析流程：概览、清洗、关键词、情感、主题、趋势时间轴、仪表盘、报告。"],
            ["6", "生成并下载报告", "报告不是空模板，会根据当前数据字段、图表和分析结果生成，并支持 Word / Markdown 下载。"],
        ],
        [0.55, 2.25, 3.55],
        header_fill=LIGHT_BLUE,
    )

    add_heading(doc, "4. 系统是怎么落地的：整体架构", 1)
    add_paragraph(
        doc,
        "项目采用“Next.js 前端 + Next.js API Routes + Python FastAPI NLP 服务”的结构。简单理解：网页负责交互和展示，Next.js API 负责协调任务，Python 服务负责较重的 NLP 模型分析。",
    )
    add_process_band(doc)
    add_table(
        doc,
        ["层级", "主要文件或目录", "职责"],
        [
            ["前端页面", "web/app/page.tsx、web/app/upload/page.tsx、web/app/analysis/[taskId]/page.tsx", "展示首页、上传中心、流程式分析工作台"],
            ["可视化组件", "web/components/Charts.tsx", "用 Recharts 绘制情感环图、趋势线、时间轴、雷达图、聚类散点等"],
            ["Next.js API", "web/app/api/*/route.ts", "接收上传、创建任务、返回关键词/情感/趋势/仪表盘、生成报告"],
            ["基础分析函数", "web/lib/analysis/*", "清洗、关键词、情感规则、趋势、时间轴、仪表盘、报告模板"],
            ["NLP 客户端", "web/lib/nlpClient.ts", "调用 Python FastAPI 模型服务；服务不可用时返回 null 并降级"],
            ["Python 模型服务", "nlp_service/main.py 和 nlp_service/services/*", "SBERT、K-Means、BERTopic、BERT 情感、风险判断"],
        ],
        [1.25, 2.45, 2.65],
        header_fill=LIGHT_BLUE,
    )

    add_heading(doc, "5. 数据进入系统后发生了什么", 1)
    add_paragraph(
        doc,
        "上传数据后，系统第一步不是直接分析，而是先做字段识别。这样网页才能适配不同类型数据：微博舆情数据可能有 platform 字段，电影评论数据可能只有 Movie_Name_CN、Star、Like、Comment 等字段。",
    )
    add_table(
        doc,
        ["数据字段", "系统含义", "在 DMSC.csv 中的例子"],
        [
            ["Comment", "评论文本字段，是关键词、情感和主题分析的主要来源", "用户对《复仇者联盟2》的评论"],
            ["Date", "评论发布时间，用于热度趋势和时间轴", "2015-04-10 至 2017-01-21"],
            ["Star", "评分字段，是电影评论情感判断的强信号", "4 星、5 星偏正面；3 星中性；1-2 星偏负面"],
            ["Like", "点赞数，用于热度、代表评论和高关注评论识别", "高点赞评论优先进入典型评论"],
            ["Movie_Name_CN", "分析对象 / 作品名称，不是平台", "复仇者联盟2"],
            ["Movie_Name_EN", "英文名称或别名", "Avengers Age of Ultron"],
            ["Username", "用户字段", "用于保留评论来源信息，但不作为分析核心"],
            ["ID / Number", "序号字段", "不参与文本分析"],
        ],
        [1.45, 2.55, 2.35],
        header_fill=LIGHT_BLUE,
    )
    add_callout(
        doc,
        "关键修正",
        "如果数据没有 platform 字段，系统会切换为“单对象评论分析模式”，展示分析对象、评分分布、点赞分布和评论时间线，而不是错误地把电影名当作平台来源。",
        fill=PALE_GOLD,
        accent=RGBColor(135, 92, 0),
    )

    add_heading(doc, "6. 分析流程：每一步对应什么算法", 1)
    add_table(
        doc,
        ["工作台步骤", "页面展示", "背后的处理逻辑"],
        [
            ["数据概览", "评论数量、时间范围、分析对象、评分、点赞、字段识别结果", "从上传数据中统计结构化字段，判断是平台舆情还是单对象评论"],
            ["数据清洗", "原始量、去重、空值、低质量文本、有效样本", "去除空文本、重复文本和明显噪声，保留有效评论"],
            ["关键词分析", "Top 关键词、词汇分类、解释文本", "分词、停用词过滤、词频统计；电影评论会偏向剧情、角色、特效、体验、争议焦点"],
            ["情感分析", "正面 / 中性 / 负面比例、典型评论、情绪趋势", "有评分时 Star 是强信号，评论文本和 BERT 情感模型是辅助信号"],
            ["主题聚类", "主题类别、语义聚类、代表评论、主题占比", "SBERT 生成语义向量，K-Means 聚类；BERTopic 用于主题建模，失败时启用可解释 fallback"],
            ["热度趋势", "评论量、点赞量、热度指数、移动平均", "按日期聚合，并用移动平均减少曲线跳动"],
            ["事件时间轴", "评论出现、讨论升温、首轮高峰、口碑分化、长尾评论", "根据数据类型生成节点；电影评论不用公共事件的“回应处理”叙事"],
            ["综合仪表盘", "传播热度、负面风险、综合状态、风险雷达", "把情感、热度、主题集中度、互动数据合并为可读判断"],
            ["分析报告", "完整文字报告与图表附件", "根据当前分析结果模板化生成，不依赖大模型，保证可控和可复现"],
        ],
        [1.2, 2.35, 2.8],
        header_fill=LIGHT_BLUE,
    )

    add_heading(doc, "7. NLP 模型服务：为什么单独放在 Python", 1)
    add_paragraph(
        doc,
        "大型 NLP 模型不适合直接放在浏览器或 React 页面里运行。因此项目把模型能力放进 Python FastAPI 服务中，Next.js 只负责把文本发过去并接收结构化 JSON。这样网页不会因为模型大、加载慢或依赖复杂而卡死。",
    )
    add_table(
        doc,
        ["模型 / 方法", "在项目中的作用", "失败时怎么保证可运行"],
        [
            ["SBERT", "把评论转成语义向量，让相似评论在向量空间中更接近", "加载失败时返回空向量，后续启用基础主题 fallback"],
            ["K-Means", "把语义相近的评论分成若干簇，例如剧情、角色、特效、口碑分化", "文本少时自动减少簇数，电影评论数据多时至少生成多个可解释主题"],
            ["BERTopic", "从聚类和关键词中生成主题名称与代表文本", "样本过少或模型失败时，回退到关键词 + K-Means 主题摘要"],
            ["BERT 情感模型", "识别评论文本的正面、中性、负面倾向", "模型不可用时使用评分字段和本地正负词典规则"],
            ["风险评分", "结合负面率、热度、主题集中度、负面主题规模得到风险等级", "基础算法可以独立计算传播热度、负面风险和综合状态"],
        ],
        [1.3, 2.55, 2.5],
        header_fill=LIGHT_BLUE,
    )
    add_callout(
        doc,
        "答辩时可强调",
        "模型不是写在网页组件里，而是通过 API 调用后端模型服务。前端只展示结果，模型层有缓存和 fallback，所以即使 Python 服务暂时没启动，网页仍然可以用基础分析模式完成演示。",
    )

    add_heading(doc, "8. 可视化和报告：为什么不是简单图表堆叠", 1)
    add_paragraph(
        doc,
        "页面中的图表服务于分析叙事，而不是为了放图而放图。比如电影评论数据中，重点不是平台来源，而是作品对象、评分分布、情感分布、主题分布、评论热度和长尾讨论。报告也会根据数据类型调整措辞，避免出现与电影评论无关的“学校、安全、回应处理”等内容。",
    )
    add_table(
        doc,
        ["可视化模块", "表达目的"],
        [
            ["情感环图", "展示正面、中性、负面比例，并标明名称和数值"],
            ["关键词排行", "说明用户讨论集中在哪些词汇和话题上"],
            ["主题分布", "把大量评论归纳成可解释的几个主题类别"],
            ["情绪立场象限图", "用横轴表达倾向、纵轴表达互动强度，让评论点位有解释意义"],
            ["热度趋势与时间轴", "把评论量、热度指数和关键阶段放在同一叙事中"],
            ["风险雷达", "把负面率、热度、点赞、评分或集中度等指标合并观察"],
        ],
        [1.8, 4.55],
        header_fill=LIGHT_BLUE,
    )

    add_heading(doc, "9. 部署方式：怎么从本地网页变成公网网站", 1)
    add_paragraph(
        doc,
        "本项目已经经历过本地开发、GitHub 上传、云服务器部署、域名解析、HTTPS 配置等步骤。对老师可以简单解释为：代码在 GitHub，服务运行在阿里云 ECS，Nginx 负责把公网请求转发到内部的 Next.js Web 服务，Certbot 负责 HTTPS 证书。",
    )
    add_table(
        doc,
        ["部署环节", "作用"],
        [
            ["GitHub 仓库", "保存项目代码，便于版本管理和云端拉取"],
            ["阿里云 ECS Ubuntu", "提供一台公网可访问的服务器来运行网页应用"],
            ["systemd 服务", "让应用在服务器后台持续运行，服务器重启后也能自动启动"],
            ["Nginx", "把 publicsentimentmirror.cyou 的访问请求转发到本机应用端口"],
            ["域名解析", "把 publicsentimentmirror.cyou 指向服务器公网 IP"],
            ["Certbot / Let's Encrypt", "配置 HTTPS，让网站可以通过 https:// 访问"],
        ],
        [1.75, 4.6],
        header_fill=LIGHT_BLUE,
    )

    add_heading(doc, "10. 技术栈速查：不用背代码，但要知道每块负责什么", 1)
    add_table(
        doc,
        ["技术", "通俗解释", "在本项目中的位置"],
        [
            ["Next.js", "React 的全栈网页框架，同时能写页面和后端接口", "web/app 页面与 web/app/api 接口"],
            ["React + TypeScript", "构建可交互页面，并让数据结构更稳定", "上传页、分析工作台、组件"],
            ["Tailwind CSS", "用类名快速写响应式视觉样式", "整体 UI 风格、卡片、布局、动画基础"],
            ["Recharts", "把分析结果画成可交互图表", "情感图、趋势图、雷达图、柱状图等"],
            ["Framer Motion", "提供页面动效和交互过渡", "首页和工作台视觉动感"],
            ["FastAPI", "Python 后端接口框架，适合承载模型服务", "nlp_service/main.py"],
            ["sentence-transformers", "加载 SBERT 语义向量模型", "embedding_service.py"],
            ["scikit-learn", "提供 K-Means 聚类等算法", "clustering_service.py"],
            ["transformers / torch", "加载 BERT 情感分类模型", "sentiment_service.py"],
            ["BERTopic", "主题建模工具", "topic_service.py"],
        ],
        [1.35, 2.35, 2.65],
        header_fill=LIGHT_BLUE,
    )

    add_heading(doc, "11. 你可以向老师强调的项目价值", 1)
    add_bullet(doc, "完整性：从数据上传到报告下载形成闭环，不只是单个算法实验。")
    add_bullet(doc, "适配性：能处理平台舆情，也能处理电影评论、商品评论等单对象评论数据。")
    add_bullet(doc, "可解释性：字段映射、清洗数量、关键词、情感、主题和风险判断都能在页面上看到。")
    add_bullet(doc, "工程性：前端展示、API 路由、Python 模型服务、云服务器部署彼此分层。")
    add_bullet(doc, "稳健性：模型失败时有 fallback，不牺牲可运行性。")
    add_bullet(doc, "可扩展性：后续可加入登录、数据库、历史任务、真正的异步队列和更强模型。")

    add_heading(doc, "12. 目前限制与后续计划", 1)
    add_table(
        doc,
        ["当前限制", "原因", "后续升级方向"],
        [
            ["大型模型启动慢", "SBERT、BERT、BERTopic 依赖较重，首次加载需要时间", "使用模型缓存、异步任务队列、GPU 或轻量模型"],
            ["当前没有长期数据库", "现阶段优先完成单次分析闭环", "接入 PostgreSQL / MongoDB 保存任务和报告"],
            ["主题命名仍需优化", "BERTopic 和 fallback 名称有时不够贴近语境", "引入更强中文主题摘要或大模型辅助命名"],
            ["分析结果不是研究终点", "规则、词典和模型仍需要在更多数据上评估", "建立测试数据集和人工标注样本进行效果验证"],
            ["公网部署需维护", "服务器、证书、域名和依赖都需要长期维护", "编写部署脚本和监控方案"],
        ],
        [1.45, 2.25, 2.65],
        header_fill=LIGHT_BLUE,
    )

    add_heading(doc, "13. 两分钟口头讲解稿", 1)
    add_callout(
        doc,
        "可直接照着说",
        "我的项目叫 Public Sentiment Mirror，是一个网络舆情检索与智能分析平台。它的核心不是单纯做一个展示网页，而是把原始评论数据转化成可读的分析结论。用户可以上传 CSV、Excel 或文本，系统先识别字段，比如评论内容、发布时间、评分、点赞数和分析对象；然后进行数据清洗、关键词提取、情感分析、主题聚类、热度趋势和事件时间轴分析；最后在网页工作台中逐步展示，并自动生成可下载的 Word 或 Markdown 报告。技术上，前端使用 Next.js、React 和 Recharts，模型能力放在 Python FastAPI 服务中，包含 SBERT、K-Means、BERTopic 和 BERT 情感分析。为了保证课堂展示时稳定，模型服务失败时系统会自动降级到基础规则算法，所以项目优先保证能启动、能返回结果、能展示、能生成报告。后续如果继续完善，可以加入登录、数据库、历史项目管理和更强的中文 NLP 模型。",
        fill=PALE_GOLD,
        accent=RGBColor(135, 92, 0),
    )

    add_heading(doc, "14. 复现命令备忘", 1)
    add_paragraph(doc, "本地复现时通常需要两个服务：Next.js 网页服务，以及可选的 Python NLP 模型服务。若 Python 服务没有启动，网页仍能以基础分析模式运行。")
    add_table(
        doc,
        ["用途", "命令", "说明"],
        [
            ["启动网页", "cd E:\\undergraduate\\Web\\PSM\\web\nnpm run dev", "打开 http://localhost:3000"],
            ["构建检查", "cd E:\\undergraduate\\Web\\PSM\\web\nnpm run build", "确认项目可生产构建"],
            ["启动 NLP 服务", "cd E:\\undergraduate\\Web\\PSM\\nlp_service\nuvicorn main:app --reload --port 8000", "提供 /analyze、/sentiment、/topics、/clusters 接口"],
            ["环境变量", "NLP_SERVICE_URL=http://localhost:8000", "Next.js API 调用 Python 服务的地址"],
        ],
        [1.1, 3.15, 2.1],
        header_fill=LIGHT_BLUE,
    )

    add_paragraph(doc, "")
    add_callout(
        doc,
        "最后提醒",
        "明天演示时，建议先使用示例数据确认流程，再上传 DMSC.csv 展示字段映射如何自动识别电影评论数据。若现场网络或模型服务不稳定，也可以说明系统会自动进入基础分析模式，核心工作流仍然可以完成。",
    )

    return doc


if __name__ == "__main__":
    doc = build_document()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUT)
    print(OUT)
