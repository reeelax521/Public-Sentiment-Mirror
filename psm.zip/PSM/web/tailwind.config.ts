import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        background: "#EEF6FF",
        foreground: "#13223A",
        muted: "#5B708B",
        panel: "rgba(255, 255, 255, 0.72)",
        cyan: "#13B6D1",
        indigo: "#6C7CFF",
        violet: "#A56EFF",
        danger: "#FF6B87",
        success: "#2EC98F",
        warning: "#F6B84B"
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(19,182,209,.22), 0 16px 44px rgba(19,182,209,.18)",
        violet: "0 0 0 1px rgba(165,110,255,.18), 0 22px 56px rgba(108,124,255,.14)"
      },
      backgroundImage: {
        "radial-grid": "linear-gradient(rgba(38,217,232,.08) 1px, transparent 1px), linear-gradient(90deg, rgba(38,217,232,.08) 1px, transparent 1px)",
        "panel-gradient": "linear-gradient(135deg, rgba(38,217,232,.14), rgba(89,100,242,.09) 48%, rgba(155,92,255,.13))"
      },
      keyframes: {
        scan: {
          "0%": { transform: "translateY(-110%)" },
          "100%": { transform: "translateY(120%)" }
        },
        pulseNode: {
          "0%, 100%": { boxShadow: "0 0 0 0 rgba(38,217,232,.45)" },
          "50%": { boxShadow: "0 0 0 10px rgba(38,217,232,0)" }
        },
        progressGlow: {
          "0%, 100%": { filter: "drop-shadow(0 0 8px rgba(38,217,232,.35))" },
          "50%": { filter: "drop-shadow(0 0 18px rgba(155,92,255,.42))" }
        },
        breathe: {
          "0%, 100%": { transform: "translateY(-10px)" },
          "50%": { transform: "translateY(10px)" }
        }
      },
      animation: {
        scan: "scan 2.8s linear infinite",
        "pulse-node": "pulseNode 2.4s ease-in-out infinite",
        "progress-glow": "progressGlow 2.2s ease-in-out infinite",
        breathe: "breathe 8s ease-in-out infinite"
      }
    }
  },
  plugins: [require("tailwindcss-animate")]
};

export default config;

