# Public Sentiment Mirror Web

Next.js product UI for Public Sentiment Mirror.

## Local Development

```bash
npm install
npm run dev
```

Open:

```text
http://localhost:3000
```

## Pages

- `/` Landing page
- `/upload` Upload center
- `/analysis/[taskId]` Workflow analysis workspace

## API Routes

- `POST /api/upload`
- `POST /api/demo-dataset`
- `POST /api/analysis`
- `GET /api/analysis/[taskId]`
- `GET /api/analysis/[taskId]/keywords`
- `GET /api/analysis/[taskId]/sentiment`
- `GET /api/analysis/[taskId]/trend`
- `GET /api/analysis/[taskId]/timeline`
- `GET /api/analysis/[taskId]/dashboard`
- `POST /api/reports/generate`
- `GET /api/reports/[reportId]/download`

## DeepSeek Report Enhancement

`POST /api/reports/generate` can call DeepSeek on the server side to add a smart judgment section to the generated report. Configure these variables in `.env.local`:

```bash
DEEPSEEK_API_KEY=your_api_key
DEEPSEEK_BASE_URL=https://api.deepseek.com
DEEPSEEK_MODEL=deepseek-v4-flash
DEEPSEEK_THINKING=disabled
DEEPSEEK_TIMEOUT_MS=45000
```

If `DEEPSEEK_API_KEY` is missing or the request fails, the route automatically returns the original local report.

## Advanced Model Layer

The first web version ships with explainable lightweight algorithms so the site can run reliably on a small ECS instance. The SBERT / BERTopic / BERT sentiment layer lives in `../nlp_service/`.

```text
Next.js UI and API gateway
-> Python analysis service
-> SBERT semantic embeddings
-> BERTopic topic modeling
-> BERT sentiment classifier
-> report generation
```

Run the model service and point Next.js to it:

```bash
cd ../nlp_service
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 127.0.0.1 --port 8000
```

Then start Next.js with:

```bash
NLP_SERVICE_URL=http://127.0.0.1:8000 npm run dev
```

If the model service is not running, the app automatically falls back to local lightweight analysis.
