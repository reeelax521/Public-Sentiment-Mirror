export function downloadTextFile(content: string, fileName: string, mime = "text/plain;charset=utf-8") {
  const blob = new Blob([content], { type: mime });
  triggerDownload(blob, fileName);
}

function triggerDownload(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function cloneSvgForExport(svg: SVGElement) {
  const cloned = svg.cloneNode(true) as SVGElement;
  const box = svg.getBoundingClientRect();
  const width = Number(svg.getAttribute("width")) || Math.ceil(box.width) || 900;
  const height = Number(svg.getAttribute("height")) || Math.ceil(box.height) || 420;

  cloned.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  cloned.setAttribute("xmlns:xlink", "http://www.w3.org/1999/xlink");
  cloned.setAttribute("width", String(width));
  cloned.setAttribute("height", String(height));
  cloned.setAttribute("viewBox", cloned.getAttribute("viewBox") || `0 0 ${width} ${height}`);

  const style = document.createElementNS("http://www.w3.org/2000/svg", "style");
  style.textContent = `
    text { font-family: "Microsoft YaHei", Arial, sans-serif; fill: #334155; }
    .recharts-cartesian-axis-tick-value, .recharts-legend-item-text { fill: #475569; }
  `;
  cloned.insertBefore(style, cloned.firstChild);

  const background = document.createElementNS("http://www.w3.org/2000/svg", "rect");
  background.setAttribute("x", "0");
  background.setAttribute("y", "0");
  background.setAttribute("width", "100%");
  background.setAttribute("height", "100%");
  background.setAttribute("fill", "#ffffff");
  cloned.insertBefore(background, cloned.firstChild);

  return { cloned, width, height };
}

async function svgToPngBytes(svg: SVGElement) {
  const { cloned, width, height } = cloneSvgForExport(svg);
  const serialized = new XMLSerializer().serializeToString(cloned);
  const svgBlob = new Blob([serialized], { type: "image/svg+xml;charset=utf-8" });
  const svgUrl = URL.createObjectURL(svgBlob);

  try {
    const image = new Image();
    image.decoding = "async";
    image.src = svgUrl;
    await image.decode();

    const scale = Math.min(2, window.devicePixelRatio || 1.5);
    const canvas = document.createElement("canvas");
    canvas.width = Math.ceil(width * scale);
    canvas.height = Math.ceil(height * scale);
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Canvas is not available");
    context.fillStyle = "#ffffff";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(image, 0, 0, canvas.width, canvas.height);

    const blob = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob((value) => value ? resolve(value) : reject(new Error("Chart image export failed")), "image/png", 0.96);
    });
    return {
      bytes: new Uint8Array(await blob.arrayBuffer()),
      width,
      height
    };
  } finally {
    URL.revokeObjectURL(svgUrl);
  }
}

async function collectChartImages() {
  const containers = Array.from(document.querySelectorAll<HTMLElement>(".report-chart"));
  const charts = await Promise.all(containers.map(async (container, index) => {
    const svg = container.querySelector("svg");
    if (!svg) return null;
    try {
      const image = await svgToPngBytes(svg);
      return {
        title: container.dataset.chartTitle || `图表 ${index + 1}`,
        ...image
      };
    } catch {
      return null;
    }
  }));

  return charts.filter(Boolean) as Array<{ title: string; bytes: Uint8Array; width: number; height: number }>;
}

function normalizeTitle(value: string) {
  return value.replace(/^报告图表：/, "").trim();
}

function shouldInsertChart(sectionTitle: string, chartTitle: string) {
  const section = sectionTitle.replace(/^\d+\.\s*/, "");
  const chart = normalizeTitle(chartTitle);
  const rules: Array<[string[], string[]]> = [
    [["数据说明", "数据来源", "样本说明", "字段识别", "平台"], ["平台来源", "评论对象", "字段识别"]],
    [["评分", "情感"], ["评分分布", "情感分布"]],
    [["关键词", "观影关注", "舆论表达", "公众关注", "词云"], ["关键词排行", "高频词云", "词云"]],
    [["主题", "聚类", "观点"], ["主题分布"]],
    [["风险", "高风险", "快速结论", "研判"], ["风险雷达"]],
    [["热度", "时间轴", "事件"], ["热度趋势", "事件转折"]]
  ];
  return rules.some(([sectionKeys, chartKeys]) =>
    sectionKeys.some((key) => section.includes(key)) && chartKeys.some((key) => chart.includes(key))
  );
}

function parseMarkdown(markdown: string) {
  const blocks: Array<
    | { type: "heading"; level: number; text: string }
    | { type: "paragraph"; text: string }
    | { type: "list"; text: string }
    | { type: "table"; rows: string[][] }
  > = [];
  const lines = markdown.split(/\r?\n/);

  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index].trim();
    if (!line) continue;

    if (line.startsWith("| ") && line.endsWith(" |")) {
      const rows: string[][] = [];
      while (index < lines.length && lines[index].trim().startsWith("| ") && lines[index].trim().endsWith(" |")) {
        const tableLine = lines[index].trim();
        const cells = tableLine.slice(2, -2).split(" | ").map((cell) => cell.trim());
        if (!cells.every((cell) => /^-+$/.test(cell))) rows.push(cells);
        index += 1;
      }
      index -= 1;
      if (rows.length) blocks.push({ type: "table", rows });
      continue;
    }

    if (line.startsWith("# ")) blocks.push({ type: "heading", level: 1, text: line.slice(2).trim() });
    else if (line.startsWith("## ")) blocks.push({ type: "heading", level: 2, text: line.slice(3).trim() });
    else if (line.startsWith("### ")) blocks.push({ type: "heading", level: 3, text: line.slice(4).trim() });
    else if (line.startsWith("- ")) blocks.push({ type: "list", text: line.slice(2).trim() });
    else blocks.push({ type: "paragraph", text: line });
  }

  return blocks;
}

function fitImage(width: number, height: number) {
  const maxWidth = 620;
  const ratio = width > maxWidth ? maxWidth / width : 1;
  return {
    width: Math.round(width * ratio),
    height: Math.round(height * ratio)
  };
}

async function createDocx(markdown: string, charts: Awaited<ReturnType<typeof collectChartImages>>) {
  const {
    AlignmentType,
    BorderStyle,
    Document,
    HeadingLevel,
    ImageRun,
    Packer,
    Paragraph,
    Table,
    TableCell,
    TableRow,
    TextRun,
    WidthType
  } = await import("docx");

  const usedCharts = new Set<number>();
  const children: any[] = [];
  let currentSection = "";

  const addChart = (chart: (typeof charts)[number], index: number) => {
    const size = fitImage(chart.width, chart.height);
    children.push(
      new Paragraph({
        spacing: { before: 260, after: 90 },
        children: [new TextRun({ text: normalizeTitle(chart.title), bold: true, color: "145C7A" })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 220 },
        children: [
          new ImageRun({
            data: chart.bytes,
            transformation: size,
            type: "png"
          })
        ]
      })
    );
    usedCharts.add(index);
  };

  for (const block of parseMarkdown(markdown)) {
    if (block.type === "heading") {
      currentSection = block.text;
      children.push(new Paragraph({
        text: block.text,
        heading: block.level === 1 ? HeadingLevel.TITLE : block.level === 2 ? HeadingLevel.HEADING_2 : HeadingLevel.HEADING_3,
        spacing: { before: block.level === 1 ? 0 : 360, after: 160 }
      }));
      charts.forEach((chart, index) => {
        if (!usedCharts.has(index) && shouldInsertChart(currentSection, chart.title) && currentSection.includes("快速结论") && chart.title.includes("风险雷达")) {
          addChart(chart, index);
        }
      });
      continue;
    }

    if (block.type === "paragraph") {
      children.push(new Paragraph({
        children: [new TextRun({ text: block.text, size: 22 })],
        spacing: { after: 120 }
      }));
    } else if (block.type === "list") {
      children.push(new Paragraph({
        bullet: { level: 0 },
        children: [new TextRun({ text: block.text, size: 22 })],
        spacing: { after: 80 }
      }));
    } else if (block.type === "table") {
      children.push(new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: block.rows.map((row, rowIndex) => new TableRow({
          children: row.map((cell) => new TableCell({
            shading: rowIndex === 0 ? { fill: "EDF7FB" } : undefined,
            borders: {
              top: { style: BorderStyle.SINGLE, size: 1, color: "CFD9E8" },
              bottom: { style: BorderStyle.SINGLE, size: 1, color: "CFD9E8" },
              left: { style: BorderStyle.SINGLE, size: 1, color: "CFD9E8" },
              right: { style: BorderStyle.SINGLE, size: 1, color: "CFD9E8" }
            },
            children: [new Paragraph({ children: [new TextRun({ text: cell, bold: rowIndex === 0, size: 20 })] })]
          }))
        }))
      }));
      children.push(new Paragraph({ text: "", spacing: { after: 130 } }));
    }

    charts.forEach((chart, index) => {
      if (!usedCharts.has(index) && shouldInsertChart(currentSection, chart.title)) addChart(chart, index);
    });
  }

  charts.forEach((chart, index) => {
    if (!usedCharts.has(index)) addChart(chart, index);
  });

  const document = new Document({
    creator: "Public Sentiment Mirror",
    description: "Network opinion analysis report",
    sections: [{
      properties: {
        page: {
          margin: { top: 900, right: 900, bottom: 900, left: 900 }
        }
      },
      children
    }]
  });

  return Packer.toBlob(document);
}

export async function downloadWordReport(markdown: string, fileName: string) {
  const docxName = fileName.endsWith(".docx") ? fileName : fileName.replace(/\.doc$/i, ".docx");
  try {
    const charts = await collectChartImages();
    const blob = await createDocx(markdown, charts);
    triggerDownload(blob, docxName);
  } catch (error) {
    console.warn("Word report export with charts failed, retrying without charts.", error);
    try {
      const blob = await createDocx(markdown, []);
      triggerDownload(blob, docxName);
    } catch (fallbackError) {
      console.warn("Word report export failed, downloading Markdown instead.", fallbackError);
      downloadTextFile(markdown, docxName.replace(/\.docx$/i, ".md"), "text/markdown;charset=utf-8");
    }
  }
}
