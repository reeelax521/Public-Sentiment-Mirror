import type { ClusterItem, NlpAnalysisResult, OpinionRecord, RiskLevel, SentimentLabel, TopicItem } from "@/lib/types";

export interface NlpAnalyzePayload {
  taskId: string;
  texts: string[];
  metadata?: Array<{
    platform?: string;
    createdAt?: string;
    likeCount?: number;
    repostCount?: number;
    commentCount?: number;
    objectName?: string;
    rating?: number | null;
    extra?: Record<string, unknown>;
  }>;
}

interface NlpResponse {
  taskId: string;
  keywords?: Array<{ word: string; count: number }>;
  sentiment?: {
    distribution?: Record<SentimentLabel, number>;
    negativeRate?: number;
    items?: Array<{ text: string; label: SentimentLabel; score: number }>;
    typicalComments?: Record<SentimentLabel, string[]>;
  };
  clusters?: ClusterItem[];
  topics?: TopicItem[];
  risk?: { riskLevel: RiskLevel; riskScore: number; reason: string };
  mode?: "nlp" | "fallback";
  warnings?: string[];
}

export interface NlpSentimentResponse {
  distribution?: Record<SentimentLabel, number>;
  negativeRate?: number;
  items?: Array<{ text: string; label: SentimentLabel; score: number }>;
  typicalComments?: Record<SentimentLabel, string[]>;
  mode?: "bert" | "snownlp" | "fallback" | "lexicon";
}

const baseUrl = (process.env.NLP_SERVICE_URL || "http://localhost:8000").replace(/\/$/, "");
const timeoutMs = Number(process.env.NLP_SERVICE_TIMEOUT_MS || 25000);
const sentimentTimeoutMs = Number(process.env.NLP_SENTIMENT_TIMEOUT_MS || 600000);

async function postJson<T>(path: string, payload: NlpAnalyzePayload, requestTimeoutMs = timeoutMs): Promise<T | null> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), requestTimeoutMs);
  try {
    const response = await fetch(`${baseUrl}${path}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    if (!response.ok) return null;
    return await response.json() as T;
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

export async function analyzeTexts(payload: NlpAnalyzePayload): Promise<NlpResponse | null> {
  return postJson<NlpResponse>("/analyze", payload);
}

export async function getSentiment(payload: NlpAnalyzePayload) {
  return postJson<NlpSentimentResponse>("/sentiment", payload, sentimentTimeoutMs);
}

export async function getTopics(payload: NlpAnalyzePayload) {
  return postJson("/topics", payload);
}

export async function getClusters(payload: NlpAnalyzePayload) {
  return postJson("/clusters", payload);
}

export function recordsToNlpPayload(taskId: string, records: OpinionRecord[]): NlpAnalyzePayload {
  return {
    taskId,
    texts: records.map((record) => record.content),
    metadata: records.map((record) => ({
      platform: record.platform,
      createdAt: record.publishTime,
      likeCount: record.likeCount,
      repostCount: record.repostCount,
      commentCount: record.commentCount,
      objectName: record.objectName,
      rating: record.rating,
      extra: {
        userId: record.userId,
        username: record.username,
        area: record.area,
        sourceUrl: record.sourceUrl,
        ...record.metadata
      }
    }))
  };
}

export function emptyNlpResult(riskLevel: RiskLevel, reason: string): NlpAnalysisResult {
  return {
    topics: [],
    clusters: [],
    risk: { riskLevel, riskScore: 0, reason },
    mode: "basic",
    warnings: ["Python NLP 服务不可用，当前使用基础分析模式。"]
  };
}
