import type { DataProfile, DatasetKind, FieldMapping, OpinionRecord } from "@/lib/types";

export type RawRow = Record<string, unknown>;

const MAX_RECORDS = 5000;
export const MAX_TEXT_BYTES = 12 * 1024 * 1024;

const contentKeys = [
  "弹幕内容", "评论内容", "新闻评论", "微博内容", "小红书内容", "帖子内容", "用户反馈",
  "comment", "comments", "content", "text", "body", "message", "description", "desc",
  "评论", "文本", "文本内容", "内容", "正文", "留言", "观点", "弹幕", "反馈"
];

const platformKeys = [
  "platform", "source_platform", "media_platform", "sourceplatform", "site", "app",
  "平台", "来源平台", "发布平台", "站点", "媒体"
];

const objectKeys = [
  "event_name", "eventname", "source_title", "sourcetitle",
  "article_title", "articletitle", "news_title", "newstitle", "movie_name_cn", "movienamecn",
  "name_cn", "movie_cn", "title_cn", "object_name", "objectname", "target", "subject", "title",
  "事件名称", "来源标题", "新闻标题", "文章标题", "视频标题", "电影名称", "影片", "片名", "中文名", "作品名称", "分析对象", "对象", "标题", "话题对象"
];

const objectAliasKeys = [
  "movie_name_en", "movienameen", "name_en", "movie_en", "title_en", "object_alias", "alias",
  "英文名", "英文名称", "对象别名", "别名"
];

const timeKeys = [
  "publish_time", "publishtime", "created_at", "createdat", "comment_time", "commenttime", "send_time", "sendtime",
  "date", "time", "发布时间", "发表时间", "评论时间", "创建时间", "发送时间", "发布时间IP", "日期", "时间"
];

const timeExcludeKeys = ["视频内时间", "视频时间", "时长", "duration", "timestamp", "时间戳", "发送时间戳"];
const collectedAtKeys = ["crawl_date", "crawldate", "collect_time", "collected_at", "采集时间", "抓取时间", "爬取时间"];
const ratingKeys = ["star", "rating", "score", "评分", "星级", "打分"];
const ratingExcludeKeys = ["heat", "hot", "热度", "情感分", "sentiment"];
const likeKeys = ["like_count", "likecount", "likes", "like", "agree", "up", "点赞数量", "点赞数", "点赞", "赞", "有用数"];
const userKeys = ["username", "user_name", "nickname", "nick", "author", "user", "用户名", "用户名称", "昵称", "作者", "评论人", "博主"];
const userIdKeys = ["user_id", "userid", "uid", "用户id", "用户ID", "用户编号"];
const areaKeys = ["area", "location", "province", "city", "地区", "地域", "位置", "省份", "城市", "发布时间IP", "IP属地"];
const sourceUrlKeys = ["source_url", "sourceurl", "url", "link", "链接", "原文链接", "来源链接", "页面网址", "帖子链接"];
const commentCountKeys = ["reply_count", "replycount", "comment_count", "comments_count", "评论数", "回复数", "互动评论"];
const repostKeys = ["repost_count", "repostcount", "share_count", "sharecount", "repost", "share", "转发数", "转发", "分享数", "分享"];
const idKeys = ["id", "number", "index", "序号", "编号", "comment_id", "commentid", "弹幕id", "弹幕ID"];
const missingTokens = new Set(["", "null", "none", "nil", "nan", "na", "n/a", "-", "--", "无", "暂无", "未知", "未提供", "空"]);

const nonCoreBiliFields = [
  "序号", "视频内时间_秒", "弹幕模式", "字号", "颜色值", "发送时间戳", "弹幕池", "用户哈希", "弹幕ID"
];

function normalizeKey(value: string) {
  return value
    .replace(/^\uFEFF/, "")
    .toLowerCase()
    .replace(/[\s_\-./\\()[\]（）【】:：]/g, "");
}

function uniqueKeys(rows: RawRow[]) {
  return Array.from(new Set(rows.flatMap((row) => Object.keys(row).map((key) => key.replace(/^\uFEFF/, "")))));
}

function normalizedRows(rows: RawRow[]) {
  return rows.map((row) => {
    const cleaned: RawRow = {};
    Object.entries(row).forEach(([key, value]) => {
      cleaned[key.replace(/^\uFEFF/, "")] = value;
    });
    return cleaned;
  });
}

function keyIncludes(key: string, candidates: string[]) {
  const normalized = normalizeKey(key);
  return candidates.some((candidate) => normalized.includes(normalizeKey(candidate)));
}

function findKeyFromKeys(keys: string[], candidates: string[], exclude: string[] = []) {
  const normalizedKeys = keys.map((key) => ({ key, normalized: normalizeKey(key) }));
  const normalizedCandidates = candidates.map((candidate) => normalizeKey(candidate)).filter(Boolean);
  const blocked = exclude.map((candidate) => normalizeKey(candidate));
  const isBlocked = (normalized: string) => blocked.some((candidate) => normalized.includes(candidate));

  for (const candidate of normalizedCandidates) {
    const exact = normalizedKeys.find((item) => item.normalized === candidate && !isBlocked(item.normalized));
    if (exact) return exact.key;
  }

  for (const candidate of normalizedCandidates) {
    if (candidate.length < 2) continue;
    const partial = normalizedKeys.find((item) => item.normalized.includes(candidate) && !isBlocked(item.normalized));
    if (partial) return partial.key;
  }
}

function inferContentKey(rows: RawRow[], profile: DataProfile) {
  const keys = uniqueKeys(rows);
  if (profile === "danmaku") {
    const exactDanmaku = findKeyFromKeys(keys, ["弹幕内容"]);
    if (exactDanmaku) return exactDanmaku;
  }

  const explicit = findKeyFromKeys(keys, contentKeys, ["弹幕模式", "评论数", "回复数"]);
  if (explicit) return explicit;

  return keys
    .filter((key) => !findKeyFromKeys([key], [
      ...platformKeys, ...objectKeys, ...objectAliasKeys, ...timeKeys, ...timeExcludeKeys,
      ...ratingKeys, ...likeKeys, ...userKeys, ...userIdKeys, ...areaKeys, ...sourceUrlKeys,
      ...commentCountKeys, ...repostKeys, ...idKeys
    ]))
    .map((key) => {
      const values = rows.map((row) => String(row[key] ?? "").trim()).filter(Boolean);
      const avgLength = values.reduce((sum, value) => sum + value.length, 0) / Math.max(values.length, 1);
      const chineseCount = values.join("").match(/[\u4e00-\u9fa5]/g)?.length || 0;
      const numericPenalty = values.filter((value) => /^[\d.:-]+$/.test(value)).length / Math.max(values.length, 1);
      return { key, score: avgLength + chineseCount * 0.08 - numericPenalty * 80 };
    })
    .sort((a, b) => b.score - a.score)[0]?.key;
}

function inferProfile(keys: string[], sourceName = ""): DataProfile {
  const source = sourceName.toLowerCase();
  if (keys.some((key) => normalizeKey(key) === normalizeKey("弹幕内容")) || source.includes("弹幕")) return "danmaku";
  if (keys.some((key) => normalizeKey(key) === "comment") && keys.some((key) => normalizeKey(key) === "star")) return "movie_review";
  if (keys.some((key) => ["newsid", "article_title", "articletitle"].includes(normalizeKey(key)))) return "news_comment";
  if (keys.some((key) => ["博主", "评论人", "页面网址", "发布时间IP"].some((candidate) => normalizeKey(key) === normalizeKey(candidate)))) return "platform_comment";
  if (keys.some((key) => findKeyFromKeys([key], platformKeys))) return "platform_comment";
  return "generic_comment";
}

function detectStaticPlatform(profile: DataProfile, keys: string[], sourceName = "") {
  if (profile === "danmaku") return "B站";
  if (/bilibili|b站|哔哩|弹幕/i.test(sourceName)) return "B站";
  if (/xiaohongshu|xhs|小红书/i.test(sourceName)) return "小红书";
  if (keys.some((key) => ["博主", "评论人", "页面网址", "发布时间IP"].some((candidate) => normalizeKey(key) === normalizeKey(candidate)))) return "小红书";
  if (keys.some((key) => normalizeKey(key) === "newsid") && /sina|新浪/i.test(sourceName)) return "新浪新闻";
  return undefined;
}

function pad(value: string | number) {
  return String(value).padStart(2, "0");
}

function formatInChina(date: Date) {
  return new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Asia/Shanghai",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  }).format(date).replace(" ", "T");
}

function isMissingValue(value: unknown) {
  if (value === undefined || value === null) return true;
  const text = String(value).replace(/^\uFEFF/, "").trim();
  return missingTokens.has(text.toLowerCase());
}

function optionalText(value: unknown) {
  return isMissingValue(value) ? undefined : String(value).trim();
}

function normalizeLocalDateString(raw: string) {
  const match = raw.match(/^(\d{4})[/-](\d{1,2})[/-](\d{1,2})(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/);
  if (!match) return undefined;
  const [, year, month, day, hour = "0", minute = "0", second = "0"] = match;
  return `${year}-${pad(month)}-${pad(day)}T${pad(hour)}:${pad(minute)}:${pad(second)}`;
}

function safeDate(value: unknown) {
  if (isMissingValue(value)) return "";
  const raw = String(value).trim();
  const dateWithArea = raw.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:\s*[^\d\s]+)?$/);
  if (dateWithArea) {
    const [, year, month, day] = dateWithArea;
    return `${year}-${pad(month)}-${pad(day)}T00:00:00`;
  }
  const monthDayWithArea = raw.match(/^(\d{1,2})[-/.](\d{1,2})(?:\s*[\u4e00-\u9fa5]+)?$/);
  if (monthDayWithArea) {
    const [, month, day] = monthDayWithArea;
    return `${new Date().getFullYear()}-${pad(month)}-${pad(day)}T00:00:00`;
  }
  if (/^\d{10}$/.test(raw)) return formatInChina(new Date(Number(raw) * 1000));
  if (/^\d{13}$/.test(raw)) return formatInChina(new Date(Number(raw)));
  const localDate = normalizeLocalDateString(raw);
  if (localDate) return localDate;
  const normalized = raw.includes("/") ? raw.replaceAll("/", "-") : raw;
  const date = new Date(normalized);
  if (!Number.isNaN(date.getTime())) return formatInChina(date);
  return "";
}

function normalizeDateOnly(value: string | undefined) {
  if (!value) return undefined;
  const direct = value.match(/^(\d{4}-\d{2}-\d{2})/);
  if (direct) return direct[1];
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return formatInChina(date).slice(0, 10);
}

function toOptionalNumber(value: unknown) {
  if (isMissingValue(value)) return null;
  const number = Number(String(value ?? "").replace(/[^\d.-]/g, ""));
  return Number.isFinite(number) ? number : null;
}

function toNumber(value: unknown) {
  return toOptionalNumber(value) ?? 0;
}

function normalizeArea(value: unknown) {
  const text = optionalText(value);
  if (!text) return undefined;
  const match = text.match(/(?:\d{1,2}[-/.]\d{1,2})?\s*([\u4e00-\u9fa5]{2,})$/);
  return match?.[1] || text;
}

function inferRatingField(rows: RawRow[], keys: string[], profile: DataProfile) {
  const explicit = profile === "movie_review"
    ? findKeyFromKeys(keys, ratingKeys, ratingExcludeKeys)
    : findKeyFromKeys(keys, ["star", "rating", "评分", "星级", "打分"], ratingExcludeKeys);
  if (explicit) return explicit;

  const ambiguous = findKeyFromKeys(keys, ["score", "grade", "mark"], ratingExcludeKeys);
  if (!ambiguous) return undefined;

  const values = rows
    .map((row) => toOptionalNumber(row[ambiguous]))
    .filter((value): value is number => value !== null);
  if (!values.length) return undefined;

  const ratingLike = values.filter((value) => value >= 1 && value <= 5 && Number.isFinite(value)).length;
  return ratingLike / values.length >= 0.85 ? ambiguous : undefined;
}

function buildMapping(rowsInput: RawRow[], sourceName = ""): FieldMapping {
  const rows = normalizedRows(rowsInput);
  const keys = uniqueKeys(rows);
  const profile = inferProfile(keys, sourceName);
  const textField = inferContentKey(rows, profile);
  const platformField = findKeyFromKeys(keys, platformKeys);
  const staticPlatform = platformField ? undefined : detectStaticPlatform(profile, keys, sourceName);
  const objectField = findKeyFromKeys(keys, objectKeys);
  const objectAliasField = findKeyFromKeys(keys, objectAliasKeys);
  const timeField = profile === "danmaku"
    ? findKeyFromKeys(keys, ["发送时间", "publish_time", "发布时间"], ["发送时间戳", "视频内时间"])
    : findKeyFromKeys(keys, timeKeys, timeExcludeKeys);
  const ratingField = inferRatingField(rows, keys, profile);
  const likeField = findKeyFromKeys(keys, likeKeys);
  const userField = profile === "danmaku" ? undefined : findKeyFromKeys(keys, userKeys);
  const userIdField = profile === "danmaku" ? undefined : findKeyFromKeys(keys, userIdKeys);
  const collectedAtField = findKeyFromKeys(keys, collectedAtKeys);
  const sourceUrlField = findKeyFromKeys(keys, sourceUrlKeys);
  const areaField = findKeyFromKeys(keys, areaKeys);
  const used = new Set([
    textField, platformField, objectField, objectAliasField, timeField, ratingField, likeField, userField,
    userIdField, collectedAtField, sourceUrlField, areaField
  ].filter(Boolean));
  const metadataFields = keys.filter((key) => !used.has(key));
  const ignoredFields = profile === "danmaku"
    ? metadataFields.filter((key) => keyIncludes(key, nonCoreBiliFields))
    : metadataFields.filter((key) => findKeyFromKeys([key], idKeys));
  const detectedKind: DatasetKind = platformField || staticPlatform ? "platform_opinion" : objectField ? "object_review" : "generic_comment";

  return {
    textField,
    timeField,
    ratingField,
    likeField,
    userField,
    userIdField,
    objectField,
    objectAliasField,
    collectedAtField,
    platformField,
    staticPlatform,
    sourceUrlField,
    areaField,
    metadataFields,
    availableFields: keys,
    dataProfile: profile,
    ignoredFields,
    detectedKind
  };
}

function rowsToRecords(rowsInput: RawRow[], mapping: FieldMapping): OpinionRecord[] {
  const rows = normalizedRows(rowsInput);
  const keys = uniqueKeys(rows);
  const commentCountKey = findKeyFromKeys(keys, commentCountKeys);
  const repostKey = findKeyFromKeys(keys, repostKeys);

  return rows.slice(0, MAX_RECORDS).map((row, index) => {
    const metadata: OpinionRecord["metadata"] = {};
    (mapping.metadataFields || []).forEach((key) => {
      const value = row[key];
      if (!isMissingValue(value)) metadata[key] = typeof value === "number" ? value : String(value);
    });
    const missingFields: string[] = [];
    const inferredFields: string[] = [];
    const content = optionalText(mapping.textField ? row[mapping.textField] : undefined) || "";
    const publishTime = mapping.timeField ? safeDate(row[mapping.timeField]) : "";
    const platformRaw = mapping.platformField ? optionalText(row[mapping.platformField]) : undefined;
    const likeValue = mapping.likeField ? toOptionalNumber(row[mapping.likeField]) : null;
    const commentCountValue = commentCountKey ? toOptionalNumber(row[commentCountKey]) : null;
    const repostValue = repostKey ? toOptionalNumber(row[repostKey]) : null;
    const ratingValue = mapping.ratingField ? toOptionalNumber(row[mapping.ratingField]) : null;

    if (!content) missingFields.push("content");
    if (!publishTime) missingFields.push("publishTime");
    if (!mapping.likeField || likeValue === null) missingFields.push("likeCount");
    if (!mapping.ratingField || ratingValue === null || ratingValue <= 0) missingFields.push("rating");
    if (!mapping.userField && !mapping.userIdField) missingFields.push("user");
    if (mapping.userField && !optionalText(row[mapping.userField])) missingFields.push("user");
    if (mapping.userIdField && !optionalText(row[mapping.userIdField])) missingFields.push("userId");
    if (mapping.platformField && !platformRaw) missingFields.push("platform");

    const collectedAt = normalizeDateOnly(mapping.collectedAtField ? safeDate(row[mapping.collectedAtField]) : undefined);
    return {
      id: optionalText(row.ID || row.id || row.Number || row.number || row["序号"]) || String(index + 1),
      platform: mapping.staticPlatform || (mapping.platformField ? platformRaw || "未知平台" : ""),
      content,
      publishTime,
      likeCount: likeValue ?? 0,
      commentCount: commentCountValue ?? 0,
      repostCount: repostValue ?? 0,
      objectName: mapping.objectField ? optionalText(row[mapping.objectField]) : undefined,
      objectAlias: mapping.objectAliasField ? optionalText(row[mapping.objectAliasField]) : undefined,
      username: mapping.userField ? optionalText(row[mapping.userField]) || "匿名用户" : undefined,
      userId: mapping.userIdField ? optionalText(row[mapping.userIdField]) : undefined,
      rating: mapping.ratingField && ratingValue !== null && ratingValue > 0 ? ratingValue : null,
      collectedAt,
      sourceUrl: mapping.sourceUrlField ? optionalText(row[mapping.sourceUrlField]) : undefined,
      area: mapping.areaField ? normalizeArea(row[mapping.areaField]) : undefined,
      metadata,
      missingFields: Array.from(new Set(missingFields)),
      inferredFields
    };
  });
}

function csvRows(text: string, maxRows = MAX_RECORDS + 1) {
  const rows: string[][] = [];
  let cell = "";
  let row: string[] = [];
  let quote = false;

  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    const next = text[i + 1];
    if (char === '"' && quote && next === '"') {
      cell += '"';
      i += 1;
    } else if (char === '"') {
      quote = !quote;
    } else if (char === "," && !quote) {
      row.push(cell.trim());
      cell = "";
    } else if ((char === "\n" || char === "\r") && !quote) {
      if (char === "\r" && next === "\n") i += 1;
      row.push(cell.trim());
      if (row.some(Boolean)) rows.push(row);
      row = [];
      cell = "";
      if (rows.length >= maxRows) break;
    } else {
      cell += char;
    }
  }

  if (rows.length < maxRows) {
    row.push(cell.trim());
    if (row.some(Boolean)) rows.push(row);
  }
  return rows;
}

function emptyMapping(kind: DatasetKind, dataProfile: DataProfile = "generic_comment"): FieldMapping {
  return { ignoredFields: [], metadataFields: [], availableFields: [], detectedKind: kind, dataProfile };
}

export function parseCsv(text: string, sourceName = "") {
  const matrix = csvRows(text);
  if (!matrix.length) return { records: [], mapping: emptyMapping("generic_comment") };
  const header = matrix[0].map((item) => item.replace(/^\uFEFF/, "").trim());
  const knownHeaders = [
    ...contentKeys, ...platformKeys, ...objectKeys, ...objectAliasKeys, ...timeKeys, ...collectedAtKeys,
    ...ratingKeys, ...likeKeys, ...userKeys, ...userIdKeys, ...areaKeys, ...sourceUrlKeys, ...commentCountKeys,
    ...repostKeys, ...idKeys, ...nonCoreBiliFields
  ].map(normalizeKey);
  const looksLikeHeader = header.some((key) => knownHeaders.some((known) => normalizeKey(key) === known || normalizeKey(key).includes(known)))
    || header.every((key) => key.length <= 40 && !/[。！？]/.test(key));
  const dataRows = looksLikeHeader ? matrix.slice(1) : matrix;
  const keys = looksLikeHeader ? header : matrix[0].map((_, index) => `column_${index + 1}`);
  const rows = dataRows.map((cells) => Object.fromEntries(keys.map((key, index) => [key || `column_${index + 1}`, cells[index] || ""])));
  const mapping = buildMapping(rows, sourceName);
  return { records: rowsToRecords(rows, mapping), mapping };
}

export function parsePlainText(text: string, sourceName = "粘贴文本数据集") {
  const rows = text.split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .slice(0, MAX_RECORDS)
    .map((content, index) => ({ content, id: `${index + 1}` }));
  const mapping: FieldMapping = {
    textField: "content",
    ignoredFields: ["id"],
    metadataFields: ["id"],
    availableFields: ["content", "id"],
    detectedKind: "generic_comment",
    dataProfile: "plain_text"
  };
  return {
    mapping,
    records: rows.map((row, index, allRows) => ({
      id: row.id,
      platform: "",
      content: row.content,
      publishTime: "",
      likeCount: 0,
      commentCount: 0,
      repostCount: 0,
      rating: null,
      metadata: { id: row.id, sourceName },
      missingFields: ["publishTime", "likeCount", "rating", "user"],
      inferredFields: []
    }))
  };
}

export async function parseExcel(file: File) {
  const xlsx = await import("xlsx");
  const buffer = Buffer.from(await file.arrayBuffer());
  const workbook = xlsx.read(buffer, { type: "buffer", cellDates: true });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  const rows = xlsx.utils.sheet_to_json<RawRow>(sheet, { defval: "" }).slice(0, MAX_RECORDS);
  const mapping = buildMapping(rows, file.name);
  return { records: rowsToRecords(rows, mapping), mapping };
}

export async function readTextSample(file: File) {
  if (file.size <= MAX_TEXT_BYTES) return file.text();
  return file.slice(0, MAX_TEXT_BYTES).text();
}

export async function parseUploadedFile(file: File) {
  const lower = file.name.toLowerCase();
  if (lower.endsWith(".xlsx") || lower.endsWith(".xls")) return parseExcel(file);
  const text = await readTextSample(file);
  return lower.endsWith(".csv") ? parseCsv(text, file.name) : parsePlainText(text, file.name);
}
