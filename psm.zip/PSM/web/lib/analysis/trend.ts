import type { OpinionRecord, SentimentSummary, TrendPoint } from "@/lib/types";

function movingAverage(values: number[], index: number, window = 7) {
  const start = Math.max(0, index - window + 1);
  const slice = values.slice(start, index + 1);
  return slice.reduce((sum, value) => sum + value, 0) / Math.max(slice.length, 1);
}

export function buildTrend(records: OpinionRecord[], sentiment: SentimentSummary): TrendPoint[] {
  const byDate = new Map<string, OpinionRecord[]>();
  records.forEach((record) => {
    if (!record.publishTime || record.missingFields?.includes("publishTime")) return;
    const date = record.publishTime.slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return;
    byDate.set(date, [...(byDate.get(date) || []), record]);
  });
  const negativeByDate = new Map(sentiment.trend.map((row) => {
    const total = row.positive + row.neutral + row.negative || 1;
    return [row.date, row.negative / total];
  }));

  const daily = [...byDate.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([date, rows]) => {
    const likes = rows.reduce((sum, item) => sum + item.likeCount, 0);
    const comments = rows.length;
    const interactions = rows.reduce((sum, item) => sum + item.likeCount + item.commentCount + item.repostCount, 0);
    const negativeRate = negativeByDate.get(date) || 0;
    return { date, comments, likes, interactions, negativeRate };
  });

  if (!daily.length) return [];

  const composite = daily.map((item) => {
    const likeSignal = Math.log1p(item.likes) * 5;
    const interactionSignal = Math.log1p(item.interactions) * 3;
    return item.comments * 1.8 + likeSignal + interactionSignal;
  });
  const smoothed = composite.map((_, index) => movingAverage(composite, index, daily.length > 90 ? 7 : 3));
  const max = Math.max(...smoothed, 1);

  return daily.map((item, index) => {
    const normalizedHeat = Math.round((smoothed[index] / max) * 100);
    return {
      ...item,
      movingAverage: Number(smoothed[index].toFixed(2)),
      heat: item.comments > 0 ? Math.max(1, normalizedHeat) : 0
    };
  });
}
