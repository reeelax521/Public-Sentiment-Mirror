import type { CleanIssueSample, CleanResult, DataQualityIssue, DataQualitySummary, OpinionRecord } from "@/lib/types";
import { normalizeSocialText } from "@/lib/analysis/textNoise";

const urlPattern = /https?:\/\/\S+|www\.\S+/g;
const spacePattern = /\s+/g;

export function normalizeText(value: string) {
  return normalizeSocialText(value)
    .replace(urlPattern, " ")
    .replace(spacePattern, " ")
    .trim();
}

function isLowQuality(content: string) {
  const text = content.replace(/\s/g, "");
  if (text.length < 4) return true;
  const meaningful = text.match(/[\u4e00-\u9fa5a-zA-Z0-9]/g)?.length || 0;
  return meaningful / Math.max(text.length, 1) < 0.45;
}

function isSemanticAnomaly(content: string) {
  return /(.)\1{8,}/.test(content) || /^[\d\s.,，。!?！？~～-]+$/.test(content);
}

function hasMissing(record: OpinionRecord, field: string) {
  return Boolean(record.missingFields?.includes(field));
}

function issue(
  field: string,
  label: string,
  count: number,
  total: number,
  severity: DataQualityIssue["severity"],
  impact: string
): DataQualityIssue | null {
  if (count <= 0) return null;
  return {
    field,
    label,
    count,
    rate: Math.round((count / Math.max(total, 1)) * 100),
    severity,
    impact
  };
}

function buildQuality(records: OpinionRecord[], cleaned: OpinionRecord[], emptyCount: number): DataQualitySummary {
  const total = Math.max(cleaned.length, 1);
  const missingPublishTimeCount = cleaned.filter((record) => hasMissing(record, "publishTime") || !record.publishTime).length;
  const missingPlatformCount = cleaned.filter((record) => hasMissing(record, "platform") || !record.platform).length;
  const missingLikeCount = cleaned.filter((record) => hasMissing(record, "likeCount")).length;
  const missingRatingCount = cleaned.filter((record) => hasMissing(record, "rating") || record.rating === null || record.rating === undefined).length;
  const missingUserCount = cleaned.filter((record) => hasMissing(record, "user") || (!record.username && !record.userId)).length;
  const inferredPublishTimeCount = cleaned.filter((record) => record.inferredFields?.includes("publishTime")).length;
  const validTimeCount = cleaned.length - missingPublishTimeCount;
  const optionalAvailability = [
    validTimeCount,
    cleaned.length - missingPlatformCount,
    cleaned.length - missingLikeCount,
    cleaned.length - missingRatingCount,
    cleaned.length - missingUserCount
  ];
  const completenessScore = Math.round((optionalAvailability.reduce((sum, value) => sum + value / total, 0) / optionalAvailability.length) * 100);
  const issues = [
    issue("content", "评论内容缺失", emptyCount, records.length, "critical", "评论内容是必填字段，空文本会被删除。"),
    issue("publishTime", "发布时间缺失", missingPublishTimeCount, cleaned.length, "warning", "不再自动伪造时间；热度趋势和时间轴仅基于有真实时间的记录生成。"),
    issue("platform", "平台字段缺失", missingPlatformCount, cleaned.length, "info", "没有平台字段时不展示平台来源图；有平台字段但空值时标为未知平台。"),
    issue("likeCount", "互动数字缺失", missingLikeCount, cleaned.length, "info", "点赞、回复、转发缺失时按 0 参与热度计算，并在报告中提示可信度边界。"),
    issue("rating", "评分字段缺失", missingRatingCount, cleaned.length, "info", "评分缺失时不参与平均评分，也不会被当作 0 分影响情感判断。"),
    issue("user", "用户字段缺失", missingUserCount, cleaned.length, "info", "用户字段缺失时不做用户层面的归因或行为异常判断。")
  ].filter(Boolean) as DataQualityIssue[];

  return {
    missingContentCount: emptyCount,
    missingPublishTimeCount,
    missingPlatformCount,
    missingLikeCount,
    missingRatingCount,
    missingUserCount,
    inferredPublishTimeCount,
    validTimeCount,
    completenessScore,
    issues
  };
}

function duplicateKey(record: OpinionRecord, content: string) {
  const parts = [
    content,
    record.publishTime,
    record.username,
    record.userId,
    record.platform
  ].filter(Boolean);
  if (content.length < 8) parts.push(record.id);
  return parts.join("|") || content;
}

function sampleIssue(record: OpinionRecord, content: string, reason: string): CleanIssueSample {
  return {
    id: record.id,
    content,
    platform: record.platform,
    publishTime: record.publishTime,
    username: record.username,
    likeCount: record.likeCount,
    reason
  };
}

export function cleanRecords(records: OpinionRecord[]): CleanResult {
  const seen = new Set<string>();
  let duplicateCount = 0;
  let emptyCount = 0;
  let tooShortCount = 0;
  let lowQualityCount = 0;
  let semanticAnomalyCount = 0;
  const cleaned: OpinionRecord[] = [];
  const issueSamples: CleanResult["issueSamples"] = {
    tooShort: [],
    lowQuality: [],
    semanticAnomaly: []
  };

  for (const record of records) {
    const content = normalizeText(record.content || "");
    if (!content) {
      emptyCount += 1;
      continue;
    }
    const dedupeKey = duplicateKey(record, content);
    if (seen.has(dedupeKey)) {
      duplicateCount += 1;
      continue;
    }
    if (content.length < 6) {
      tooShortCount += 1;
      issueSamples.tooShort.push(sampleIssue(record, content, "文本长度少于 6 个字符，语义信息较弱。"));
    }
    if (isLowQuality(content)) {
      lowQualityCount += 1;
      issueSamples.lowQuality.push(sampleIssue(record, content, "有效中文、英文或数字占比较低，可能是表情、符号或噪声。"));
    }
    if (isSemanticAnomaly(content)) {
      semanticAnomalyCount += 1;
      issueSamples.semanticAnomaly.push(sampleIssue(record, content, "存在长重复字符或纯数字符号，语义解释价值较低。"));
    }
    seen.add(dedupeKey);
    cleaned.push({ ...record, content });
  }

  return {
    originalCount: records.length,
    duplicateCount,
    emptyCount,
    validCount: cleaned.length,
    tooShortCount,
    lowQualityCount,
    semanticAnomalyCount,
    issueSamples,
    records: cleaned,
    quality: buildQuality(records, cleaned, emptyCount)
  };
}
