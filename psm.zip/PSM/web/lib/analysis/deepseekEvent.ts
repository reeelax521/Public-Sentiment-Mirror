import { createDeepSeekChatCompletion, isDeepSeekConfigured } from "@/lib/deepseekClient";
import type {
  DashboardData,
  EventAnalysis,
  EventDynamicField,
  KeywordItem,
  OpinionRecord,
  SentimentSummary,
  TopicItem,
  TrendPoint
} from "@/lib/types";

type EventRefineInput = {
  records: OpinionRecord[];
  eventMaterial?: string;
  keywords: KeywordItem[];
  sentiment: SentimentSummary;
  trend: TrendPoint[];
  dashboard: DashboardData;
  topics: TopicItem[];
};

type DeepSeekEventResult = {
  name?: string;
  category?: string;
  eventType?: string;
  stage?: string;
  summary?: string;
  subjects?: string[];
  coreIssues?: string[];
  brief?: {
    what?: string;
    when?: string;
    where?: string;
    who?: string[];
    why?: string;
    how?: string;
  };
  dynamicFields?: EventDynamicField[];
};

const emptyValues = new Set(["无", "未知", "未识别", "不确定", "暂无", "N/A", "-"]);

function clip(value: string | undefined, max: number) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text.length > max ? `${text.slice(0, max)}...` : text;
}

function useful(value: unknown) {
  const text = String(value ?? "").trim();
  return Boolean(text) && !emptyValues.has(text);
}

function uniqueStrings(items: unknown, limit = 10) {
  if (!Array.isArray(items)) return [];
  return Array.from(new Set(items.map((item) => String(item || "").trim()).filter(useful))).slice(0, limit);
}

function normalizeFields(fields: unknown): EventDynamicField[] {
  if (!Array.isArray(fields)) return [];
  return fields
    .map((item) => {
      const row = item as Partial<EventDynamicField>;
      const confidence = String(row.confidence || "中").trim();
      return {
        label: String(row.label || "").trim(),
        value: String(row.value || "").trim(),
        evidence: row.evidence ? String(row.evidence).trim() : undefined,
        confidence: (["低", "中", "高"].includes(confidence) ? confidence : "中") as EventDynamicField["confidence"]
      };
    })
    .filter((item) => useful(item.label) && useful(item.value))
    .slice(0, 10);
}

function stripJsonFence(content: string) {
  return content.replace(/^```(?:json)?/i, "").replace(/```$/i, "").trim();
}

function parseJsonObject(content: string): DeepSeekEventResult | null {
  const stripped = stripJsonFence(content);
  try {
    return JSON.parse(stripped) as DeepSeekEventResult;
  } catch {
    const start = stripped.indexOf("{");
    const end = stripped.lastIndexOf("}");
    if (start < 0 || end <= start) return null;
    try {
      return JSON.parse(stripped.slice(start, end + 1)) as DeepSeekEventResult;
    } catch {
      return null;
    }
  }
}

function buildPrompt(base: EventAnalysis, input: EventRefineInput) {
  const comments = input.records
    .slice(0, 28)
    .map((record, index) => {
      const meta = [
        record.platform ? `平台=${record.platform}` : "",
        record.publishTime ? `时间=${record.publishTime.slice(0, 10)}` : "",
        record.likeCount ? `点赞=${record.likeCount}` : ""
      ].filter(Boolean).join("，");
      return `${index + 1}. ${clip(record.content, 110)}${meta ? `（${meta}）` : ""}`;
    })
    .join("\n");

  const keywords = input.keywords.slice(0, 24).map((item) => `${item.word}(${item.count})`).join("、");
  const topics = input.topics.slice(0, 8).map((topic) => `${topic.name}: ${topic.keywords.slice(0, 8).join("、")}`).join("\n");
  const trend = input.trend.slice(0, 10).map((item) => `${item.date}: heat=${item.heat}, comments=${item.comments}, negative=${Math.round(item.negativeRate * 100)}%`).join("；");

  return `你是一个中文舆情事件识别助手。请根据“事件材料”和“评论数据摘要”识别本次分析围绕的具体事件。

必须遵守：
1. 事件材料只用于理解事件身份、背景、主体和争议点，不可当作评论样本参与情感判断。
2. 不要套用固定模板。外交事件、文化事件、消费事件、校园事件、影视评论、B站弹幕等字段名称应不同。
3. 没有证据的字段不要输出，不要为了凑字段而猜测。不要输出“非遗文创 / 国潮消费 / 文旅传播”等示例值，除非材料确实支持。
4. name 不得使用文件名、带扩展名的标题或“【xxx.docx】”。应是公众能理解的事件名称。
5. stage 只能描述“本次样本呈现的讨论阶段”，不能断言全网真实阶段。
6. coreIssues 应来自事件材料和评论焦点，不要把“回复、评论、视频、弹幕、平台、网友”等通用词当作讨论对象。

请只返回 JSON，不要 Markdown，不要解释过程。结构如下：
{
  "name": "事件名称",
  "category": "事件类别",
  "eventType": "事件类型",
  "stage": "样本讨论阶段",
  "summary": "2到3句事件梗概，说明事件是什么、为何被讨论、评论主要关注什么",
  "subjects": ["核心主体"],
  "coreIssues": ["核心议题或争议点"],
  "brief": {
    "what": "发生了什么",
    "when": "时间",
    "where": "地点",
    "who": ["参与主体"],
    "why": "背景或起因，可为空",
    "how": "传播、处理或发展方式，可为空"
  },
  "dynamicFields": [
    { "label": "根据事件定制的字段名", "value": "字段值", "evidence": "简短依据", "confidence": "低|中|高" }
  ]
}

规则初稿：
${JSON.stringify({
  name: base.name,
  category: base.category,
  eventType: base.eventType,
  stage: base.stage,
  subjects: base.subjects,
  coreIssues: base.coreIssues,
  brief: base.brief
}, null, 2)}

事件材料：
${clip(input.eventMaterial, 6000)}

评论数据摘要：
- 评论数：${input.records.length}
- 主要平台：${input.dashboard.majorPlatform || "未识别"}
- 情感分布：正面 ${Math.round(input.sentiment.positive * 100)}%，中性 ${Math.round(input.sentiment.neutral * 100)}%，负面 ${Math.round(input.sentiment.negative * 100)}%
- 关键词：${keywords || "无"}
- 主题：${topics || "无"}
- 趋势：${trend || "无"}

评论样本：
${comments || "无"}`;
}

export async function refineEventAnalysisWithDeepSeek(base: EventAnalysis, input: EventRefineInput): Promise<EventAnalysis> {
  if (!isDeepSeekConfigured() || !input.eventMaterial?.trim()) return base;

  try {
    const completion = await createDeepSeekChatCompletion({
      maxTokens: 1900,
      responseFormat: "json_object",
      messages: [
        { role: "system", content: "你只返回严格 JSON，不输出 Markdown，不解释推理过程。" },
        { role: "user", content: buildPrompt(base, input) }
      ]
    });

    const parsed = completion?.content ? parseJsonObject(completion.content) : null;
    if (!parsed) return base;

    const subjects = uniqueStrings(parsed.subjects, 8);
    const coreIssues = uniqueStrings(parsed.coreIssues, 8);
    const who = uniqueStrings(parsed.brief?.who, 8);
    const dynamicFields = normalizeFields(parsed.dynamicFields);

    return {
      ...base,
      name: useful(parsed.name) ? String(parsed.name).trim() : base.name,
      category: useful(parsed.category) ? String(parsed.category).trim() : base.category,
      eventType: useful(parsed.eventType) ? String(parsed.eventType).trim() : base.eventType,
      stage: useful(parsed.stage) ? String(parsed.stage).trim() : base.stage,
      summary: useful(parsed.summary) ? String(parsed.summary).trim() : base.summary,
      subjects: subjects.length ? subjects : base.subjects,
      coreIssues: coreIssues.length ? coreIssues : base.coreIssues,
      brief: {
        what: useful(parsed.brief?.what) ? String(parsed.brief?.what).trim() : base.brief.what,
        when: useful(parsed.brief?.when) ? String(parsed.brief?.when).trim() : base.brief.when,
        where: useful(parsed.brief?.where) ? String(parsed.brief?.where).trim() : base.brief.where,
        who: who.length ? who : base.brief.who,
        why: useful(parsed.brief?.why) ? String(parsed.brief?.why).trim() : base.brief.why,
        how: useful(parsed.brief?.how) ? String(parsed.brief?.how).trim() : base.brief.how
      },
      dynamicFields: dynamicFields.length ? dynamicFields : base.dynamicFields,
      recognitionMode: "deepseek"
    };
  } catch (error) {
    console.warn("DeepSeek event recognition failed", error);
    return base;
  }
}
