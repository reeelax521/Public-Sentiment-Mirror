import type {
  DashboardData,
  EventAnalysis,
  EventKeywordGroups,
  LexiconItem,
  OpinionRecord,
  ShortTermPrediction,
  SentimentSummary,
  TopicItem,
  TrendPoint
} from "@/lib/types";

type TermRule = { term: string; aliases?: string[]; tone?: LexiconItem["tone"] };
type EventDomain = "diplomatic" | "cultural_public" | "cultural_consumer" | "education" | "consumer" | "object_review" | "public";

const subjectRules: TermRule[] = [
  { term: "国家博物馆" }, { term: "博物馆" }, { term: "博物院" }, { term: "凤冠冰箱贴" }, { term: "冰箱贴" },
  { term: "景区" }, { term: "品牌" }, { term: "文创品牌" }, { term: "传承人" },
  { term: "官方" }, { term: "平台" }, { term: "商家" }, { term: "企业" }, { term: "消费者" },
  { term: "用户" }, { term: "网友" }, { term: "学校" }, { term: "学生" }, { term: "媒体" }
];

const culturalRules: TermRule[] = [
  { term: "非遗", tone: "positive" }, { term: "传统文化", tone: "positive" }, { term: "国潮", tone: "positive" },
  { term: "传承", tone: "positive" }, { term: "匠心", tone: "positive" }, { term: "审美", tone: "positive" },
  { term: "文创", tone: "positive" }, { term: "漆扇", tone: "positive" },
  { term: "簪花", tone: "positive" }, { term: "香囊", tone: "positive" }, { term: "体验课", tone: "positive" },
  { term: "英歌舞", tone: "positive" }, { term: "潮汕", tone: "positive" }, { term: "民俗", tone: "positive" },
  { term: "传统", tone: "positive" }, { term: "文化", tone: "positive" }, { term: "表演", tone: "positive" },
  { term: "舞蹈", tone: "positive" }, { term: "遗产", tone: "positive" }, { term: "申遗", tone: "positive" },
  { term: "民间艺术", tone: "positive" }
];

const consumerRules: TermRule[] = [
  { term: "价格", tone: "mixed" }, { term: "太贵", tone: "negative" }, { term: "质量", tone: "mixed" },
  { term: "性价比", tone: "mixed" }, { term: "好看", tone: "positive" }, { term: "实用", tone: "positive" },
  { term: "体验", tone: "mixed" }, { term: "服务", tone: "mixed" }, { term: "排队", tone: "negative" },
  { term: "购买", tone: "mixed" }, { term: "售后", tone: "mixed" }
];

const riskRules: TermRule[] = [
  { term: "割韭菜", tone: "negative" }, { term: "太贵", tone: "negative" }, { term: "同质化", tone: "negative" },
  { term: "伪国潮", tone: "negative" }, { term: "过度商业化", tone: "negative" }, { term: "商业化", tone: "mixed" },
  { term: "质量差", tone: "negative" }, { term: "抄袭", tone: "negative" }, { term: "侵权", tone: "negative" },
  { term: "质疑", tone: "negative" }, { term: "争议", tone: "negative" }, { term: "不满", tone: "negative" },
  { term: "失望", tone: "negative" }, { term: "回应不足", aliases: ["没回应", "回应太慢"], tone: "negative" }
];

const diplomaticSubjectRules: TermRule[] = [
  { term: "特朗普" }, { term: "习近平" }, { term: "美国" }, { term: "中国" }, { term: "中华人民共和国" },
  { term: "白宫" }, { term: "外交部" }, { term: "国务院" }, { term: "国防部" }, { term: "商务部" },
  { term: "财政部" }, { term: "企业代表团" }, { term: "商界代表团" }, { term: "国务卿" }, { term: "贸易代表" }
];

const diplomaticIssueRules: TermRule[] = [
  { term: "国事访问" }, { term: "中美关系" }, { term: "经贸合作" }, { term: "贸易" }, { term: "台湾问题", tone: "mixed" },
  { term: "伊朗", tone: "mixed" }, { term: "人工智能" }, { term: "能源" }, { term: "安全保障", tone: "mixed" },
  { term: "商务代表团" }, { term: "利益冲突", tone: "negative" }, { term: "芬太尼", tone: "mixed" },
  { term: "会晤" }, { term: "双边会谈" }, { term: "战略稳定" }
];

function compactText(value?: string) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function materialLines(eventMaterial?: string) {
  return String(eventMaterial || "").split(/\r?\n/).map((line) => compactText(line)).filter(Boolean);
}

function allText(records: OpinionRecord[], eventMaterial?: string) {
  return `${eventMaterial || ""}\n${records.map((record) => record.content).join("\n")}`;
}

function valueAfterLabel(line: string, labels: string[]) {
  const labelPattern = labels.map((label) => label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|");
  const match = line.match(new RegExp(`^(${labelPattern})\\s*[:：\\t ]\\s*(.+)$`));
  return match?.[2]?.trim() || "";
}

function firstLabeledValue(lines: string[], labels: string[]) {
  for (const line of lines) {
    const value = valueAfterLabel(line, labels);
    if (value) return value;
  }
  return "";
}

function uniqueTerms(items: string[], limit = 8) {
  return Array.from(new Set(items.map((item) => item.trim()).filter(Boolean))).slice(0, limit);
}

function normalizeActorName(value: string) {
  return value
    .replace(/唐纳德[·・•]特朗普/g, "特朗普")
    .replace(/中华人民共和国/g, "中国")
    .replace(/中共中央总书记、国家主席/g, "")
    .replace(/总统[:：]?/g, "")
    .trim();
}

function uniqueActors(items: string[], limit = 8) {
  return uniqueTerms(items.map(normalizeActorName), limit);
}

function sentenceWith(text: string, patterns: RegExp[]) {
  return compactText(text)
    .split(/(?<=[。！？])/)
    .map((item) => item.trim())
    .find((sentence) => patterns.some((pattern) => pattern.test(sentence))) || "";
}

function inferDomain(text: string, dashboard: DashboardData): EventDomain {
  if (/特朗普|习近平|国事访问|访华|中美|白宫|外交部|国务卿|总统|会晤|双边会谈/.test(text)) return "diplomatic";
  const hasCultureSignal = /非遗|传统文化|传统|传承|民俗|民间艺术|文化遗产|申遗|英歌舞|潮汕|表演|舞蹈|节日|遗产/.test(text);
  const hasConsumerSignal = /文创|产品|价格|太贵|消费|购买|性价比|质量|商家|品牌|售后|排队|体验课/.test(text);
  if (hasCultureSignal && hasConsumerSignal) return "cultural_consumer";
  if (hasCultureSignal) return "cultural_public";
  if (dashboard.sourceMode === "object_review") return "object_review";
  if (/学校|学生|校园|班级|宿舍|校方/.test(text)) return "education";
  if (/价格|质量|消费|服务|商家|品牌|售后|性价比/.test(text)) return "consumer";
  return "public";
}

function extractDateFromMaterial(lines: string[], text: string) {
  const labeled = firstLabeledValue(lines, ["日期", "时间", "发生时间", "事件时间", "访问时间"]);
  if (labeled) return labeled;
  return text.match(/20\d{2}年\d{1,2}月\d{1,2}日(?:\s*[—\-至到]\s*(?:20\d{2}年)?\d{1,2}月?\d{0,2}日?)?/)?.[0] || "";
}

function extractActorsFromMaterial(lines: string[], text: string, subjects: LexiconItem[]) {
  const labeled = firstLabeledValue(lines, ["参与者", "参与方", "涉事主体", "核心主体", "相关主体"]);
  const roleActors = lines
    .slice(0, 30)
    .map((line) => line.match(/^(总统|主席|国务卿|国防部长|财政部长|贸易代表|外交部长|代表|机构|平台|企业|品牌|景区|学校|官方)\s*[:：]\s*(.+)$/)?.[2])
    .filter(Boolean) as string[];
  const known = ["特朗普", "习近平", "美国", "中国", "中华人民共和国", "白宫", "外交部", "新浪新闻", "微博", "小红书", "B站"]
    .filter((term) => text.includes(term));
  return uniqueActors([labeled, ...roleActors, ...subjects.map((item) => item.term), ...known], 8);
}

function buildEventBrief(eventMaterial: string | undefined, name: string, subjects: LexiconItem[], coreIssues: string[]): EventAnalysis["brief"] {
  const lines = materialLines(eventMaterial);
  const text = compactText(eventMaterial);
  if (!text) return { who: subjects.slice(0, 6).map((item) => item.term) };
  const when = extractDateFromMaterial(lines, text);
  const where = firstLabeledValue(lines, ["地点", "发生地点", "所在地", "位置"]);
  const who = extractActorsFromMaterial(lines, text, subjects);
  const why = firstLabeledValue(lines, ["背景", "起因", "核心争议", "核心问题", "讨论焦点"]) || sentenceWith(text, [/背景|起源|原因|引发|争议|焦点|讨论重点|关注点/]);
  const how = sentenceWith(text, [/随后|形成讨论|扩散|升温|回应|会面|会晤|行程|成果|达成/]);
  const what = [
    name,
    when ? `发生时间为 ${when}` : "",
    where ? `地点为 ${where}` : "",
    who.length ? `涉及 ${who.slice(0, 4).join("、")}` : "",
    coreIssues.length ? `关注点包括 ${coreIssues.slice(0, 4).join("、")}` : ""
  ].filter(Boolean).join("，") + "。";

  return { what, when, where, who, why, how };
}

function countTerm(text: string, rule: TermRule) {
  const terms = [rule.term, ...(rule.aliases || [])];
  return terms.reduce((sum, term) => sum + (text.match(new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"))?.length || 0), 0);
}

function countTermInRecords(records: OpinionRecord[], rule: TermRule) {
  const terms = [rule.term, ...(rule.aliases || [])];
  return records.reduce((sum, record) => {
    return sum + terms.reduce((inner, term) => inner + (record.content.match(new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"))?.length || 0), 0);
  }, 0);
}

function examplesFor(records: OpinionRecord[], rule: TermRule, limit = 2) {
  const terms = [rule.term, ...(rule.aliases || [])];
  return records
    .filter((record) => terms.some((term) => record.content.includes(term)))
    .sort((a, b) => b.likeCount - a.likeCount)
    .slice(0, limit)
    .map((record) => record.content);
}

function extractItems(records: OpinionRecord[], rules: TermRule[], limit = 8): LexiconItem[] {
  return rules
    .map((rule) => {
      const examples = examplesFor(records, rule);
      return {
        term: rule.term,
        count: countTermInRecords(records, rule),
        tone: rule.tone,
        examples
      };
    })
    .filter((item) => item.count > 0 && item.examples.length > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, limit);
}

function topKeywordsAsItems(records: OpinionRecord[], keywords: Array<{ word: string; count: number }>, used: Set<string>, limit = 5): LexiconItem[] {
  return keywords
    .filter((item) => item.word.length >= 2 && !used.has(item.word) && !growthKeywordStopwords.has(item.word))
    .filter((item) => /(馆|院|宫|局|部|会|司|店|校|府|景区|品牌|机构|企业|公司|官方|产品|作品|冰箱贴|文创)$/.test(item.word) || /凤冠|冰箱贴|文创|博物馆|博物院|景区|品牌|学校|企业|机构|官方/.test(item.word))
    .slice(0, limit)
    .map((item) => ({
      term: item.word,
      count: item.count,
      examples: records.filter((record) => record.content.includes(item.word)).slice(0, 2).map((record) => record.content)
    }));
}

function eventTitleFromMaterial(eventMaterial: string | undefined) {
  const lines = String(eventMaterial || "").split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const looksLikeFileName = (line: string) => /(\.docx?|\.txt|\.csv|\.xlsx?)$/i.test(line) || /^【[^】]+\.(docx?|txt|csv|xlsx?)】$/i.test(line);
  const cleanTitle = (line: string) => line.replace(/^#\s*/, "").replace(/^【(.+)】$/, "$1").trim();
  const explicit = lines.find((line) => /^(标题|事件名称|主题)[:：]/.test(line));
  if (explicit) {
    const title = cleanTitle(explicit.replace(/^(标题|事件名称|主题)[:：]\s*/, ""));
    if (title && !looksLikeFileName(title)) return title.slice(0, 34);
  }
  const firstUseful = lines
    .map(cleanTitle)
    .find((line) => line.length >= 6 && line.length <= 44 && !/[。！？]$/.test(line) && !looksLikeFileName(line));
  if (firstUseful) return firstUseful.slice(0, 34);
  const sentence = compactText(eventMaterial).split(/[。！？]/)[0];
  const title = cleanTitle(sentence);
  return title && !looksLikeFileName(title) ? title.slice(0, 28) : "";
}

function inferEventName(records: OpinionRecord[], dashboard: DashboardData, keywords: Array<{ word: string; count: number }>, eventMaterial?: string) {
  const title = eventTitleFromMaterial(eventMaterial);
  if (title) return title;
  if (dashboard.objectName) return `${dashboard.objectName}评论事件`;
  const object = records.find((record) => record.objectName)?.objectName;
  if (object) return `${object}评论事件`;
  const top = keywords.slice(0, 2).map((item) => item.word).join("与");
  return top ? `${top}相关舆情事件` : "未命名舆情事件";
}

function inferCategory(domain: EventDomain) {
  if (domain === "diplomatic") return "国际关系 / 外交访问 / 公共议题";
  if (domain === "cultural_public") return "传统文化 / 非遗传播 / 公共文化";
  if (domain === "cultural_consumer") return "非遗文创 / 国潮消费 / 文旅传播";
  if (domain === "object_review") return "作品评论 / 口碑传播";
  if (domain === "education") return "校园管理 / 公共沟通";
  if (domain === "consumer") return "消费评价 / 品牌声誉";
  return "";
}

function inferEventType(domain: EventDomain, sentiment: SentimentSummary, groups: EventKeywordGroups) {
  if (domain === "diplomatic") return "外交访问型";
  if (domain === "cultural_public") return sentiment.positive >= 0.45 ? "文化传播型" : "公共文化讨论型";
  if (domain === "education") return sentiment.negative >= 0.25 ? "管理争议型" : "公共沟通型";
  if (domain === "consumer" || domain === "object_review") return "评论评价型";
  if (sentiment.negative >= 0.25 || groups.riskDisputes.length >= 3) return "争议扩散型";
  if (sentiment.positive >= 0.55 && groups.culturalValues.length) return "正向传播型";
  if (groups.consumerEvaluations.length) return "消费评价型";
  return "";
}

function inferStage(trend: TrendPoint[], dashboard: DashboardData) {
  if (!trend.length) return "时间信息不足";
  const peakIndex = trend.reduce((best, point, index) => point.heat > trend[best].heat ? index : best, 0);
  const last = trend[trend.length - 1];
  const peak = trend[peakIndex];
  if (trend.length <= 2 && last.heat >= 70) return "样本讨论爆发期";
  if (last.date === peak.date && peak.heat >= 85) return "样本讨论峰值期";
  if (last.heat <= peak.heat * 0.45) return "样本长尾观察期";
  if (last.heat < peak.heat) return "样本讨论回落期";
  return "样本讨论升温期";
}

function slopeLabel(values: number[]): "上升" | "平稳" | "下降" | "不足" {
  if (values.length < 3) return "不足";
  const first = values[0];
  const last = values[values.length - 1];
  const diff = last - first;
  if (Math.abs(diff) <= 5) return "平稳";
  return diff > 0 ? "上升" : "下降";
}

const growthKeywordStopwords = new Set([
  "回复", "评论", "视频", "弹幕", "平台", "媒体", "用户", "网友", "内容", "观点",
  "打卡", "文旅", "国潮", "种草", "出圈", "更多", "很多", "这个", "那个", "可以", "应该",
  "这么", "地方", "好看", "喜欢", "博物", "确实", "还有", "不到", "网上", "一般"
]);

function growthKeywords(records: OpinionRecord[], keywords: Array<{ word: string; count: number }>) {
  if (records.length < 12) return [];
  const sortedRecords = [...records].sort((a, b) => {
    const left = a.publishTime ? Date.parse(a.publishTime) : Number.NaN;
    const right = b.publishTime ? Date.parse(b.publishTime) : Number.NaN;
    if (Number.isFinite(left) && Number.isFinite(right)) return left - right;
    return 0;
  });
  const mid = Math.floor(sortedRecords.length / 2);
  const early = sortedRecords.slice(0, mid).map((record) => record.content).join("\n");
  const late = sortedRecords.slice(mid).map((record) => record.content).join("\n");
  return keywords
    .filter((keyword) => !growthKeywordStopwords.has(keyword.word))
    .map((keyword) => {
      const word = keyword.word;
      const earlyCount = (early.match(new RegExp(word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"))?.length || 0);
      const lateCount = (late.match(new RegExp(word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"))?.length || 0);
      const growth = lateCount - earlyCount;
      const ratio = (lateCount + 1) / (earlyCount + 1);
      return { word, growth, ratio, lateCount };
    })
    .filter((item) => item.growth > 0 && item.lateCount >= 2 && item.ratio >= 1.25)
    .sort((a, b) => b.growth - a.growth || b.ratio - a.ratio)
    .slice(0, 5)
    .map((item) => item.word);
}

function buildPrediction(records: OpinionRecord[], trend: TrendPoint[], sentiment: SentimentSummary, groups: EventKeywordGroups, dashboard: DashboardData, keywords: Array<{ word: string; count: number }>) {
  const recent = trend.slice(-3);
  const heatSlope = slopeLabel(recent.map((point) => point.heat));
  const negativeSlope = slopeLabel(recent.map((point) => Math.round(point.negativeRate * 100)));
  const negativeChange: ShortTermPrediction["negativeChange"] = negativeSlope === "平稳" ? "持平" : negativeSlope;
  const growth = Array.from(new Set([...groups.growthHotspots.map((item) => item.term), ...growthKeywords(records, keywords)])).slice(0, 5);
  const confidence: ShortTermPrediction["confidence"] = records.length >= 300 && trend.length >= 5 ? "高" : records.length >= 50 && trend.length >= 3 ? "中" : "低";
  const result = heatSlope === "下降"
    ? `根据近3日热度变化，事件大概率从峰值进入${dashboard.overallStatus.includes("长尾") ? "长尾观察" : "回落观察"}。`
    : heatSlope === "上升"
      ? "根据近3日热度变化，事件仍有继续升温的可能。"
      : heatSlope === "平稳"
        ? "根据近3日热度变化，事件短期内可能保持平稳讨论。"
        : "当前时间序列不足，短期趋势仅能作为低置信度参考。";
  const negativeFocus = groups.riskDisputes.filter((item) => item.tone === "negative").slice(0, 3).map((item) => item.term);
  const issueFocus = groups.riskDisputes.slice(0, 3).map((item) => item.term);
  const riskFocus = (negativeFocus.length ? negativeFocus : issueFocus).join("、");
  const growthBasis = growth.length
    ? `样本内识别到后段增长词：${growth.slice(0, 3).join("、")}。`
    : "当前未识别到可靠的关键词增长词，不强行归纳热点词。";
  const advice = negativeFocus.length
    ? `后续优先观察风险表达${riskFocus}是否在长尾阶段继续出现。`
    : riskFocus
      ? `后续优先观察核心议题${riskFocus}是否在长尾阶段继续出现。`
      : "后续优先观察高互动评论与新增表达是否改变讨论方向。";
  return {
    heatSlope,
    negativeChange,
    growthKeywords: growth,
    result,
    confidence,
    basis: `热度指数为相对标准化指标，表示本次样本内部变化，不等同于全网绝对热度。当前负面占比为 ${Math.round(sentiment.negative * 100)}%，传播热度为${dashboard.propagationHeat}。${growthBasis}`,
    advice
  };
}

function representativeBySentiment(sentiment: SentimentSummary, label: "positive" | "neutral" | "negative") {
  return sentiment.records
    .filter((record) => record.sentiment === label)
    .sort((a, b) => b.likeCount - a.likeCount)
    .slice(0, 3)
    .map((record) => record.content);
}

const driverStopwords = new Set([
  "回复", "视频", "评论", "弹幕", "内容", "观点", "平台", "媒体", "用户", "网友", "这个", "那个",
  "很多", "主要", "下面", "可以", "应该", "觉得", "感觉", "真的", "一下", "一些", "一个",
  "他们", "我们", "你们", "哈哈", "哈哈哈"
]);

function sentimentEvidenceTerms(sentiment: SentimentSummary, label: "positive" | "neutral" | "negative", limit = 4) {
  const counter = new Map<string, number>();
  sentiment.records
    .filter((record) => record.sentiment === label)
    .forEach((record) => {
      const words = record.content.match(/[\u4e00-\u9fa5]{2,8}|[A-Za-z][A-Za-z\s]{2,24}/g) || [];
      words.forEach((raw) => {
        const word = raw.replace(/\s+/g, " ").trim();
        if (!word || driverStopwords.has(word)) return;
        if (/^(回复|评论|视频|弹幕|这个|那个|可以|应该|很多|主要)/.test(word)) return;
        counter.set(word, (counter.get(word) || 0) + 1);
      });
    });
  return [...counter.entries()]
    .filter(([, count]) => count >= 2)
    .sort((a, b) => b[1] - a[1] || b[0].length - a[0].length)
    .slice(0, limit)
    .map(([word]) => word);
}

function reasonFromTerms(prefix: string, terms: string[]) {
  return terms.length ? `${prefix}${terms.slice(0, 4).join("、")}` : "";
}

function buildSentimentDrivers(groups: EventKeywordGroups, sentiment: SentimentSummary) {
  const negativeIssueTerms = groups.riskDisputes.filter((item) => item.tone === "negative" && item.examples.length > 0);
  const positiveCultureTerms = groups.culturalValues.filter((item) => item.examples.length > 0).slice(0, 4).map((item) => item.term);
  const positiveConsumerTerms = groups.consumerEvaluations.filter((item) => item.tone === "positive" && item.examples.length > 0).slice(0, 3).map((item) => item.term);
  const neutralTerms = sentimentEvidenceTerms(sentiment, "neutral", 4);
  const negativeTerms = negativeIssueTerms.length
    ? negativeIssueTerms.slice(0, 4).map((item) => item.term)
    : sentimentEvidenceTerms(sentiment, "negative", 4);
  const positiveReasons = [
    reasonFromTerms("正向表达集中在", [...positiveCultureTerms, ...positiveConsumerTerms]),
    sentiment.positive > 0.25 ? "支持、期待或认可表达较集中" : ""
  ].filter(Boolean);
  const neutralReasons = [
    neutralTerms.length ? `中性评论多围绕${neutralTerms.join("、")}等事实信息或提问展开` : "观望态度、事实判断或信息不足"
  ];
  const negativeReasons = [
    negativeTerms.length ? `负面样本主要围绕${negativeTerms.join("、")}展开` : "",
    sentiment.negative > 0.15 ? "负面评论占比需要观察" : ""
  ].filter(Boolean);

  return [
    { label: "正面", reasons: positiveReasons.length ? positiveReasons : ["认可、支持或积极期待"], representativeExpressions: representativeBySentiment(sentiment, "positive") },
    { label: "中性", reasons: neutralReasons, representativeExpressions: representativeBySentiment(sentiment, "neutral") },
    { label: "负面", reasons: negativeReasons.length ? negativeReasons : ["未形成集中负面原因"], representativeExpressions: representativeBySentiment(sentiment, "negative") }
  ] satisfies EventAnalysis["sentimentDrivers"];
}

function readableTopicName(topic: TopicItem) {
  const text = `${topic.name} ${topic.keywords.join(" ")} ${topic.representativeTexts.join(" ")}`;
  if (/只此青绿|青绿|千里江山|江山|青山|山水|华夏|舞蹈|舞美|配色|老虎|妩媚|春晚|节目|文化自信|文艺复兴/.test(text)) {
    if (/b站|版本|没看过|侵权|抄袭|授权|原创|央视/.test(text)) return "版本来源与原创争议";
    if (/看不懂|没看懂|不懂|解读|讲解|赏析|意境|明白|理解/.test(text)) return "艺术理解与观演门槛";
    if (/华夏|文化自信|传统文化|文艺复兴|传承|国风|中国审美/.test(text)) return "文化认同与传统传承";
    return "舞台审美与文化表达";
  }
  if (/预约|名额|门票|抢掉|抢不到|抢名额|约上|约不上|难约|看展|逛国博|参观/.test(text)) return "预约名额与参观体验冲突";
  if (/黄牛|倒卖|代购|加价|限购|抢购/.test(text)) return "抢购秩序与黄牛风险";
  if (/凤冠|冰箱贴|国博|国家博物馆|文创产品|爆款|热卖|销量/.test(text) && /销售|销量|热度|爆款|限购|购买/.test(text)) return "爆款文创与销售热度";
  if (/价格|太贵|性价比|割韭菜|值不值|不值/.test(text)) return "价格与消费体验争议";
  if (/消费|购买|淘宝|没抢上|抢不到|想买|到手|买到|售罄|缺货/.test(text)) return "购买体验与爆款供需";
  if (/好看|审美|拍照|种草|打卡|出圈|体验|发卡|卡头发|造型|漂亮|精致|设计/.test(text)) return "审美造型与体验评价";
  if (/传统|文化|传承|匠心|国潮|遗产|民俗|节日/.test(text)) return "文化认同与传统传承";
  if (/质量|真假|真实|抄袭|原创|同质化/.test(text)) return "质量真实性与原创争议";
  if (/文旅|景区|城市|旅游|博物馆/.test(text)) return "文旅打卡与城市传播";
  if (/商业化|过度消费|边界/.test(text)) return "商业化边界讨论";
  if (/学生|学校|管理|安全/.test(text) && /反对|质疑|不满/.test(text)) return "管理方式争议";
  if (/学生|学校|管理|安全/.test(text) && /支持|建议|理性/.test(text)) return "安全管理支持与理性建议";
  if (/回应|官方|服务|处理|解释/.test(text)) return "官方回应与服务问题";
  if (/合作|发展|期待|共赢|希望/.test(text)) return "合作发展期待";
  if (/质疑|担心|风险|反对|失望/.test(text)) return "疑问质疑与风险关注";
  if (/支持|认可|满意|期待|喜欢/.test(text)) return "正向态度与认可表达";
  if (/相关讨论|综合讨论|综合评论|其他讨论/.test(topic.name)) {
    const readable = topic.keywords.filter(isReadableTopicTerm).slice(0, 2);
    return readable.length ? `${readable.join("与")}相关讨论` : "长尾评论与补充表达";
  }
  return topic.name.includes("、") ? `围绕“${topic.keywords.filter(isReadableTopicTerm).slice(0, 2).join("、") || "长尾评论"}”的讨论` : topic.name;
}

function isReadableTopicTerm(term: string) {
  const value = term.trim();
  if (!value) return false;
  if (/^\d+$/.test(value)) return false;
  if (/^[a-z0-9_]{1,}$/i.test(value)) return /^unesco$/i.test(value);
  if (value.length < 2 || value.length > 12) return false;
  if (/^(回复|评论|视频|弹幕|内容|观点|平台|媒体|用户|网友|这个|那个|这么|可以|应该|地方|还有|不到|网上|super|up|bip|call|doge|b站)$/i.test(value)) return false;
  if (/^(另一个|个人|头发|有人吗|bgm|bmg|舞蹈区|投稿|原版|版本)$/.test(value)) return false;
  if (/^[a-z0-9_]+$/i.test(value)) return false;
  return true;
}

function topicJudgment(topic: TopicItem, name: string, riskLevel: "低" | "中" | "高", positive: boolean, negative: boolean) {
  const terms = topic.keywords.slice(0, 4).join("、");
  if (name.includes("预约名额")) return "该主题直接涉及参观名额被购买需求挤占、正常看展体验受影响，属于服务秩序类负面焦点。";
  if (name.includes("版本来源")) return "该主题围绕不同平台版本、节目来源、授权或原创归属展开。是否构成风险取决于是否出现明确侵权、抄袭或来源争议。";
  if (name.includes("艺术理解")) return "该主题主要反映观众对作品意象、叙事和审美表达的理解门槛，通常属于解释需求，不应直接按负面风险处理。";
  if (name.includes("舞台审美")) return "该主题集中在舞蹈、舞美、配色和国风审美表达上，是传统文化舞台化传播的核心观演反馈，不属于消费种草议题。";
  if (name.includes("文化认同")) return "该主题表达对传统文化、华夏意象和文化自信的认同，通常是正向关注点。";
  if (name.includes("黄牛")) return "该主题涉及抢购、倒卖或加价风险，若与高互动评论叠加，需要优先观察。";
  if (name.includes("价格")) return "该主题围绕价格、购买门槛和消费值不值展开，重点看高点赞吐槽是否继续扩散。";
  if (name.includes("购买体验")) return "该主题集中在想买、购买渠道、是否抢得到和到手体验上。若表达以“漂亮、想买、抢手”为主，应理解为爆款热度；只有伴随黄牛、加价或预约挤占时才上升为风险。";
  if (name.includes("审美")) return "该主题主要讨论造型、佩戴体验和产品设计，既可能形成种草，也可能暴露体验短板。";
  if (name.includes("爆款文创")) return "该主题反映文创产品销售热度和传播效果，热度本身不等同于风险，需结合购买秩序和体验反馈判断。";
  if (riskLevel === "高") return `该主题同时具备负面语义和较高样本占比，关键词集中在${terms || "相关争议"}，需重点关注。`;
  if (riskLevel === "中") return `该主题出现一定争议表达，关键词集中在${terms || "相关议题"}，建议观察是否继续扩散。`;
  if (positive && topic.percentage >= 20) return `该主题热度较高但以正向表达为主，关键词集中在${terms || "相关议题"}，属于高关注议题而非高风险。`;
  if (negative) return `该主题存在负面表达，但规模或互动强度暂未达到高风险阈值，关键词集中在${terms || "相关议题"}。`;
  return `该主题主要围绕${terms || name}展开，当前更适合作为常规观察维度。`;
}

function enrichTopic(topic: TopicItem): TopicItem {
  const cleanedKeywords = topic.keywords.filter(isReadableTopicTerm).slice(0, 10);
  const text = `${topic.name} ${cleanedKeywords.join(" ")} ${topic.representativeTexts.join(" ")}`;
  const negativeTerms = text.match(/太贵|割韭菜|质疑|不满|失望|风险|质量差|抄袭|过度商业化|反对|丢人|造假|恶心|无语|翻译争议|误读|担忧|被偷|抢走|坏处|抢掉|预约名额|约不上|难约|黄牛|倒卖|加价/g) || [];
  const positiveTerms = text.match(/支持|期待|认可|好看|漂亮|超级漂亮|精致|想买|抢手|爆款|热门|传承|喜欢|共赢|满意|祝贺|恭喜|成功|开心|自豪|骄傲|好消息|点赞|文化自信|传统文化/g) || [];
  const negative = negativeTerms.length > 0;
  const positive = positiveTerms.length > 0;
  const sentimentTendency = negative && positive ? "分化" : negative ? "负面" : positive ? "正面" : "中性";
  const negativeStrength = Math.min(1, negativeTerms.length / Math.max(topic.keywords.length + topic.representativeTexts.length, 1));
  const heatShare = Math.min(1, topic.percentage / 35);
  const riskScore = negative
    ? Math.round((negativeStrength * 55 + heatShare * 35 + (sentimentTendency === "分化" ? 10 : 0)))
    : Math.round(heatShare * 18);
  const riskLevel = riskScore >= 62 ? "高" : riskScore >= 32 ? "中" : "低";
  const name = readableTopicName(topic);
  return {
    ...topic,
    name,
    keywords: cleanedKeywords.length ? cleanedKeywords : topic.keywords.slice(0, 3).filter(isReadableTopicTerm),
    sentimentTendency,
    riskLevel,
    judgment: topicJudgment({ ...topic, keywords: cleanedKeywords }, name, riskLevel, positive, negative)
  };
}

function buildTimelineInsights(trend: TrendPoint[], eventName: string, stage: string, groups: EventKeywordGroups): EventAnalysis["timeline"] {
  if (!trend.length) {
    return [{ time: "-", eventNode: "事件材料整理", dataSignal: "未识别到有效发布时间", systemJudgment: "暂不强行划分生命周期阶段" }];
  }
  const points = [...new Map(trend.filter((point) => point.comments > 0 || point.likes > 0).map((point) => [point.date, point])).values()]
    .sort((a, b) => a.date.localeCompare(b.date));
  if (!points.length) {
    return [{ time: "-", eventNode: "事件材料整理", dataSignal: "未识别到有效评论日期", systemJudgment: "暂不强行划分生命周期阶段" }];
  }

  const peak = points.reduce((best, item) => {
    if (item.comments !== best.comments) return item.comments > best.comments ? item : best;
    return item.heat > best.heat ? item : best;
  }, points[0]);
  const first = points[0];
  const last = points[points.length - 1];
  const dispute = groups.riskDisputes[0]?.term;
  const rows: EventAnalysis["timeline"] = [];

  if (first.date === peak.date) {
    rows.push({
      time: first.date,
      eventNode: `${eventName}讨论集中出现`,
      dataSignal: `评论量 ${first.comments}，热度指数 ${first.heat}`,
      systemJudgment: first.date === last.date ? "样本集中在单日，不强行拆分多个阶段" : "事件进入集中讨论阶段"
    });
  } else {
    rows.push({
      time: first.date,
      eventNode: `${eventName}进入评论样本`,
      dataSignal: `评论量 ${first.comments}，热度指数 ${first.heat}`,
      systemJudgment: "事件进入可观察状态"
    });
    rows.push({
      time: peak.date,
      eventNode: dispute ? `${dispute}相关讨论达到阶段高点` : "讨论达到阶段峰值",
      dataSignal: `峰值评论量 ${peak.comments}，点赞量 ${peak.likes}，负面占比 ${Math.round(peak.negativeRate * 100)}%`,
      systemJudgment: "传播进入高关注阶段"
    });
  }

  if (last.date !== first.date && last.date !== peak.date) {
    rows.push({
      time: last.date,
      eventNode: "热度进入后续观察",
      dataSignal: `评论量 ${last.comments}，热度指数 ${last.heat}`,
      systemJudgment: stage
    });
  }

  return rows;
}

function keywordOverlap(a: string[], b: string[]) {
  const left = new Set(a);
  const right = new Set(b);
  const overlap = [...left].filter((item) => right.has(item)).length;
  return overlap / Math.max(Math.min(left.size, right.size), 1);
}

function normalizeTopicName(name: string) {
  return name
    .replace(/\s+/g, "")
    .replace(/[，,。；;：:"“”'‘’（）()【】\[\]<>《》]/g, "")
    .trim();
}

function mergeTopicRisk(left?: "低" | "中" | "高", right?: "低" | "中" | "高") {
  if (left === "高" || right === "高") return "高";
  if (left === "中" || right === "中") return "中";
  return "低";
}

function mergeTopicSentiment(left?: "正面" | "中性" | "负面" | "分化", right?: "正面" | "中性" | "负面" | "分化") {
  if (!left) return right;
  if (!right) return left;
  return left === right ? left : "分化";
}

export function enrichTopics(topics: TopicItem[]) {
  const totalSize = Math.max(topics.reduce((sum, topic) => sum + topic.size, 0), 1);
  const merged: TopicItem[] = [];
  for (const topic of topics.map(enrichTopic).sort((a, b) => b.size - a.size)) {
    const topicName = normalizeTopicName(topic.name);
    const target = merged.find((item) => {
      const itemName = normalizeTopicName(item.name);
      return itemName === topicName || keywordOverlap(item.keywords, topic.keywords) >= 0.7;
    });
    if (!target) {
      merged.push({ ...topic, topicId: merged.length });
      continue;
    }
    target.size += topic.size;
    target.keywords = [...new Set([...target.keywords, ...topic.keywords])].slice(0, 10);
    target.representativeTexts = [...new Set([...target.representativeTexts, ...topic.representativeTexts])].slice(0, 5);
    target.sentimentTendency = mergeTopicSentiment(target.sentimentTendency, topic.sentimentTendency);
    target.riskLevel = mergeTopicRisk(target.riskLevel, topic.riskLevel);
    target.judgment = target.riskLevel === topic.riskLevel ? target.judgment : topicJudgment(target, target.name, target.riskLevel, target.sentimentTendency === "正面", target.sentimentTendency === "负面");
  }
  return merged
    .map((topic, index) => ({
      ...topic,
      topicId: index,
      percentage: Number(((topic.size / totalSize) * 100).toFixed(1))
    }))
    .sort((a, b) => b.size - a.size)
    .map((topic, index) => ({ ...topic, topicId: index }));
}

function buildRuleDynamicFields(event: {
  category: string;
  eventType: string;
  subjects: string[];
  coreIssues: string[];
  stage: string;
  brief: EventAnalysis["brief"];
}): EventAnalysis["dynamicFields"] {
  const fields: EventAnalysis["dynamicFields"] = [
    { label: "事件类别", value: event.category, confidence: "中" },
    { label: "事件类型", value: event.eventType, confidence: "中" },
    { label: "参与主体", value: event.subjects.join("、"), confidence: "中" },
    { label: "核心议题", value: event.coreIssues.join("、"), confidence: "中" },
    { label: "样本阶段", value: event.stage, confidence: "中" },
    { label: "时间", value: event.brief.when || "", confidence: "中" },
    { label: "地点", value: event.brief.where || "", confidence: "中" }
  ];
  return fields.filter((item) => item.value);
}

export function buildEventAnalysis(input: {
  records: OpinionRecord[];
  eventMaterial?: string;
  keywords: Array<{ word: string; count: number }>;
  sentiment: SentimentSummary;
  trend: TrendPoint[];
  dashboard: DashboardData;
  topics: TopicItem[];
}): EventAnalysis {
  const { records, eventMaterial, keywords, sentiment, trend, dashboard, topics } = input;
  const text = allText(records, eventMaterial);
  const domain = inferDomain(text, dashboard);
  const used = new Set<string>();
  const subjectRuleSet = domain === "diplomatic" ? diplomaticSubjectRules : subjectRules;
  const subjects = extractItems(records, subjectRuleSet, 8);
  subjects.forEach((item) => used.add(item.term));
  const culturalValues = (domain === "cultural_consumer" || domain === "cultural_public") ? extractItems(records, culturalRules, 8) : [];
  culturalValues.forEach((item) => used.add(item.term));
  const consumerEvaluations = (domain === "cultural_consumer" || domain === "consumer" || domain === "object_review") ? extractItems(records, consumerRules, 8) : [];
  consumerEvaluations.forEach((item) => used.add(item.term));
  const diplomaticIssues = domain === "diplomatic" ? extractItems(records, diplomaticIssueRules, 8) : [];
  diplomaticIssues.forEach((item) => used.add(item.term));
  const riskDisputes = domain === "diplomatic" ? diplomaticIssues : extractItems(records, riskRules, 8);
  riskDisputes.forEach((item) => used.add(item.term));
  const growthHotspots = growthKeywords(records, keywords).map((word) => ({
    term: word,
    count: keywords.find((item) => item.word === word)?.count || 1,
    examples: records.filter((record) => record.content.includes(word)).slice(0, 2).map((record) => record.content)
  })).filter((item) => item.examples.length > 0);
  growthHotspots.forEach((item) => used.add(item.term));
  if (!subjects.length) subjects.push(...topKeywordsAsItems(records, keywords, used, 3));

  const keywordGroups = { eventSubjects: subjects, culturalValues, consumerEvaluations, riskDisputes, growthHotspots };
  const name = inferEventName(records, dashboard, keywords, eventMaterial);
  const category = inferCategory(domain);
  const eventType = inferEventType(domain, sentiment, keywordGroups);
  const stage = inferStage(trend, dashboard);
  const subjectTerms = uniqueActors(subjects.map((item) => item.term), 4);
  const coreIssues = (domain === "diplomatic"
    ? diplomaticIssues
    : riskDisputes.length
      ? riskDisputes
      : [...consumerEvaluations, ...culturalValues]
  ).slice(0, 5).map((item) => item.term);
  const prediction = buildPrediction(records, trend, sentiment, keywordGroups, dashboard, keywords);
  const topicNames = topics.slice(0, 3).map((topic) => topic.name).join("、") || keywords.slice(0, 3).map((item) => item.word).join("、");
  const materialExcerpt = compactText(eventMaterial).slice(0, 180);
  const brief = buildEventBrief(eventMaterial, name, subjects, coreIssues);
  const explicitRiskTerms = riskDisputes.filter((item) => item.tone === "negative").map((item) => item.term);
  const focusTerms = explicitRiskTerms.length ? explicitRiskTerms : coreIssues;
  const dynamicFields = buildRuleDynamicFields({ category, eventType, subjects: subjectTerms, coreIssues, stage, brief });
  const primaryTarget = domain === "diplomatic"
    ? "事件相关主体"
    : domain === "cultural_public"
      ? "文化传播主体"
      : domain === "cultural_consumer"
        ? "相关品牌或机构"
        : "相关主体";
  const contentAdvice = domain === "cultural_public"
    ? "围绕文化来源、地域脉络、表演形式与传承价值补充说明，帮助公众理解具体文化语境。"
    : domain === "cultural_consumer"
      ? "强化文化背景、工艺过程和真实体验叙事，同时回应数据中已经出现的具体消费疑问。"
      : culturalValues.length
        ? "补充文化背景和真实体验叙事，避免只停留在口号式传播。"
        : "用更清晰的事实链路解释事件经过和主体责任。";

  return {
    name,
    category,
    eventType,
    subjects: subjectTerms,
    coreIssues,
    stage,
    summary: `本次分析围绕“${name}”展开。${brief.what || (materialExcerpt ? `事件材料显示：${materialExcerpt}` : "系统主要依据上传评论数据识别事件线索。")}${topicNames ? `评论样本关注点主要集中在${topicNames}等方面。` : ""}`,
    materialExcerpt,
    brief,
    dynamicFields,
    recognitionMode: "rules",
    keywordGroups,
    sentimentDrivers: buildSentimentDrivers(keywordGroups, sentiment),
    prediction,
    timeline: buildTimelineInsights(trend, name, stage, keywordGroups),
    opportunities: [
      culturalValues.length ? "文化审美与价值认同可转化为正向传播资产" : "高频正向表达可作为后续沟通切入点",
      "高互动评论可用于识别用户真实需求和内容优化方向",
      growthHotspots.length ? `增长热点词“${growthHotspots.slice(0, 3).map((item) => item.term).join("、")}”可作为后续内容观察方向` : "长尾阶段仍可观察新议题是否出现"
    ],
    risks: [
      explicitRiskTerms.length
        ? `风险表达集中在${explicitRiskTerms.slice(0, 4).join("、")}`
        : focusTerms.length
          ? `核心议题集中在${focusTerms.slice(0, 4).join("、")}，需观察是否被争议化传播`
          : "暂未发现集中风险词",
      sentiment.negative >= 0.15 ? "负面情绪占比已具备持续观察价值" : "负面情绪当前不高，但需关注高互动负面评论",
      dashboard.propagationHeat === "高" ? "热度较高时单条争议评论可能被放大" : "低热度阶段仍需关注长尾争议"
    ],
    recommendations: [
      { target: primaryTarget, advice: focusTerms.length ? `围绕${focusTerms.slice(0, 2).join("、")}等具体议题补充事实信息，避免泛泛表态。` : "继续补充事实信息和价值说明，稳定公众理解。" },
      { target: "平台运营方", advice: "关注高互动评论和突然增长词，及时识别二次争议。" },
      { target: "内容传播方", advice: contentAdvice }
    ]
  };
}
