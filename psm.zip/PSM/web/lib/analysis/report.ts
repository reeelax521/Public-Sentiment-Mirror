import type { AnalysisTask, Report, RiskLevel, SentimentLabel, TopicItem, TrendPoint } from "@/lib/types";

const riskLabel: Record<RiskLevel, string> = {
  low: "低风险",
  medium: "中风险",
  high: "较高风险",
  critical: "高风险"
};

const sentimentLabel: Record<SentimentLabel, string> = {
  positive: "正面",
  neutral: "中性",
  negative: "负面"
};

function cleanCell(value: string | number | undefined | null) {
  return String(value ?? "-").replace(/\|/g, "/").replace(/\r?\n/g, " ").trim() || "-";
}

function table(headers: string[], rows: Array<Array<string | number | undefined | null>>) {
  return [
    `| ${headers.map(cleanCell).join(" | ")} |`,
    `| ${headers.map(() => "---").join(" | ")} |`,
    ...rows.map((row) => `| ${row.map(cleanCell).join(" | ")} |`)
  ].join("\n");
}

function percent(value: number) {
  return `${Math.round(value * 100)}%`;
}

function listTerms(items: Array<{ term: string; count: number }> | undefined, limit = 8) {
  return items?.length
    ? items.slice(0, limit).map((item) => `${item.term}（${item.count}）`).join("、")
    : "未识别到明显集中表达";
}

function topIssueTerms(task: AnalysisTask, limit = 8) {
  const fromLexicon = task.lexicon.targets?.map((item) => ({ term: item.term, count: item.count })) || [];
  const fromKeywords = task.keywords.map((item) => ({ term: item.word, count: item.count }));
  return (fromLexicon.length ? fromLexicon : fromKeywords).slice(0, limit);
}

function topIssueText(task: AnalysisTask, limit = 8) {
  const terms = topIssueTerms(task, limit);
  return terms.length ? terms.map((item) => `${item.term}（${item.count}）`).join("、") : "暂无明显高频议题词";
}

function timeRange(task: AnalysisTask) {
  if (!task.trend.length) return "未识别到明确时间范围";
  return `${task.trend[0].date} 至 ${task.trend[task.trend.length - 1].date}`;
}

function dominantSentiment(task: AnalysisTask) {
  const entries: Array<[SentimentLabel, number]> = [
    ["positive", task.sentiment.positive],
    ["neutral", task.sentiment.neutral],
    ["negative", task.sentiment.negative]
  ];
  return entries.sort((a, b) => b[1] - a[1])[0];
}

function topicRows(topics: TopicItem[]) {
  if (!topics.length) {
    return [["基础主题摘要", 0, "0%", "暂无", "样本较少或模型服务未返回主题"]];
  }

  return topics.slice(0, 8).map((topic) => [
    topic.name,
    topic.size,
    `${topic.percentage.toFixed(1)}%`,
    topic.keywords.slice(0, 8).join("、") || "暂无",
    topic.representativeTexts.slice(0, 2).join(" / ") || "暂无代表评论"
  ]);
}

function platformRows(task: AnalysisTask) {
  const total = Math.max(task.clean.validCount, 1);
  return task.dashboard.platformDistribution.map((item) => [
    item.platform,
    item.count,
    `${Math.round((item.count / total) * 100)}%`
  ]);
}

function objectRows(task: AnalysisTask) {
  const total = Math.max(task.clean.validCount, 1);
  return task.dashboard.objectDistribution.map((item) => [
    item.objectName,
    item.objectAlias || "-",
    item.count,
    `${Math.round((item.count / total) * 100)}%`
  ]);
}

function platformChartNarrative(task: AnalysisTask) {
  const platforms = [...task.dashboard.platformDistribution].sort((a, b) => b.count - a.count);
  if (!platforms.length) return "当前数据未提供明确平台字段，因此报告不生成平台来源图，避免把文件名或对象名误判为平台。";
  const total = Math.max(platforms.reduce((sum, item) => sum + item.count, 0), 1);
  const primary = platforms[0];
  const primaryRate = Math.round((primary.count / total) * 100);
  const rest = platforms.slice(1, 4).map((item) => `${item.platform}${Math.round((item.count / total) * 100)}%`).join("、");
  return `平台来源图显示，${primary.platform}占比最高，为 ${primary.count} 条（约 ${primaryRate}%）${rest ? `；其他主要来源包括 ${rest}` : ""}。该图用于判断样本来源是否均衡：若单一平台占比过高，报告结论应主要解释该平台评论区的表达，不宜直接外推为全网舆情。`;
}

function wordCloudNarrative(task: AnalysisTask) {
  const top = task.keywords.slice(0, 8);
  if (!top.length) return "词云图未识别到稳定高频词，因此报告不强行生成热点词判断。";
  const primary = top.slice(0, 3).map((item) => `“${item.word}”`).join("、");
  const secondary = top.slice(3, 8).map((item) => item.word).join("、");
  return `词云图用于观察公众首先把事件和哪些词联系在一起。当前居中的高频词为 ${primary}${secondary ? `，外围词包括 ${secondary}` : ""}。如果居中词主要是产品、主体或事件名，说明讨论仍围绕事件本身；如果风险词、质疑词或负面体验词逐渐靠前，则意味着讨论焦点可能从关注热度转向争议解释。`;
}

function keywordBarNarrative(task: AnalysisTask) {
  const top = task.keywords.slice(0, 5);
  if (!top.length) return "关键词排行未形成可解释的集中词。";
  const topText = top.map((item) => `${item.word}${item.count}`).join("、");
  return `关键词排行图补充了词云的定量信息，显示前五个关键词为 ${topText}。词云强调视觉权重，柱状图则用于核对具体频次，因此两者需要合并阅读：既看哪些词突出，也看突出程度是否显著高于其他词。`;
}

function sentimentChartNarrative(task: AnalysisTask) {
  const [dominant, value] = dominantSentiment(task);
  return `情感分布图显示，当前${sentimentLabel[dominant]}表达占比最高，为 ${percent(value)}；正面 ${percent(task.sentiment.positive)}、中性 ${percent(task.sentiment.neutral)}、负面 ${percent(task.sentiment.negative)}。该图用于判断评论氛围，但不能脱离代表评论理解：中性比例高可能来自事实陈述或信息补充，正面比例高通常意味着认可和传播意愿更强，负面比例高才需要进一步定位具体原因。`;
}

function topicDistributionNarrative(topics: TopicItem[]) {
  if (!topics.length) return "主题分布图未形成稳定主题，当前报告以关键词、情感和代表评论作为主要解释依据。";
  const sorted = [...topics].sort((a, b) => b.size - a.size);
  const primary = sorted[0];
  const secondary = sorted.slice(1, 4).map((topic) => `“${topic.name}”${topic.percentage.toFixed(1)}%`).join("、");
  const concentration = primary.percentage >= 60
    ? "高度集中"
    : primary.percentage >= 35
      ? "相对集中"
      : "较为分散";
  return `主题分布图显示，当前讨论${concentration}，最大主题为“${primary.name}”，占比 ${primary.percentage.toFixed(1)}%。${secondary ? `次级主题包括 ${secondary}。` : ""}需要注意，主题占比代表样本内部讨论结构，不等同于风险等级；只有负面表达、较高互动和争议词同时集中时，才应进入高风险判断。`;
}

function riskRadarNarrative(task: AnalysisTask) {
  if (!task.dashboard.riskRadar.length) return "当前数据不足以形成风险雷达图，报告不强行给出结构化风险图。";
  const sorted = [...task.dashboard.riskRadar].sort((a, b) => b.value - a.value);
  const top = sorted.slice(0, 3).map((item) => `${item.metric}${item.value}`).join("、");
  return `风险雷达图将风险拆分为多个维度，而不是用单一“中风险/高风险”概括。当前较突出的维度为 ${top}。其中传播热度或点赞集中度较高，只说明事件被看见、被互动；真正的高风险通常来自负面率、负面高热评论、事实争议和极端表达的叠加。`;
}

function dashboardMetricRows(task: AnalysisTask) {
  return [
    ["总文本数", task.clean.originalCount],
    ["有效文本数", task.clean.validCount],
    ["主要平台", task.dashboard.majorPlatform || "未识别"],
    ["样本时间范围", timeRange(task)],
    ["热度指数", task.dashboard.heatIndex],
    ["负面率", percent(task.sentiment.negative)],
    ["最大主题", task.nlp?.topics?.[0]?.name || "未形成稳定主题"],
    ["当前阶段", task.event.stage || task.dashboard.overallStatus]
  ];
}

function issuePhrase(task: AnalysisTask) {
  const terms = topIssueTerms(task, 5).map((item) => item.term);
  return terms.length ? `“${terms.join("”“")}”` : "高频议题词";
}

function sourceNarrative(task: AnalysisTask) {
  const mapping = task.dataset.fieldMapping;
  const hasPlatform = Boolean(mapping.platformField || mapping.staticPlatform || task.dashboard.platformDistribution.length);
  const contentField = mapping.textField || "未识别";
  const timeField = mapping.timeField || "未识别";
  const platformField = mapping.platformField || mapping.staticPlatform || "无";
  const userField = mapping.userField || mapping.userIdField || "无";
  const likeField = mapping.likeField || "无";

  const sourcePart = hasPlatform
    ? `本次数据主要来源于${task.dashboard.majorPlatform || "已识别平台"}评论数据，系统识别 ${contentField} 为文本内容字段，${timeField} 为发布时间字段，${platformField} 为平台字段，${userField} 为用户字段，${likeField} 为互动字段。`
    : `本次数据未提供明确平台字段，系统识别 ${contentField} 为文本内容字段，${timeField} 为发布时间字段，${userField} 为用户字段，${likeField} 为互动字段，并按通用评论文本进行分析。`;

  const objectPart = mapping.objectField
    ? `原始数据提供了 ${mapping.objectField} 作为分析对象字段，因此报告可结合对象分布观察评论集中度。`
    : "原始数据未提供明确分析对象字段，因此本报告不进行对象级立场判断，主要围绕评论文本中的高频议题词、情感倾向、主题聚类和热度变化展开。";

  return `${sourcePart}${objectPart}`;
}

function cleaningNarrative(task: AnalysisTask) {
  const clean = task.clean;
  const lowQualityTotal = clean.tooShortCount + clean.lowQualityCount + clean.semanticAnomalyCount;
  const qualityPart = lowQualityTotal > 0
    ? `样本中另识别出 ${clean.tooShortCount} 条过短文本、${clean.lowQualityCount} 条低质量文本和 ${clean.semanticAnomalyCount} 条语义异常文本。这些文本仍可作为热度和整体情绪方向的参考，但不宜被过度解释为明确观点。`
    : "样本中未发现明显集中的过短、低质量或语义异常文本，整体文本质量较为稳定。";
  const missingPart = clean.quality.issues.length
    ? `缺失值处理方面，系统仅删除评论内容为空的记录；发布时间、平台、点赞、评分、用户等可选字段缺失时采用降级策略，并在后续图表和结论中标注影响范围。当前元数据完整度为 ${clean.quality.completenessScore}%。`
    : `当前样本未检测到明显字段缺失，元数据完整度为 ${clean.quality.completenessScore}%。`;

  return `原始数据共 ${clean.originalCount} 条，清洗后去除重复文本 ${clean.duplicateCount} 条、空文本 ${clean.emptyCount} 条，最终保留有效样本 ${clean.validCount} 条。${qualityPart}${missingPart}`;
}

function qualityRows(task: AnalysisTask) {
  return task.clean.quality.issues.length
    ? task.clean.quality.issues.map((item) => [
      item.label,
      item.count,
      `${item.rate}%`,
      item.impact
    ])
    : [["缺失值检测", 0, "0%", "未发现明显字段缺失"]];
}

function keywordNarrative(task: AnalysisTask) {
  const issue = topIssueTerms(task, 6).map((item) => item.term);
  const emotions = task.lexicon.emotions?.slice(0, 6).map((item) => item.term) || [];
  const stances = task.lexicon.stances?.slice(0, 6).map((item) => item.term) || [];

  const issueText = issue.length
    ? `高频议题词集中在“${issue.join("”“")}”等方面，说明评论讨论主要围绕这些词汇所指向的公共议题、态度表达或事件线索展开。`
    : "当前样本未形成特别集中的高频议题词，说明讨论较为分散。";
  const emotionText = emotions.length
    ? `情绪倾向词以“${emotions.join("”“")}”等表达为主，可用于观察评论区情绪氛围的方向。`
    : "情绪倾向词不明显，说明文本更多是事实陈述、简短回应或低情绪强度表达。";
  const stanceText = stances.length
    ? `立场表达词包括“${stances.join("”“")}”等，反映出部分评论在支持、期待、质疑或建议等方向上的态度。`
    : "未识别到明显立场表达词，因此不宜强行判断清晰的支持或反对阵营。";

  return `${issueText}${emotionText}${stanceText}`;
}

function sentimentNarrative(task: AnalysisTask) {
  const [dominant, value] = dominantSentiment(task);
  const negativeRate = task.sentiment.negative;
  const riskText = negativeRate < 0.1
    ? "负面占比较低，尚未形成明显负面扩散。"
    : negativeRate < 0.25
      ? "负面表达存在一定占比，需要观察是否继续扩散。"
      : "负面表达占比较高，需要重点关注其传播范围和主题指向。";

  const dominantText = dominant === "neutral"
    ? "中性评论占比最高，常见于新闻评论中的事实判断、简短表态和观望性表达。"
    : dominant === "positive"
      ? "正面评论占比最高，说明样本中认可、期待或支持性表达更集中。"
      : "负面评论占比最高，说明样本中不满、质疑或担忧表达较为突出。";

  return `情感分析依据为：${task.sentiment.basis}。结果显示，${sentimentLabel[dominant]}评论占比最高，为 ${percent(value)}。${dominantText}${riskText}`;
}

function longTailNarrative(topics: TopicItem[]) {
  const longTail = topics.find((topic) => /长尾|其他|短文本|低信息/.test(topic.name));
  if (!longTail) return "";
  return `其中“${longTail.name}”占比 ${longTail.percentage.toFixed(1)}%，说明样本中存在一定比例的短文本、泛化表达或低频议题。这类内容虽然难以形成单一清晰主题，但仍有助于判断整体热度和情绪氛围。`;
}

function topicNarrative(topics: TopicItem[]) {
  if (!topics.length) {
    return "当前样本未形成稳定主题聚类，报告暂以关键词和情感结构作为主要解释依据。";
  }

  const primary = topics[0];
  const names = topics.slice(0, 4).map((topic) => `“${topic.name}”`).join("、");
  const tail = longTailNarrative(topics);
  return `主题聚类主要用于回答“大家讨论了哪些议题”。本次较突出的主题包括 ${names}，其中“${primary.name}”规模最大，占比 ${primary.percentage.toFixed(1)}%。${tail}当前报告将主题标签与语义相近评论组合并呈现，避免重复展示同一组聚类结果。`;
}

function trendFeature(point: TrendPoint, peak: TrendPoint, index: number, length: number) {
  if (point.date === peak.date) return "评论集中出现，讨论达到阶段峰值";
  if (index === 0) return "讨论开始出现，形成初始样本";
  if (index === length - 1 && point.heat < peak.heat) return "峰值后热度回落，进入长尾讨论";
  if (point.heat > peak.heat * 0.65) return "热度保持较高，讨论仍在延续";
  return "热度处于较低水平，讨论相对分散";
}

function trendRows(task: AnalysisTask) {
  if (!task.trend.length) return [["-", "-", "-", "-", "未识别到有效时间序列"]];

  const peak = task.trend.reduce((best, item) => (item.heat > best.heat ? item : best), task.trend[0]);
  const rows = task.trend.map((point, index) => [
    point.date,
    point.comments,
    point.likes,
    point.heat,
    trendFeature(point, peak, index, task.trend.length)
  ]);

  if (rows.length <= 12) return rows;

  const head = rows.slice(0, 5);
  const peakRow = rows.find((row) => row[0] === peak.date);
  const tail = rows.slice(-5);
  const merged = peakRow ? [...head, peakRow, ...tail] : [...head, ...tail];
  return merged.filter((row, index, arr) => arr.findIndex((item) => item[0] === row[0]) === index);
}

function trendNarrative(task: AnalysisTask) {
  if (!task.trend.length) {
    return `当前数据未识别到可用发布时间，系统不会自动伪造日期，因此热度趋势和事件时间轴降级处理。报告仍保留关键词、情感、主题和风险研判，但不输出日期峰值结论。`;
  }
  const dates = new Set(task.trend.map((point) => point.date));
  const granularity = dates.size <= 3
    ? "当前数据时间粒度较粗，报告按日期展示热度变化，不强行拆分为多个舆情生命周期阶段。"
    : "当前数据可形成连续日期趋势，报告按日期聚合展示热度变化。";

  return `${granularity}峰值评论量为 ${task.dashboard.peakCommentCount}，峰值点赞量为 ${task.dashboard.peakLikeCount}，热度指数为 ${task.dashboard.heatIndex}。相对起始阶段增长率为 ${task.dashboard.relativeGrowthRate}%，该指标只表示趋势变化；若起始阶段评论量较低，增长率可能偏高，不等同于绝对传播规模。`;
}

function countHits(task: AnalysisTask, terms: string[]) {
  const text = task.clean.records.map((record) => record.content).join("\n");
  return terms.reduce((sum, term) => sum + (text.match(new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"))?.length || 0), 0);
}

function levelFromCount(count: number, total: number) {
  const ratio = total ? count / total : 0;
  if (ratio >= 0.1) return "高";
  if (ratio >= 0.03) return "中";
  return "低";
}

function topicConcentration(topics: TopicItem[]) {
  const maxTopic = topics[0];
  if (!maxTopic) return { level: "低", basis: "未形成明显集中主题" };
  if (maxTopic.percentage >= 50) return { level: "高", basis: `最大主题“${maxTopic.name}”占比 ${maxTopic.percentage.toFixed(1)}%` };
  if (maxTopic.percentage >= 25) return { level: "中", basis: `最大主题“${maxTopic.name}”占比 ${maxTopic.percentage.toFixed(1)}%` };
  return { level: "低", basis: `最大主题“${maxTopic.name}”占比 ${maxTopic.percentage.toFixed(1)}%` };
}

function riskRows(task: AnalysisTask, topics: TopicItem[]) {
  const total = Math.max(task.clean.validCount, 1);
  const concentration = topicConcentration(topics);
  const uncertaintyCount = countHits(task, ["网传", "求证", "真假", "不明", "未证实", "谣言", "听说", "据说"]);
  const extremeCount = countHits(task, ["攻击", "抵制", "封杀", "造谣", "恶心", "垃圾", "滚", "骂"]);

  return [
    ["传播热度", task.dashboard.propagationHeat, `峰值日热度指数为 ${task.dashboard.heatIndex}，峰值评论量为 ${task.dashboard.peakCommentCount}`],
    ["负面情绪", task.dashboard.negativeRisk, `负面占比为 ${percent(task.sentiment.negative)}`],
    ["主题集中度", concentration.level, concentration.basis],
    ["信息不确定性", levelFromCount(uncertaintyCount, total), `样本中识别到 ${uncertaintyCount} 次不确定性表达`],
    ["极端表达", levelFromCount(extremeCount, total), `样本中识别到 ${extremeCount} 次攻击性或极端表达`]
  ];
}

function riskNarrative(task: AnalysisTask, topics: TopicItem[]) {
  const concentration = topicConcentration(topics);
  return `综合判断不是只看单一“风险等级”，而是拆分为传播热度、负面情绪、主题集中度、信息不确定性和极端表达。当前传播热度为${task.dashboard.propagationHeat}，负面风险为${task.dashboard.negativeRisk}，主题集中度为${concentration.level}，综合状态为“${task.dashboard.overallStatus}”。`;
}

function usefulReportValue(value: string | number | undefined | null) {
  const text = String(value ?? "").trim();
  return Boolean(text) && !["无", "未知", "未识别", "未见集中争议", "时间信息不足"].includes(text);
}

function eventOverviewRows(task: AnalysisTask) {
  const event = task.event;
  const dynamicRows = event.dynamicFields?.map((item) => [
    item.label,
    item.evidence ? `${item.value}（依据：${item.evidence}）` : item.value
  ]) || [];
  if (dynamicRows.length) {
    return [
      ["事件名称", event.name],
      ["事件梗概", event.brief?.what],
      ...dynamicRows
    ].filter(([, value]) => usefulReportValue(value));
  }
  return [
    ["事件名称", event.name],
    ["事件梗概", event.brief?.what],
    ["时间", event.brief?.when],
    ["地点", event.brief?.where],
    ["参与主体", event.brief?.who?.join("、")],
    ["事件类别", event.category],
    ["事件类型", event.eventType],
    ["核心主体", event.subjects.join("、")],
    ["核心议题", event.coreIssues.join("、")],
    ["样本阶段", event.stage]
  ].filter(([, value]) => usefulReportValue(value));
}

function eventKeywordRows(task: AnalysisTask) {
  const groups = task.event.keywordGroups;
  const isDiplomatic = task.event.category.includes("外交");
  return [
    ["事件主体词", listTerms(groups.eventSubjects)],
    [isDiplomatic ? "关系与议题词" : "文化价值词", listTerms(groups.culturalValues)],
    [isDiplomatic ? "互动反馈词" : "消费评价词", listTerms(groups.consumerEvaluations)],
    [isDiplomatic ? "核心议题词" : "风险争议词", listTerms(groups.riskDisputes)],
    ["增长热点词", listTerms(groups.growthHotspots)]
  ].filter(([, value]) => !String(value).includes("未识别到明显集中表达"));
}

function sentimentDriverRows(task: AnalysisTask) {
  return task.event.sentimentDrivers.map((item) => [
    item.label,
    item.reasons.join("、") || "未形成集中原因",
    item.representativeExpressions[0] || "暂无代表表达"
  ]);
}

function predictionRows(task: AnalysisTask) {
  const prediction = task.event.prediction;
  return [
    ["近3日热度斜率", prediction.heatSlope],
    ["近3日负面占比变化", prediction.negativeChange],
    ["样本内增长词", prediction.growthKeywords.join("、") || "未识别到可靠增长词"],
    ["预测结果", prediction.result]
  ];
}

function eventTimelineRows(task: AnalysisTask) {
  return task.event.timeline.map((item) => [
    item.time,
    item.eventNode,
    item.dataSignal,
    item.systemJudgment
  ]);
}

function opportunityRiskRows(task: AnalysisTask) {
  const max = Math.max(task.event.risks.length, task.event.opportunities.length);
  return Array.from({ length: max }).map((_, index) => [
    task.event.risks[index] || "",
    task.event.opportunities[index] || ""
  ]);
}

function recommendationRows(task: AnalysisTask) {
  return task.event.recommendations.map((item) => [item.target, item.advice]);
}

function limitationNarrative(task: AnalysisTask) {
  const platformCount = task.dashboard.platformDistribution.length;
  const platformLimit = platformCount <= 1
    ? "本次样本来源较集中，结论主要反映当前数据源评论区的阶段性表达，不宜直接外推为全网舆情。"
    : `本次样本覆盖 ${platformCount} 个来源平台，可用于观察跨平台差异，但仍需结合采集范围判断代表性。`;
  const fieldLimit = task.dataset.fieldMapping.objectField
    ? "原始数据提供了分析对象字段，因此可以进行对象分布观察。"
    : "原始数据未提供明确分析对象字段，因此报告重点解释议题、情绪和主题，不做对象级立场归因。";

  return `${platformLimit}${fieldLimit}`;
}

function buildPublicReport(task: AnalysisTask) {
  const topics = task.nlp?.topics || [];
  const hasPlatform = task.dashboard.platformDistribution.length > 0;
  const objects = objectRows(task);
  const trendConclusion = task.trend.length
    ? `热度峰值出现在 ${task.dashboard.peakTime || "未识别"}，当前综合状态可概括为：${task.dashboard.overallStatus}。`
    : `当前数据未提供可用发布时间，系统已降级处理趋势与时间轴，不输出伪造峰值结论；综合状态可概括为：${task.dashboard.overallStatus}。`;

  return `# ${task.event.name}舆情研判报告

## 一、事件概览
本次分析围绕“${task.event.name}”展开。${task.event.summary}

${table(["项目", "识别结果"], eventOverviewRows(task))}

## 二、数据来源与样本范围
${sourceNarrative(task)}

本次原始文本共 ${task.clean.originalCount} 条，经去重与清洗后得到有效样本 ${task.clean.validCount} 条，样本时间范围为 ${timeRange(task)}。${limitationNarrative(task)}

${table(["字段含义", "识别结果"], [
  ["内容字段", task.dataset.fieldMapping.textField || "未识别"],
  ["发布时间字段", task.dataset.fieldMapping.timeField || "未识别"],
  ["平台字段", task.dataset.fieldMapping.platformField || task.dataset.fieldMapping.staticPlatform || "无"],
  ["用户字段", task.dataset.fieldMapping.userField || task.dataset.fieldMapping.userIdField || "无"],
  ["互动字段", task.dataset.fieldMapping.likeField || "无"],
  ["分析对象字段", task.dataset.fieldMapping.objectField || "无"],
  ["来源链接字段", task.dataset.fieldMapping.sourceUrlField || "无"]
])}

${hasPlatform ? table(["平台", "文本数量", "占比"], platformRows(task)) : "当前数据没有明确平台字段，后续页面和报告不展示平台来源构成。"}

${platformChartNarrative(task)}

${objects.length ? `评论对象构成：\n${table(["对象", "别名", "文本数量", "占比"], objects)}` : ""}

## 三、综合仪表盘解读
综合仪表盘用于先回答“这件事现在处在什么状态”。整体来看，本次讨论热度为${task.dashboard.propagationHeat}，情感结构以${sentimentLabel[dominantSentiment(task)[0]]}表达为主，其中正面评论占 ${percent(task.sentiment.positive)}，中性评论占 ${percent(task.sentiment.neutral)}，负面评论占 ${percent(task.sentiment.negative)}。${trendConclusion}

${table(["指标", "当前结果"], dashboardMetricRows(task))}

这一页的图表需要组合阅读：平台来源图解释样本从哪里来，词云和关键词排行解释公众在谈什么，情感分布解释评论氛围，主题分布解释议题结构，热度趋势解释时间变化。风险雷达不在此处直接下结论，而在后文结合负面情绪、互动热度和主题集中度单独研判。

## 四、数据清洗与样本质量
${table(["项目", "数量"], [
  ["原始文本", task.clean.originalCount],
  ["重复文本", task.clean.duplicateCount],
  ["空文本", task.clean.emptyCount],
  ["有效样本", task.clean.validCount],
  ["过短文本", task.clean.tooShortCount],
  ["低质量文本", task.clean.lowQualityCount],
  ["语义异常文本", task.clean.semanticAnomalyCount],
  ["元数据完整度", `${task.clean.quality.completenessScore}%`]
])}

${table(["缺失项", "数量", "占比", "处理方式与影响"], qualityRows(task))}

${cleaningNarrative(task)}

## 五、公众关注焦点与词云解读
${table(["线索类型", "识别结果"], eventKeywordRows(task))}

${wordCloudNarrative(task)}

${keywordBarNarrative(task)}

${keywordNarrative(task)}

## 六、情感与立场分析
${table(["情感类型", "占比"], [
  [sentimentLabel.positive, percent(task.sentiment.positive)],
  [sentimentLabel.neutral, percent(task.sentiment.neutral)],
  [sentimentLabel.negative, percent(task.sentiment.negative)]
])}

${table(["情感类型", "主要原因", "代表表达"], sentimentDriverRows(task))}

${sentimentChartNarrative(task)}

${sentimentNarrative(task)}

## 七、主题与观点聚类
${table(["主题", "规模", "占比", "关键词", "代表评论"], topicRows(topics))}

${topicNarrative(topics)}

${topicDistributionNarrative(topics)}

## 八、事件演化与热度趋势
${table(["时间", "事件节点", "数据表现", "系统判断"], eventTimelineRows(task))}

${table(["日期", "评论量", "点赞量", "热度指数", "主要特征"], trendRows(task))}

${trendNarrative(task)}

## 九、短期趋势辅助判断
${table(["指标", "判断"], predictionRows(task))}

${task.event.prediction.basis}${task.event.prediction.advice}

## 十、风险研判依据
${table(["风险维度", "当前判断", "依据"], riskRows(task, topics))}

${riskRadarNarrative(task)}

${riskNarrative(task, topics)}

## 十一、风险点与机会点
${table(["风险点", "机会点"], opportunityRiskRows(task))}

## 十二、应对建议
${table(["对象", "建议"], recommendationRows(task))}

## 十三、总结
综合来看，本次“${task.event.name}”相关讨论呈现出“${task.dashboard.propagationHeat === "高" ? "热度集中" : "热度可观察"}、情绪${task.dashboard.negativeRisk === "低" ? "整体平稳" : "需要持续关注"}、议题围绕 ${issuePhrase(task)} 展开”的特征。结合事件材料，公众关注并不只停留在数据量变化，而是集中到事件本身涉及的主体、体验、传播效果和潜在争议上：${task.event.summary}

从风险角度看，当前负面表达比例为 ${percent(task.sentiment.negative)}，${task.sentiment.negative < 0.1 ? "尚未形成明显负面情绪压力" : "已有一定负面压力，需要结合高互动评论继续判断"}。后续观察重点包括：一是负面评论比例是否上升；二是高互动评论是否改变讨论方向；三是峰值后的长尾讨论是否出现新的争议点；四是补充更多平台数据后，当前主题结构和情感结构是否仍然稳定。`;
}

function buildObjectReviewReport(task: AnalysisTask) {
  const topics = task.nlp?.topics || [];
  const objectName = task.dashboard.objectName || "评论对象";
  const alias = task.dashboard.objectAlias ? `（${task.dashboard.objectAlias}）` : "";

  return `# ${objectName}${alias} 评论分析报告

## 一、核心结论
本次分析对象为“${objectName}”，原始文本共 ${task.clean.originalCount} 条，经去重与清洗后得到有效评论 ${task.clean.validCount} 条，时间范围为 ${timeRange(task)}。平均评分为 ${task.dashboard.ratingAverage ?? "暂无"}，总点赞数为 ${task.dashboard.totalLikes}，情感分析依据为：${task.sentiment.basis}。

整体来看，评论热度为${task.dashboard.propagationHeat}，负面风险为${task.dashboard.negativeRisk}，综合状态为“${task.dashboard.overallStatus}”。评论重点主要围绕 ${issuePhrase(task)} 等方面展开。

## 二、数据来源与字段识别
${sourceNarrative(task)}

${table(["字段含义", "识别结果"], [
  ["评论内容", task.dataset.fieldMapping.textField || "未识别"],
  ["评论时间", task.dataset.fieldMapping.timeField || "未识别"],
  ["评分字段", task.dataset.fieldMapping.ratingField || "无"],
  ["点赞字段", task.dataset.fieldMapping.likeField || "无"],
  ["用户字段", task.dataset.fieldMapping.userField || task.dataset.fieldMapping.userIdField || "无"],
  ["分析对象字段", task.dataset.fieldMapping.objectField || "无"],
  ["对象别名字段", task.dataset.fieldMapping.objectAliasField || "无"],
  ["采集时间字段", task.dataset.fieldMapping.collectedAtField || "无"]
])}

## 三、数据清洗与样本质量
${table(["项目", "数量"], [
  ["原始评论", task.clean.originalCount],
  ["重复评论", task.clean.duplicateCount],
  ["空文本", task.clean.emptyCount],
  ["有效评论", task.clean.validCount],
  ["过短评论", task.clean.tooShortCount],
  ["低质量评论", task.clean.lowQualityCount],
  ["语义异常评论", task.clean.semanticAnomalyCount],
  ["元数据完整度", `${task.clean.quality.completenessScore}%`]
])}

${table(["缺失项", "数量", "占比", "处理方式与影响"], qualityRows(task))}

${cleaningNarrative(task)}

## 四、关键词与观影表达
${table(["类别", "识别结果"], [
  ["内容对象", listTerms(task.lexicon.contentObjects)],
  ["角色人物", listTerms(task.lexicon.characters)],
  ["观影体验", listTerms(task.lexicon.viewingExperience)],
  ["情绪评价", listTerms(task.lexicon.emotionEvaluations)],
  ["争议焦点", listTerms(task.lexicon.controversyFocus)]
])}

关键词显示，评论主要围绕剧情、角色、特效场面、观影体验和情绪评价展开。若“失望、疲劳、翻译、反派”等词频上升，通常意味着口碑分化或争议焦点正在形成。

## 五、评分与情感倾向
${table(["情感类型", "占比"], [
  [sentimentLabel.positive, percent(task.sentiment.positive)],
  [sentimentLabel.neutral, percent(task.sentiment.neutral)],
  [sentimentLabel.negative, percent(task.sentiment.negative)]
])}

${task.dashboard.ratingDistribution?.length ? table(["评分", "评论数"], task.dashboard.ratingDistribution.map((item) => [item.rating, item.count])) : ""}

${sentimentNarrative(task)}

## 六、主题与观点聚类
${table(["主题", "规模", "占比", "关键词", "代表评论"], topicRows(topics))}

${topicNarrative(topics)}

## 七、热度趋势与时间变化
${table(["日期", "评论量", "点赞量", "热度指数", "主要特征"], trendRows(task))}

${trendNarrative(task)}

## 八、风险研判
${table(["风险维度", "当前判断", "依据"], riskRows(task, topics))}

${riskNarrative(task, topics)}

## 九、总结与后续观察建议
综合来看，“${objectName}”的评论讨论集中在 ${issuePhrase(task)} 等方面。当前负面风险为${task.dashboard.negativeRisk}，后续可继续观察高点赞评论、低评分评论和长尾讨论中是否出现新的争议点。`;
}

function escapeHtml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

export function markdownToHtml(markdown: string) {
  const lines = markdown.split("\n");
  let inTable = false;
  const html: string[] = [];

  for (const line of lines) {
    if (line.startsWith("| ") && line.endsWith(" |")) {
      const cells = line.slice(2, -2).split(" | ").map(escapeHtml);
      if (cells.every((cell) => /^-+$/.test(cell))) continue;
      if (!inTable) {
        html.push("<table>");
        inTable = true;
      }
      const tag = html[html.length - 1] === "<table>" ? "th" : "td";
      html.push(`<tr>${cells.map((cell) => `<${tag}>${cell}</${tag}>`).join("")}</tr>`);
      continue;
    }

    if (inTable) {
      html.push("</table>");
      inTable = false;
    }

    if (line.startsWith("# ")) html.push(`<h1>${escapeHtml(line.slice(2))}</h1>`);
    else if (line.startsWith("## ")) html.push(`<h2>${escapeHtml(line.slice(3))}</h2>`);
    else if (line.startsWith("### ")) html.push(`<h3>${escapeHtml(line.slice(4))}</h3>`);
    else if (line.startsWith("- ")) html.push(`<p>• ${escapeHtml(line.slice(2))}</p>`);
    else if (line.trim()) html.push(`<p>${escapeHtml(line)}</p>`);
  }

  if (inTable) html.push("</table>");
  return html.join("");
}

export function buildReportHtml(markdown: string) {
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>网络舆情分析报告</title><style>body{font-family:Arial,"Microsoft YaHei",sans-serif;line-height:1.75;max-width:900px;margin:40px auto;color:#13223a}h1{font-size:30px;color:#0f355c}h2{margin-top:28px;color:#145c7a}h3{margin-top:20px;color:#1f6f8b}table{border-collapse:collapse;width:100%;margin:12px 0 20px}th,td{border:1px solid #cfd9e8;padding:8px 10px;font-size:13px;vertical-align:top}th{background:#edf7fb}</style></head><body>${markdownToHtml(markdown)}</body></html>`;
}

export function generateReport(task: AnalysisTask): Report {
  const markdown = task.dashboard.sourceMode === "object_review" ? buildObjectReviewReport(task) : buildPublicReport(task);
  const html = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>网络舆情分析报告</title><style>body{font-family:Arial,"Microsoft YaHei",sans-serif;line-height:1.75;max-width:900px;margin:40px auto;color:#13223a}h1{font-size:30px;color:#0f355c}h2{margin-top:28px;color:#145c7a}h3{margin-top:20px;color:#1f6f8b}table{border-collapse:collapse;width:100%;margin:12px 0 20px}th,td{border:1px solid #cfd9e8;padding:8px 10px;font-size:13px;vertical-align:top}th{background:#edf7fb}</style></head><body>${markdownToHtml(markdown)}</body></html>`;

  return {
    id: `report_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    taskId: task.id,
    markdown,
    txt: markdown.replace(/^#+\s/gm, ""),
    html: buildReportHtml(markdown),
    createdAt: new Date().toISOString()
  };
}
