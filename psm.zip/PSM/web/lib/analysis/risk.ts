import type { DashboardData, KeywordItem, LexiconAnalysis, OpinionRecord, RiskLevel, SentimentSummary, TrendPoint } from "@/lib/types";

type StatusLevel = "低" | "中" | "高";

export function getRiskLevel(negativeRate: number, heatIndex: number): RiskLevel {
  if (negativeRate >= 0.35 && heatIndex >= 70) return "critical";
  if (negativeRate >= 0.28 || (negativeRate >= 0.2 && heatIndex >= 75)) return "high";
  if (negativeRate >= 0.14 || (negativeRate >= 0.09 && heatIndex >= 85)) return "medium";
  return "low";
}

function statusByHeat(totalComments: number, peakComments: number, peakLikes: number): StatusLevel {
  if (totalComments >= 500 || peakComments >= 120 || peakLikes >= 1200) return "高";
  if (totalComments >= 120 || peakComments >= 35 || peakLikes >= 180) return "中";
  return "低";
}

function statusByNegative(value: number): StatusLevel {
  if (value >= 0.28) return "高";
  if (value >= 0.12) return "中";
  return "低";
}

function riskLevelByNegativeAndHeat(negativeRate: number, propagationHeat: StatusLevel): RiskLevel {
  const heatScore = propagationHeat === "高" ? 90 : propagationHeat === "中" ? 55 : 25;
  return getRiskLevel(negativeRate, heatScore);
}

function ratingDistribution(records: OpinionRecord[]) {
  const buckets = new Map<string, number>([["1星", 0], ["2星", 0], ["3星", 0], ["4星", 0], ["5星", 0]]);
  let hasRating = false;
  records.forEach((record) => {
    if (!record.rating || record.rating < 1) return;
    hasRating = true;
    const key = `${Math.min(5, Math.max(1, Math.round(record.rating)))}星`;
    buckets.set(key, (buckets.get(key) || 0) + 1);
  });
  if (!hasRating) return [];
  return [...buckets.entries()].map(([rating, count]) => ({ rating, count }));
}

function objectDistribution(records: OpinionRecord[]) {
  const counts = new Map<string, { objectName: string; objectAlias?: string; count: number }>();
  records.forEach((record) => {
    if (!record.objectName) return;
    const row = counts.get(record.objectName) || { objectName: record.objectName, objectAlias: record.objectAlias, count: 0 };
    row.count += 1;
    if (!row.objectAlias && record.objectAlias) row.objectAlias = record.objectAlias;
    counts.set(record.objectName, row);
  });
  return [...counts.values()].sort((a, b) => b.count - a.count);
}

function relativeGrowthRate(trend: TrendPoint[]) {
  if (trend.length < 2) return 0;
  const points = trend.filter((item) => item.heat > 0);
  if (points.length < 2) return 0;
  const peak = points.reduce((best, item) => (item.heat > best.heat ? item : best), points[0]);
  const peakIndex = points.findIndex((item) => item.date === peak.date);
  const beforePeak = points.slice(0, Math.max(peakIndex, 1)).filter((item) => item.date !== peak.date);
  const baselinePool = beforePeak.length ? beforePeak : points.slice(0, Math.max(1, Math.floor(points.length / 3)));
  const sorted = baselinePool.map((item) => item.heat).sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  const median = sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
  const baseline = Math.max(median || 0, 30);
  if (peak.heat <= baseline) return 0;
  return Math.min(200, Math.round(((peak.heat - baseline) / baseline) * 100));
}

function overallStatus(negativeRisk: StatusLevel, propagationHeat: StatusLevel, sourceMode: DashboardData["sourceMode"]) {
  if (negativeRisk === "高" && propagationHeat === "高") return sourceMode === "object_review" ? "高热负面口碑风险" : "高热负面风险";
  if (negativeRisk === "高") return "负面风险需关注";
  if (negativeRisk === "中" && propagationHeat === "高") return "高热争议观察";
  if (propagationHeat === "高") return "高热正向或中性观察";
  if (propagationHeat === "中") return "中等热度观察";
  return "平稳观察";
}

export function buildDashboard(
  records: OpinionRecord[],
  sentiment: SentimentSummary,
  trend: TrendPoint[],
  keywords: KeywordItem[],
  lexicon: LexiconAnalysis
): DashboardData {
  const totalComments = records.length;
  const hasTrend = trend.length > 0;
  const heatIndex = Math.max(...trend.map((item) => item.heat), 0);
  const negativeRate = sentiment.negative;
  const fallbackTrend = { date: hasTrend ? "未知" : "无有效时间", heat: 0, comments: 0, likes: 0, interactions: 0, negativeRate: 0, movingAverage: 0 };
  const peak = trend.reduce((best, item) => (item.heat > best.heat ? item : best), trend[0] || fallbackTrend);
  const peakCommentDay = trend.reduce((best, item) => (item.comments > best.comments ? item : best), trend[0] || fallbackTrend);
  const peakLikeDay = trend.reduce((best, item) => (item.likes > best.likes ? item : best), trend[0] || fallbackTrend);
  const platformCounts = new Map<string, number>();
  records.forEach((record) => {
    if (record.platform) platformCounts.set(record.platform, (platformCounts.get(record.platform) || 0) + 1);
  });
  const platformDistribution = [...platformCounts.entries()]
    .map(([platform, count]) => ({ platform, count }))
    .sort((a, b) => b.count - a.count);
  const objects = objectDistribution(records);
  const sourceMode = platformDistribution.length ? "platform_opinion" : objects.length ? "object_review" : "generic_comment";
  const totalLikes = records.reduce((sum, record) => sum + record.likeCount, 0);
  const rated = records.map((record) => record.rating).filter((rating): rating is number => typeof rating === "number" && rating > 0);
  const ratingAverage = rated.length ? Number((rated.reduce((sum, value) => sum + value, 0) / rated.length).toFixed(2)) : undefined;
  const topLikedComment = [...sentiment.records].sort((a, b) => b.likeCount - a.likeCount)[0];
  const propagationHeat = statusByHeat(totalComments, peakCommentDay.comments, peakLikeDay.likes);
  const negativeRisk = statusByNegative(negativeRate);
  const riskLevel = riskLevelByNegativeAndHeat(negativeRate, propagationHeat);
  const majorPlatform = platformDistribution[0]?.platform || "";
  const majorPlatformShare = Math.round(((platformDistribution[0]?.count || 0) / Math.max(totalComments, 1)) * 100);
  const objectName = objects[0]?.objectName;
  const objectAlias = objects[0]?.objectAlias;
  const collectedAt = records.find((record) => record.collectedAt)?.collectedAt;
  const topWords = keywords.slice(0, 6).map((item) => item.word).join("、");
  const focus = sourceMode === "object_review"
    ? [lexicon.contentObjects?.[0]?.term, lexicon.characters?.[0]?.term, lexicon.viewingExperience?.[0]?.term].filter(Boolean).join("、") || topWords
    : lexicon.targets.slice(0, 3).map((item) => item.term).join("、") || topWords;
  const status = overallStatus(negativeRisk, propagationHeat, sourceMode);
  const activeDays = trend.filter((item) => item.comments > 0 || item.likes > 0).length;
  const heatPressure = propagationHeat === "高" ? 76 : propagationHeat === "中" ? 48 : 22;
  const interactionPressure = Math.min(100, Math.round((Math.log1p(peakLikeDay.likes) / Math.log1p(50000)) * 100));
  const negativePressure = Math.round(negativeRate * 100);
  const highHeatNegative = Math.min(100, Math.round(negativeRate * heatPressure));
  const sourceConcentration = sourceMode === "platform_opinion"
    ? majorPlatformShare
    : sourceMode === "object_review"
      ? Math.min(100, objects[0] ? Math.round((objects[0].count / Math.max(totalComments, 1)) * 100) : 0)
      : 0;
  const judgment = sourceMode === "object_review"
    ? `当前数据属于单对象评论分析，分析对象为「${objectName || "未知对象"}」${objectAlias ? `（${objectAlias}）` : ""}。评论主要围绕${focus || "内容体验和用户评价"}展开，平均评分${ratingAverage ? `为 ${ratingAverage}` : "暂不可计算"}，负面比例为 ${Math.round(negativeRate * 100)}%。传播热度为${propagationHeat}，负面风险为${negativeRisk}，综合状态为「${status}」。`
    : sourceMode === "platform_opinion" ? [
      `本次讨论主要集中在「${focus || "核心议题"}」等议题上，负面比例为 ${Math.round(negativeRate * 100)}%。`,
      hasTrend ? `热度峰值出现在 ${peak.date}，当日热度指数为 ${peak.heat}，${majorPlatform || "主要来源"} ${majorPlatform ? `占样本约 ${majorPlatformShare}%` : ""}。` : "当前数据缺少可用发布时间，热度趋势和时间轴已降级，不生成伪造日期结论。",
      `传播热度为${propagationHeat}，负面风险为${negativeRisk}，综合状态为「${status}」。`
    ].join("") : `当前数据未提供明确平台或分析对象，系统按通用评论文本处理。样本共 ${totalComments} 条，主要关键词为「${focus || "暂无明显集中表达"}」，负面比例为 ${Math.round(negativeRate * 100)}%。${hasTrend ? `传播热度为${propagationHeat}` : "未识别到可用发布时间，趋势模块降级"}，负面风险为${negativeRisk}，综合状态为「${status}」。`;

  return {
    totalComments,
    heatIndex,
    negativeRate,
    peakTime: peak.date,
    majorPlatform,
    riskLevel,
    platformDistribution,
    objectDistribution: objects,
    sourceMode,
    objectName,
    objectAlias,
    ratingAverage,
    ratingDistribution: ratingDistribution(records),
    totalLikes,
    topLikedComment,
    collectedAt,
    peakCommentCount: peakCommentDay.comments,
    peakLikeCount: peakLikeDay.likes,
    relativeGrowthRate: relativeGrowthRate(trend),
    propagationHeat,
    negativeRisk,
    overallStatus: status,
    riskRadar: [
      { metric: "负面压力", value: negativePressure },
      { metric: "负面高热", value: highHeatNegative },
      { metric: "传播热度", value: heatPressure },
      { metric: "互动集中", value: interactionPressure },
      { metric: "来源集中", value: sourceConcentration || Math.min(100, Math.round((Math.log1p(activeDays) / Math.log1p(30)) * 100)) }
    ],
    judgment
  };
}
