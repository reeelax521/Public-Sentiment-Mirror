import type { DashboardData, TimelineNode, TrendPoint } from "@/lib/types";

function riskForPoint(point: TrendPoint, dashboard: DashboardData): TimelineNode["risk"] {
  if (point.negativeRate >= 0.35 || dashboard.negativeRisk === "高") return "high";
  if (point.negativeRate >= 0.16 || dashboard.negativeRisk === "中") return "medium";
  return "low";
}

function makeNode(stage: string, point: TrendPoint, summary: string, emotionChange: string, dashboard: DashboardData): TimelineNode {
  return {
    stage,
    time: point.date,
    summary,
    volume: point.comments,
    heat: point.heat,
    emotionChange,
    risk: riskForPoint(point, dashboard)
  };
}

function uniqueByDate(points: TrendPoint[]) {
  const map = new Map<string, TrendPoint>();
  for (const point of points) {
    const existing = map.get(point.date);
    if (!existing || point.comments > existing.comments || point.heat > existing.heat) {
      map.set(point.date, point);
    }
  }
  return [...map.values()].sort((a, b) => a.date.localeCompare(b.date));
}

function peakPoint(points: TrendPoint[]) {
  return points.reduce((best, point) => {
    if (point.comments !== best.comments) return point.comments > best.comments ? point : best;
    if (point.heat !== best.heat) return point.heat > best.heat ? point : best;
    return point.likes > best.likes ? point : best;
  }, points[0]);
}

function stageFor(point: TrendPoint, index: number, points: TrendPoint[], peak: TrendPoint, sourceMode: DashboardData["sourceMode"]) {
  if (point.date === peak.date) return sourceMode === "object_review" ? "评论峰值" : "热度峰值";
  if (index === 0) return sourceMode === "object_review" ? "评论出现" : "讨论出现";
  if (index === points.length - 1) return "长尾观察";
  const previous = points[index - 1];
  if (point.comments > previous.comments || point.heat > previous.heat) return "讨论升温";
  return "讨论回落";
}

function summaryFor(point: TrendPoint, stage: string, dashboard: DashboardData) {
  const base = `当日评论量 ${point.comments}，点赞量 ${point.likes}，热度指数 ${point.heat}，负面占比 ${Math.round(point.negativeRate * 100)}%。`;
  if (stage.includes("峰值")) return `${base}该日期是样本内讨论最集中的时间点，适合观察核心议题和高互动评论。`;
  if (stage === "讨论升温") return `${base}评论量或互动量较前一阶段上升，说明讨论关注度正在增加。`;
  if (stage === "讨论回落") return `${base}峰值后讨论热度回落，进入持续反馈阶段。`;
  if (stage === "长尾观察") return `${base}仍有少量评论延续，后续重点看是否出现新的争议点或高互动评论。`;
  return `${base}${dashboard.sourceMode === "object_review" ? "评论样本开始出现。" : "相关讨论开始进入样本。"}`
}

function emotionText(point: TrendPoint) {
  const negative = Math.round(point.negativeRate * 100);
  if (negative >= 35) return `负面占比 ${negative}%，情绪压力较高`;
  if (negative >= 16) return `负面占比 ${negative}%，需观察争议表达`;
  return `负面占比 ${negative}%，情绪压力较低`;
}

export function buildTimeline(trend: TrendPoint[], dashboard: DashboardData): TimelineNode[] {
  const points = uniqueByDate(trend.filter((point) => point.comments > 0 || point.likes > 0));
  if (!points.length) return [];
  const peak = peakPoint(points);

  if (points.length <= 5) {
    return points.map((point, index) => {
      const stage = stageFor(point, index, points, peak, dashboard.sourceMode);
      return makeNode(stage, point, summaryFor(point, stage, dashboard), emotionText(point), dashboard);
    });
  }

  const peakIndex = points.findIndex((point) => point.date === peak.date);
  const candidates = [
    points[0],
    points[Math.max(0, Math.floor(peakIndex / 2))],
    peak,
    points[Math.min(points.length - 1, peakIndex + Math.max(1, Math.floor((points.length - peakIndex) / 2)))],
    points[points.length - 1]
  ];
  const selected = uniqueByDate(candidates).slice(0, 5);

  return selected.map((point, index) => {
    const stage = stageFor(point, index, selected, peak, dashboard.sourceMode);
    return makeNode(stage, point, summaryFor(point, stage, dashboard), emotionText(point), dashboard);
  });
}
