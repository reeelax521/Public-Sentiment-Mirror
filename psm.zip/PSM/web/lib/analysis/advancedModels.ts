import type { AnalysisModelInfo, Dataset, KeywordItem, SentimentSummary } from "@/lib/types";

interface AdvancedModelResponse {
  keywords?: KeywordItem[];
  sentiment?: SentimentSummary;
  modelInfo?: AnalysisModelInfo[];
}

const defaultTimeoutMs = 18000;

export function fallbackModelInfo(): AnalysisModelInfo[] {
  return [
    {
      name: "SBERT",
      role: "语义向量与相似文本聚类",
      status: "fallback",
      description: "已预留模型服务接口；当前环境未启用时，使用规则清洗与词频统计保持网站可运行。"
    },
    {
      name: "BERTopic",
      role: "主题建模与主题词解释",
      status: "fallback",
      description: "已预留 BERTopic 输出入口；当前先用 Top 关键词展示舆情焦点。"
    },
    {
      name: "BERT 情感模型",
      role: "中文情感倾向识别",
      status: "fallback",
      description: "已预留 BERT 分类器入口；当前先用正负面词典生成可解释结果。"
    }
  ];
}

function activeModelInfo(): AnalysisModelInfo[] {
  return [
    {
      name: "SBERT",
      role: "语义向量与相似文本聚类",
      status: "active",
      description: "通过 Python 模型服务生成文本向量，可用于相似评论聚合和语义去重。"
    },
    {
      name: "BERTopic",
      role: "主题建模与主题词解释",
      status: "active",
      description: "基于 SBERT 向量聚类并使用 c-TF-IDF 输出主题词。"
    },
    {
      name: "BERT 情感模型",
      role: "中文情感倾向识别",
      status: "active",
      description: "调用中文 BERT/Roberta 情感分类器，补强规则词典难以识别的语境。"
    }
  ];
}

export async function runAdvancedModelAnalysis(dataset: Dataset): Promise<AdvancedModelResponse | null> {
  const baseUrl = process.env.ADVANCED_ANALYSIS_URL?.replace(/\/$/, "");
  if (!baseUrl) return null;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), Number(process.env.ADVANCED_ANALYSIS_TIMEOUT_MS || defaultTimeoutMs));

  try {
    const response = await fetch(`${baseUrl}/analyze`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        datasetId: dataset.id,
        records: dataset.records
      }),
      signal: controller.signal
    });

    if (!response.ok) return null;
    const data = (await response.json()) as AdvancedModelResponse;

    return {
      keywords: Array.isArray(data.keywords) ? data.keywords : undefined,
      sentiment: data.sentiment,
      modelInfo: Array.isArray(data.modelInfo) ? data.modelInfo : activeModelInfo()
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}
