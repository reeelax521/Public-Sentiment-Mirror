import type { KeywordItem, OpinionRecord } from "@/lib/types";
import { isLowInformationLatinToken, normalizeSocialText } from "@/lib/analysis/textNoise";

const stopwords = new Set([
  "的", "了", "和", "是", "在", "就", "都", "而", "及", "与", "或", "也", "很", "太", "又", "还",
  "我", "你", "他", "她", "它", "我们", "你们", "他们", "自己", "大家", "时候", "问题", "东西",
  "这个", "那个", "这些", "那些", "这样", "这种", "一下", "一点", "一些", "一部", "一个", "一种",
  "什么", "因为", "所以", "如果", "但是", "不过", "然后", "就是", "没有", "还是", "可以", "应该",
  "比较", "非常", "真的", "感觉", "觉得", "知道", "可能", "现在", "最后", "其实", "完全", "需要",
  "那么", "怎么", "不是", "不能", "不会", "出来", "起来", "下来", "里面", "这里", "那里", "对于", "关于",
  "这么", "地方", "确实", "还有", "不到", "网上",
  "回复", "评论", "视频", "弹幕", "内容", "观点", "用户", "网友", "平台", "媒体", "来源", "正文", "标题",
  "很多", "下面", "主要", "看到", "更多", "大家", "有人", "这里", "那里",
  "哔哩哔哩", "哔哩", "b站", "官方", "视频标题", "来源标题", "打开太阳", "bgm",
  "发来", "贺电", "这是"
]);

const domainPhrases = [
  "剧情", "叙事", "故事", "节奏", "逻辑", "铺垫", "主线", "支线", "结尾", "反转",
  "特效", "视觉效果", "场面", "动作场面", "打斗", "镜头", "配乐", "剪辑", "翻译", "字幕",
  "角色", "人物", "英雄", "群像", "反派", "钢铁侠", "美国队长", "绿巨人", "雷神", "黑寡妇", "鹰眼", "女巫", "快银", "奥创",
  "复仇者联盟", "漫威", "彩蛋", "好看", "精彩", "失望", "疲劳", "无聊", "一般", "推荐", "口碑", "情怀",
  "官方回应", "补充公告", "反馈渠道", "处理结果", "执行细节", "公开规则", "透明", "质疑", "担心", "不满", "支持", "观望",
  "贸易", "合作", "合作共赢", "谈判", "外交", "期待", "热度",
  "英歌舞", "潮汕", "民俗", "传统", "传统文化", "文化", "传承", "传承人", "非遗", "申遗", "春节", "中轴线",
  "文化遗产", "世界遗产", "民间艺术", "表演", "舞蹈", "鼓点", "春晚", "保护", "好帅", "太帅了", "看哭了",
  "国家博物馆", "博物馆", "博物院", "凤冠冰箱贴", "冰箱贴", "文创产品", "文创", "凤冠",
  "爆款", "热卖", "抢手", "购买体验", "预约名额", "参观体验", "黄牛", "倒卖", "加价", "限购", "排队购买"
];

const englishStopwords = new Set([
  "the", "and", "for", "with", "from", "this", "that", "these", "those", "you", "your", "are", "was", "were",
  "have", "has", "had", "will", "would", "could", "should", "not", "but", "all", "any", "can", "our", "their",
  "about", "into", "over", "under", "after", "before", "very", "more", "less", "just", "also", "then", "than",
  "new", "year", "happy", "lunar", "official", "save", "world", "remote", "control", "everything", "want", "wants",
  "bgm", "music", "video", "bilibili", "sakura", "ouo", "super", "up", "bip"
]);

const blockedLatinTokens = new Set([
  "official", "bgm", "bilibili", "sakura", "ouo", "save", "remote", "control", "world", "super", "up", "bip",
  "qbdswnrhhh", "qbdswnrhhh1", "xixi0311", "movae0218"
]);

const blockedChineseTerms = new Set([
  "打开太阳", "哔哩哔哩", "哔哩", "官方", "视频", "弹幕", "评论", "回复", "用户", "网友",
  "天回地转覆六甲", "头顶三柱问路香", "脚踏大禹七星罡", "诛邪斩妖震四方",
  "就是杀了我", "快丢掉它", "紧掷掉怹", "对着你的头壳",
  "太阳", "七星", "四方", "头顶", "脚踏", "问路", "三柱", "帅帅", "博物"
]);

const englishPhraseWhitelist = [
  "chinese new year",
  "happy chinese new year",
  "spring festival",
  "world heritage",
  "unesco"
];

function countOccurrences(text: string, phrase: string) {
  if (!phrase) return 0;
  return text.split(phrase).length - 1;
}

function isUsefulToken(token: string) {
  if (!token || stopwords.has(token)) return false;
  if (blockedChineseTerms.has(token)) return false;
  if (/^\d+$/.test(token)) return false;
  if (/^[a-z0-9]+$/i.test(token)) {
    const lower = token.toLowerCase();
    return lower === "unesco" || englishPhraseWhitelist.includes(lower);
  }
  if (/^[\u4e00-\u9fa5]+$/.test(token)) {
    if (token.length < 2 || token.length > 8) return false;
    if (token.length > 6 && !domainPhrases.includes(token)) return false;
    if (token.length >= 5 && /[的与和于在之]/.test(token) && !domainPhrases.includes(token)) return false;
    if (/(.)\1{2,}/.test(token)) return false;
    if (token.length === 2 && token[0] === token[1]) return false;
    if (["和", "与", "的", "了", "是", "在", "都", "就"].some((word) => token.startsWith(word) || token.endsWith(word))) return false;
    if (/^[一二三四五六七八九十个部种些点]+$/.test(token)) return false;
    return true;
  }
  return false;
}

function segmentChinese(text: string) {
  const tokens: string[] = [];
  const segmenterCtor = Intl.Segmenter;
  if (segmenterCtor) {
    const segmenter = new segmenterCtor("zh-CN", { granularity: "word" });
    for (const item of segmenter.segment(text)) {
      const token = item.segment.trim();
      if (item.isWordLike && isUsefulToken(token)) tokens.push(token);
    }
    return tokens;
  }

  return (text.match(/[\u4e00-\u9fa5]{2,8}/g) || []).filter(isUsefulToken);
}

export function tokenize(text: string) {
  const normalized = normalizeSocialText(text).replace(/https?:\/\/\S+|www\.\S+/g, " ").replace(/[^\u4e00-\u9fa5a-zA-Z0-9#]+/g, " ");
  const tokens: string[] = [];

  for (const phrase of domainPhrases) {
    const count = countOccurrences(normalized, phrase);
    for (let i = 0; i < count; i += 1) tokens.push(phrase);
  }

  tokens.push(...segmentChinese(normalized));
  tokens.push(...(normalized.toLowerCase().match(/[a-z0-9]{3,}/g) || []));

  return tokens.filter(isUsefulToken);
}

function canonicalEnglishPhrase(value: string) {
  return value
    .split(/\s+/)
    .filter(Boolean)
    .map((word) => word.length <= 3 && word === word.toUpperCase() ? word : word[0].toUpperCase() + word.slice(1).toLowerCase())
    .join(" ");
}

function phraseOverlap(a: string, b: string) {
  const left = new Set(a.split(" "));
  const right = new Set(b.split(" "));
  const overlap = [...left].filter((item) => right.has(item)).length;
  return overlap / Math.max(Math.min(left.size, right.size), 1);
}

function coveredMeaningfulPhrase(existing: string, phrase: string) {
  const existingWords = new Set(existing.split(" "));
  const meaningful = phrase.split(" ").filter((word) => !englishStopwords.has(word));
  return meaningful.length > 0 && meaningful.length <= 2 && meaningful.every((word) => existingWords.has(word));
}

function collectEnglishPhrases(records: OpinionRecord[]) {
  const counter = new Map<string, number>();
  for (const record of records) {
    const text = normalizeSocialText(record.content).replace(/https?:\/\/\S+|www\.\S+/g, " ");
    const lowerText = text.toLowerCase();
    englishPhraseWhitelist.forEach((phrase) => {
      const count = countOccurrences(lowerText, phrase);
      if (count > 0) counter.set(phrase, (counter.get(phrase) || 0) + count);
    });
    const words = (text.match(/[a-zA-Z][a-zA-Z0-9]*/g) || [])
      .map((word) => word.toLowerCase())
      .filter((word) => word.length >= 2 && !blockedLatinTokens.has(word) && !isLowInformationLatinToken(word) && !englishStopwords.has(word));

    for (let size = 4; size >= 2; size -= 1) {
      for (let index = 0; index <= words.length - size; index += 1) {
        const phraseWords = words.slice(index, index + size);
        if (phraseWords.every((word) => englishStopwords.has(word))) continue;
        const phrase = phraseWords.join(" ");
        counter.set(phrase, (counter.get(phrase) || 0) + 1);
      }
    }
  }

  const ranked = [...counter.entries()]
    .filter(([phrase, count]) => (count >= 2 || englishPhraseWhitelist.includes(phrase)) && phrase.length >= 7 && !phrase.split(" ").some((word) => blockedLatinTokens.has(word)))
    .sort((a, b) => b[1] - a[1] || b[0].split(" ").length - a[0].split(" ").length);
  const selected: Array<{ key: string; word: string; count: number }> = [];
  for (const [phrase, count] of ranked) {
    const overlapped = selected.some((item) =>
      item.key.includes(phrase)
      || phrase.includes(item.key)
      || phraseOverlap(item.key, phrase) >= 0.66
      || coveredMeaningfulPhrase(item.key, phrase)
    );
    if (!overlapped) selected.push({ key: phrase, word: canonicalEnglishPhrase(phrase), count });
    if (selected.length >= 12) break;
  }
  return selected;
}

export function sanitizeKeywordItems(items: KeywordItem[], recordCount = 0, limit = 30): KeywordItem[] {
  const minCount = recordCount >= 1000
    ? Math.max(18, Math.ceil(recordCount * 0.01))
    : recordCount >= 100
      ? 2
      : 1;
  const selected: KeywordItem[] = [];
  for (const item of items) {
    if (item.count < minCount) continue;
    const lower = item.word.toLowerCase();
    if (item.word.includes(" ")) {
      if (!englishPhraseWhitelist.includes(lower)) {
        const words = lower.split(/\s+/).filter(Boolean);
        if (words.length > 3 || words.some((word) => blockedLatinTokens.has(word) || englishStopwords.has(word))) continue;
      }
    } else if (!isUsefulToken(item.word)) {
      continue;
    }
    if (selected.some((existing) => existing.word !== item.word && existing.word.includes(item.word) && existing.count >= item.count * 0.75)) continue;
    if (item.word === "歌舞" && items.some((candidate) => candidate.word === "英歌舞" && candidate.count >= item.count * 0.75)) continue;
    if (selected.some((existing) => existing.word === item.word)) continue;
    selected.push(item);
    if (selected.length >= limit) break;
  }
  return selected;
}

export function extractKeywords(records: OpinionRecord[], limit = 30): KeywordItem[] {
  const counter = new Map<string, number>();
  const phraseItems = collectEnglishPhrases(records);
  const phraseComponents = new Set(phraseItems.flatMap((item) => item.key.split(" ")));

  records.forEach((record) => {
    tokenize(record.content).forEach((token) => {
      if (/^[a-z0-9]+$/i.test(token) && phraseComponents.has(token.toLowerCase())) return;
      counter.set(token, (counter.get(token) || 0) + 1);
    });
  });
  phraseItems.forEach((item) => {
    counter.set(item.word, Math.max(counter.get(item.word) || 0, item.count));
  });
  const max = Math.max(...counter.values(), 1);
  const ranked = [...counter.entries()]
    .sort((a, b) => b[1] - a[1] || b[0].length - a[0].length)
    .map(([word, count]) => ({ word, count, weight: Math.round((count / max) * 100) }));

  const filtered: KeywordItem[] = [];
  for (const item of ranked) {
    const coveredByPhrase = item.word.length <= 2
      && filtered.some((selected) => selected.word.length > item.word.length && selected.word.includes(item.word) && selected.count >= item.count);
    if (!coveredByPhrase) filtered.push(item);
    if (filtered.length >= limit * 2) break;
  }
  return sanitizeKeywordItems(filtered, records.length, limit);
}
