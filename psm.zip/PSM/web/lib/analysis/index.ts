import { cleanRecords } from "@/lib/analysis/clean";
import { buildDashboard } from "@/lib/analysis/risk";
import { analyzeSentiment, classifySentiment } from "@/lib/analysis/sentiment";
import { buildTimeline } from "@/lib/analysis/timeline";
import { buildTrend } from "@/lib/analysis/trend";
import { buildEventAnalysis, enrichTopics } from "@/lib/analysis/event";
import { refineEventAnalysisWithDeepSeek } from "@/lib/analysis/deepseekEvent";
import { fallbackModelInfo, runAdvancedModelAnalysis } from "@/lib/analysis/advancedModels";
import { extractKeywords, sanitizeKeywordItems } from "@/lib/analysis/keywords";
import { extractLexicon } from "@/lib/analysis/lexicon";
import { analyzeTexts, getSentiment, recordsToNlpPayload } from "@/lib/nlpClient";
import { ensureNlpService } from "@/lib/nlpServiceManager";
import type {
  AnalysisTask,
  ClusterItem,
  DashboardData,
  DataProfile,
  Dataset,
  KeywordItem,
  NlpAnalysisResult,
  OpinionRecord,
  SentimentRecord,
  SentimentSummary,
  TopicItem
} from "@/lib/types";

interface NlpRawResponse {
  keywords?: Array<{ word: string; count: number }>;
  sentiment?: {
    distribution?: { positive?: number; neutral?: number; negative?: number };
    negativeRate?: number;
    items?: Array<{ text: string; label: "positive" | "neutral" | "negative"; score: number }>;
    typicalComments?: { positive?: string[]; neutral?: string[]; negative?: string[] };
    mode?: "bert" | "snownlp" | "fallback" | "lexicon";
  };
  clusters?: ClusterItem[];
  topics?: TopicItem[];
  risk?: NlpAnalysisResult["risk"];
  mode?: "nlp" | "fallback";
  warnings?: string[];
}

function normalizePercentValue(value?: number) {
  if (!value) return 0;
  return value > 1 ? value / 100 : value;
}

function mapNlpKeywords(raw: Array<{ word: string; count: number }> | undefined, recordCount = 0): KeywordItem[] | null {
  if (!raw?.length) return null;
  const max = Math.max(...raw.map((item) => item.count), 1);
  return sanitizeKeywordItems(raw.map((item) => ({
    word: item.word,
    count: item.count,
    weight: Math.round((item.count / max) * 100)
  })), recordCount);
}

function mapNlpSentiment(records: OpinionRecord[], raw?: NlpRawResponse["sentiment"]): SentimentSummary | null {
  if (!raw?.distribution) return null;
  const labelByText = new Map((raw.items || []).map((item) => [item.text, item]));
  const enriched: SentimentRecord[] = records.map((record) => {
    if (record.rating !== null && record.rating !== undefined) return classifySentiment(record);
    const match = labelByText.get(record.content);
    const local = classifySentiment(record);
    if (!match) return local;
    const modelScore = Math.round(match.score * 100);
    if (local.sentiment === "negative" && local.score >= 80 && match.label !== "negative") {
      return { ...local, score: Math.max(local.score, Math.round((local.score + Math.min(modelScore, 82)) / 2)) };
    }
    if (local.sentiment === "neutral" && local.score >= 76 && match.label === "negative" && modelScore < 92) {
      return { ...local, score: Math.max(local.score, Math.round((local.score + Math.min(modelScore, 82)) / 2)) };
    }
    if (local.sentiment === "neutral" && local.score >= 76 && match.label === "positive" && modelScore < 90) {
      return { ...local, score: Math.max(local.score, Math.round((local.score + Math.min(modelScore, 82)) / 2)) };
    }
    if (local.sentiment === "positive" && local.score >= 86 && match.label === "neutral") {
      return { ...local, score: Math.max(local.score, modelScore) };
    }
    if (match.label === "neutral" && local.sentiment !== "neutral" && local.score >= 70) {
      return { ...local, score: Math.max(local.score, modelScore) };
    }
    if (local.sentiment !== "neutral" && local.sentiment !== match.label && local.score >= 84 && modelScore < 90) {
      return { ...local, score: Math.max(72, Math.round((local.score + modelScore) / 2)) };
    }
    return {
      ...record,
      sentiment: match.label,
      score: modelScore
    };
  });
  const trendMap = new Map<string, { date: string; positive: number; neutral: number; negative: number }>();
  enriched.forEach((item) => {
    if (!item.publishTime || item.missingFields?.includes("publishTime")) return;
    const date = item.publishTime.slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return;
    const row = trendMap.get(date) || { date, positive: 0, neutral: 0, negative: 0 };
    row[item.sentiment] += 1;
    trendMap.set(date, row);
  });
  const total = Math.max(enriched.length, 1);
  const share = (label: "positive" | "neutral" | "negative") => enriched.filter((item) => item.sentiment === label).length / total;
  const hasRating = records.some((record) => record.rating !== null && record.rating !== undefined);
  const modelItemCount = raw.items?.length || 0;
  const modelCoverage = modelItemCount / total;
  const hasReliableModelItems = modelCoverage >= 0.95;
  const modelShare = (label: "positive" | "neutral" | "negative") => normalizePercentValue(raw.distribution?.[label]);
  const engineLabel = raw.mode === "bert"
    ? "后台 BERT 情感模型"
    : raw.mode === "snownlp"
      ? "后台 SnowNLP 情感模型"
      : raw.mode === "fallback"
        ? "后台情感服务降级模型"
        : "后台情感模型";
  return {
    positive: hasRating || hasReliableModelItems ? share("positive") : modelShare("positive"),
    neutral: hasRating || hasReliableModelItems ? share("neutral") : modelShare("neutral"),
    negative: hasRating || hasReliableModelItems ? share("negative") : modelShare("negative"),
    records: enriched,
    trend: [...trendMap.values()].sort((a, b) => a.date.localeCompare(b.date)),
    examples: (["positive", "neutral", "negative"] as const)
      .flatMap((label) => enriched.filter((item) => item.sentiment === label).sort((a, b) => b.likeCount - a.likeCount).slice(0, 2))
      .slice(0, 6),
    basis: hasRating ? `${engineLabel} + 用户评分` : `${engineLabel} + 情绪证据校准`
  };
}

type SemanticRule = { name: string; terms: string[]; priority?: number };

const movieTopicRules: SemanticRule[] = [
  { name: "剧情与叙事评价", terms: ["剧情", "叙事", "故事", "节奏", "逻辑", "结尾", "主线"] },
  { name: "角色与英雄群像讨论", terms: ["角色", "英雄", "钢铁侠", "美国队长", "绿巨人", "雷神", "黑寡妇", "鹰眼", "女巫", "奥创", "复仇者"] },
  { name: "视觉特效与动作场面", terms: ["特效", "视觉", "场面", "打斗", "动作", "镜头", "震撼"] },
  { name: "反派塑造与冲突设计", terms: ["反派", "奥创", "冲突", "危机", "设定", "塑造"] },
  { name: "观影体验与口碑分化", terms: ["好看", "精彩", "失望", "疲劳", "无聊", "推荐", "一般", "口碑", "翻译"] }
];

const publicTopicRules: SemanticRule[] = [
  { name: "正向态度与认可表达", terms: ["支持", "期待", "期盼", "认可", "满意", "理解", "共赢", "友好", "正道", "好处", "振奋"] },
  { name: "疑问质疑与风险关注", terms: ["质疑", "担心", "风险", "不满", "反对", "没回答", "敷衍", "需要解释", "不信任", "波动", "博弈"] },
  { name: "建议诉求与行动期待", terms: ["建议", "要求", "希望尽快", "改进", "回应", "处理", "解释", "透明", "规则", "解决"] },
  { name: "事实信息与对象描述", terms: ["事件", "话题", "平台", "媒体", "官方", "政策", "规则", "公告", "回应", "结果", "用户", "网友", "评论"] },
  { name: "日常互动与低信息评论", terms: ["哈哈", "愉快", "早安", "晚安", "咖啡", "鲜花", "赞", "good", "小心心", "假期"] }
];

const culturalPerformanceTopicRules: SemanticRule[] = [
  { name: "版本来源与原创争议", terms: ["b站", "版本", "没看过", "侵权", "抄袭", "授权", "原创", "春晚", "央视"], priority: 90 },
  { name: "艺术理解与观演门槛", terms: ["看不懂", "没看懂", "不懂", "解读", "讲解", "赏析", "意境", "表达", "明白", "理解"], priority: 80 },
  { name: "舞台审美与文化表达", terms: ["只此青绿", "青绿", "千里江山", "江山", "青山", "山水", "舞蹈", "舞美", "配色", "老虎", "妩媚", "春晚", "节目"], priority: 70 },
  { name: "文化认同与传统传承", terms: ["华夏", "文化自信", "传统文化", "文艺复兴", "传承", "文化", "国风", "中国审美"], priority: 60 },
  { name: "表演传播与节目记忆", terms: ["记住", "出圈", "火", "传播", "舞台", "演员", "表演", "震惊", "备受震惊"], priority: 50 }
];

const danmakuTopicRules: SemanticRule[] = [
  { name: "高频梗与称呼表达", terms: ["哈哈", "笑", "牛", "绷", "老板", "忠诚", "称呼"] },
  { name: "事件行为与剧情节点", terms: ["事件", "行为", "时间", "地点", "人物", "场景", "剧情"] },
  { name: "情绪反应与短句互动", terms: ["哈哈", "笑", "好", "？", "！", "666", "离谱", "震惊"] },
  { name: "信息补充与事实提示", terms: ["视频", "弹幕", "新闻", "补充", "解释", "原因", "结果"] }
];

function scoreRecord(record: OpinionRecord, terms: string[]) {
  return terms.reduce((sum, term) => sum + (record.content.includes(term) ? 1 : 0), 0);
}

function isReadableTopicTerm(term: string) {
  const value = term.trim();
  if (!value) return false;
  if (/^\d+$/.test(value)) return false;
  if (/^[a-z0-9_]{1,}$/i.test(value)) return /^unesco$/i.test(value);
  if (value.length < 2 || value.length > 12) return false;
  if (/^(回复|评论|视频|弹幕|内容|观点|平台|媒体|用户|网友|这个|那个|这么|可以|应该|地方|还有|不到|网上|super|up|bip|call|doge|b站)$/i.test(value)) return false;
  if (/^(另一个|个人|头发|有人吗|bgm|bmg|舞蹈区|投稿|原版|版本)$/.test(value)) return false;
  return true;
}

function buildReviewSemanticResult(records: OpinionRecord[], keywords: KeywordItem[], dashboard: DashboardData): Pick<NlpAnalysisResult, "topics" | "clusters"> {
  const assigned = movieTopicRules.map((rule, index) => {
    const matched = records.filter((record) => scoreRecord(record, rule.terms) > 0);
    const fallbackStart = Math.floor((records.length / movieTopicRules.length) * index);
    const rows = matched.length ? matched : records.slice(fallbackStart, fallbackStart + Math.ceil(records.length / movieTopicRules.length));
    const topTerms = rule.terms
      .map((term) => ({ term, count: rows.filter((record) => record.content.includes(term)).length + (keywords.find((item) => item.word === term)?.count || 0) }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5)
      .map((item) => item.term);
    const representativeTexts = [...rows].sort((a, b) => b.likeCount - a.likeCount).slice(0, 3).map((record) => record.content);
    const size = rows.length;
    const percentage = Number((size / Math.max(records.length, 1) * 100).toFixed(1));
    return {
      clusterId: index,
      topicId: index,
      label: rule.name,
      name: rule.name,
      size,
      percentage,
      topTerms,
      keywords: topTerms,
      representativeTexts,
      coordinates: rows.slice(0, 40).map((record, pointIndex) => ({
        x: index * 1.8 + (pointIndex % 7) * 0.16,
        y: (record.rating || 3) * 8 + Math.log(record.likeCount + 1) * 3,
        clusterId: index,
        text: record.content
      }))
    };
  });

  const clusters: ClusterItem[] = assigned.map((item) => ({
    clusterId: item.clusterId,
    label: item.label,
    size: item.size,
    percentage: item.percentage,
    topTerms: item.topTerms,
    representativeTexts: item.representativeTexts,
    coordinates: item.coordinates
  }));
  const topics: TopicItem[] = assigned.map((item) => ({
    topicId: item.topicId,
    name: item.name,
    size: item.size,
    percentage: item.percentage,
    keywords: item.keywords,
    representativeTexts: item.representativeTexts
  }));

  return { topics, clusters };
}

function inferGenericLabel(term: string) {
  if (/预约|名额|门票|抢|约上|约不上|难约|看展|逛国博|参观/.test(term)) return "预约名额与参观体验冲突";
  if (/凤冠|冰箱贴|国博|国家博物馆|文创/.test(term)) return "爆款文创与销售热度";
  if (/价格|太贵|消费|购买|性价比/.test(term)) return "价格与购买门槛讨论";
  if (/只此青绿|青绿|千里江山|江山|青山|山水|舞蹈|舞美|配色|老虎|妩媚/.test(term)) return "舞台审美与文化表达";
  if (/b站|版本|没看过|侵权|抄袭|授权|原创/.test(term)) return "版本来源与原创争议";
  if (/看不懂|没看懂|不懂|解读|讲解|赏析|意境/.test(term)) return "艺术理解与观演门槛";
  if (/好看|审美|漂亮|造型|精致|发卡|卡头发/.test(term)) return "审美造型与体验评价";
  if (/黄牛|倒卖|代购|限购|抢购/.test(term)) return "抢购秩序与黄牛风险";
  if (["支持", "期待", "希望", "喜欢", "认可", "忠诚"].some((word) => term.includes(word))) return `正向态度：${term}`;
  if (["质疑", "担心", "反对", "失望", "不满"].some((word) => term.includes(word))) return `负向关注：${term}`;
  return "长尾评论与补充表达";
}

function rulesForProfile(dataProfile: DataProfile | undefined, keywords: KeywordItem[]): SemanticRule[] {
  const hasCulturalPerformanceSignal = keywords.some((keyword) => /只此青绿|青绿|千里江山|江山|青山|华夏|舞蹈|舞美|春晚|版本|b站|老虎|妩媚|文化自信|文艺复兴/.test(keyword.word));
  const baseRules: SemanticRule[] = dataProfile === "danmaku"
    ? danmakuTopicRules
    : hasCulturalPerformanceSignal
      ? culturalPerformanceTopicRules
    : [...publicTopicRules];
  const coveredTerms = new Set(baseRules.flatMap((rule) => rule.terms));
  const keywordRules: SemanticRule[] = keywords
    .filter((keyword) => isReadableTopicTerm(keyword.word))
    .filter((keyword) => !coveredTerms.has(keyword.word) && !baseRules.some((rule) => rule.terms.some((term) => keyword.word.includes(term) || term.includes(keyword.word))))
    .slice(0, 3)
    .map((keyword) => ({
    name: inferGenericLabel(keyword.word),
    terms: [keyword.word]
  }));
  return [...baseRules, ...keywordRules];
}

function topicTermCounts(rows: OpinionRecord[], terms: string[], keywords: KeywordItem[]) {
  const fromTerms = terms.map((term) => ({
    term,
    count: rows.filter((record) => record.content.includes(term)).length + (keywords.find((item) => item.word === term)?.count || 0)
  }));
  const fromKeywords = extractKeywords(rows, 10).map((item) => ({ term: item.word, count: item.count }));
  return [...fromTerms, ...fromKeywords]
    .filter((item) => item.term && item.count > 0 && isReadableTopicTerm(item.term))
    .filter((item, index, all) => all.findIndex((other) => other.term === item.term) === index)
    .sort((a, b) => b.count - a.count)
    .slice(0, 6)
    .map((item) => item.term);
}

function buildGenericSemanticResult(records: OpinionRecord[], keywords: KeywordItem[], dataProfile?: DataProfile): Pick<NlpAnalysisResult, "topics" | "clusters"> {
  const candidateRules = rulesForProfile(dataProfile, keywords);
  const preferredRules = candidateRules.map((rule) => {
    const size = records.filter((record) => scoreRecord(record, rule.terms) > 0).length;
    return { ...rule, size };
  }).filter((rule) => rule.size > 0)
    .sort((a, b) => (b.priority || 0) - (a.priority || 0) || b.size - a.size);

  const preferredCoverage = preferredRules.reduce((sum, rule) => sum + rule.size, 0) / Math.max(records.length, 1);
  const seedRules = preferredRules.length >= 3 && preferredCoverage >= 0.18
    ? preferredRules
    : candidateRules.map((rule) => ({
      ...rule,
      size: records.filter((record) => scoreRecord(record, rule.terms) > 0).length
    })).sort((a, b) => (b.priority || 0) - (a.priority || 0) || b.size - a.size);
  const rules = seedRules
    .filter((rule, index, all) => {
      const currentTerms = new Set(rule.terms);
      return all.findIndex((item) => {
        const otherTerms = new Set(item.terms);
        const overlap = [...currentTerms].filter((term) => otherTerms.has(term)).length;
        const similarity = overlap / Math.max(Math.min(currentTerms.size, otherTerms.size), 1);
        return item.name === rule.name || similarity >= 0.66;
      }) === index;
    })
    .slice(0, records.length >= 500 ? 7 : 6);

  const safeRules = rules.length ? rules : [{
    name: "综合评论表达",
    terms: keywords.filter((item) => isReadableTopicTerm(item.word)).slice(0, 5).map((item) => item.word),
    size: records.length
  }];

  const usedIndices = new Set<number>();
  const assigned = safeRules.map((rule, index) => {
    const matched = records
      .map((record, recordIndex) => ({ record, recordIndex }))
      .filter((item) => !usedIndices.has(item.recordIndex) && rule.terms.some((term) => item.record.content.includes(term)));
    const fallbackRows = records
      .map((record, recordIndex) => ({ record, recordIndex }))
      .filter((item) => !usedIndices.has(item.recordIndex))
      .slice(0, Math.ceil(records.length / Math.max(safeRules.length + 1, 1)));
    const entries = matched.length ? matched : fallbackRows;
    entries.forEach((item) => usedIndices.add(item.recordIndex));
    const rows = entries.map((item) => item.record);
    const topTerms = topicTermCounts(rows, rule.terms, keywords);
    const representativeTexts = [...rows].sort((a, b) => b.likeCount - a.likeCount).slice(0, 3).map((record) => record.content);
    const size = rows.length;
    const percentage = Number((size / Math.max(records.length, 1) * 100).toFixed(1));
    return {
      id: index,
      name: rule.name,
      size,
      percentage,
      topTerms: topTerms.length ? topTerms : keywords.filter((item) => isReadableTopicTerm(item.word)).slice(0, 5).map((item) => item.word),
      representativeTexts,
      coordinates: rows.slice(0, 36).map((record, pointIndex) => ({
        x: index * 1.4 + (pointIndex % 6) * 0.18,
        y: Math.log(record.likeCount + record.commentCount + record.repostCount + 2) * 10 + (pointIndex % 5),
        clusterId: index,
        text: record.content
      }))
    };
  }).filter((item) => item.size > 0);

  const remaining = records.filter((_, index) => !usedIndices.has(index));
  if (remaining.length) {
    const topTerms = topicTermCounts(remaining, keywords.filter((item) => isReadableTopicTerm(item.word)).slice(0, 6).map((item) => item.word), keywords);
    const index = assigned.length;
    assigned.push({
      id: index,
      name: dataProfile === "danmaku" ? "其他短弹幕与长尾互动" : "其他短文本与长尾讨论",
      size: remaining.length,
      percentage: Number((remaining.length / Math.max(records.length, 1) * 100).toFixed(1)),
      topTerms,
      representativeTexts: remaining.slice(0, 3).map((record) => record.content),
      coordinates: remaining.slice(0, 36).map((record, pointIndex) => ({
        x: index * 1.4 + (pointIndex % 6) * 0.18,
        y: Math.log(record.likeCount + record.commentCount + record.repostCount + 2) * 10 + (pointIndex % 5),
        clusterId: index,
        text: record.content
      }))
    });
  }

  return {
    clusters: assigned.map((item) => ({
      clusterId: item.id,
      label: item.name,
      size: item.size,
      percentage: item.percentage,
      topTerms: item.topTerms,
      representativeTexts: item.representativeTexts,
      coordinates: item.coordinates
    })),
    topics: assigned.map((item) => ({
      topicId: item.id,
      name: item.name,
      size: item.size,
      percentage: item.percentage,
      keywords: item.topTerms,
      representativeTexts: item.representativeTexts
    }))
  };
}

function basicSemanticResult(records: OpinionRecord[], keywords: KeywordItem[], dashboard: DashboardData, dataProfile?: DataProfile): NlpAnalysisResult {
  if (dashboard.sourceMode === "object_review" && records.length >= 100) {
    const semantic = buildReviewSemanticResult(records, keywords, dashboard);
    return {
      ...semantic,
      risk: {
        riskLevel: dashboard.riskLevel,
        riskScore: dashboard.heatIndex,
        reason: dashboard.judgment
      },
      mode: "basic",
      warnings: ["Python NLP 服务不可用，当前使用电影评论主题 fallback。"]
    };
  }

  if (records.length >= 30) {
    const semantic = buildGenericSemanticResult(records, keywords, dataProfile);
    return {
      ...semantic,
      risk: {
        riskLevel: dashboard.riskLevel,
        riskScore: dashboard.heatIndex,
        reason: dashboard.judgment
      },
      mode: "basic",
      warnings: ["Python NLP 服务不可用，当前使用通用主题聚类 fallback。"]
    };
  }

  const topTerms = keywords.filter((item) => isReadableTopicTerm(item.word)).slice(0, 8).map((item) => item.word);
  const representative = topTerms.length ? [`主要讨论集中在：${topTerms.slice(0, 5).join("、")}`] : [];
  const cluster: ClusterItem = {
    clusterId: 0,
    label: topTerms.slice(0, 3).join("、") || "综合讨论",
    size: dashboard.totalComments,
    percentage: 100,
    topTerms,
    representativeTexts: representative,
    coordinates: []
  };
  return {
    clusters: [cluster],
    topics: [{
      topicId: 0,
      name: dashboard.sourceMode === "object_review" ? "综合观影体验讨论" : cluster.label,
      size: cluster.size,
      percentage: 100,
      keywords: cluster.topTerms,
      representativeTexts: representative
    }],
    risk: {
      riskLevel: dashboard.riskLevel,
      riskScore: dashboard.heatIndex,
      reason: dashboard.judgment
    },
    mode: "basic",
    warnings: ["Python NLP 服务不可用，当前使用基础分析模式。"]
  };
}

export async function createAnalysisTask(dataset: Dataset): Promise<AnalysisTask> {
  const taskId = `task_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const clean = cleanRecords(dataset.records);
  const nlpStatus = await ensureNlpService();
  const nlpPayload = recordsToNlpPayload(taskId, clean.records);
  const sentimentRaw = nlpStatus.ok ? await getSentiment(nlpPayload) : null;
  const fullAnalysisLimit = Number(process.env.NLP_FULL_ANALYSIS_MAX_RECORDS || 1800);
  const shouldRunFullNlp = nlpStatus.ok && clean.records.length <= fullAnalysisLimit;
  const nlpRaw = shouldRunFullNlp ? await analyzeTexts(nlpPayload) as NlpRawResponse | null : null;
  const advanced = await runAdvancedModelAnalysis({ ...dataset, records: clean.records });
  const nlpKeywords = mapNlpKeywords(nlpRaw?.keywords, clean.records.length);
  const keywords = nlpKeywords?.length ? nlpKeywords : advanced?.keywords?.length ? advanced.keywords : extractKeywords(clean.records);
  const lexicon = extractLexicon(clean.records, dataset.fieldMapping.dataProfile);
  const nlpSentiment = mapNlpSentiment(clean.records, nlpRaw?.sentiment || sentimentRaw || undefined);
  const sentiment = nlpSentiment || (advanced?.sentiment?.records?.length ? advanced.sentiment : analyzeSentiment(clean.records));
  const trend = buildTrend(clean.records, sentiment);
  let dashboard = buildDashboard(clean.records, sentiment, trend, keywords, lexicon);
  if (nlpRaw?.risk) {
    const useNlpRiskLevel = dashboard.negativeRisk !== "低" || nlpRaw.risk.riskLevel === "low";
    dashboard = {
      ...dashboard,
      riskLevel: useNlpRiskLevel ? nlpRaw.risk.riskLevel : dashboard.riskLevel,
      judgment: nlpRaw.risk.reason
    };
  }
  const timeline = buildTimeline(trend, dashboard);
  let modelInfo = advanced?.modelInfo?.length ? advanced.modelInfo : fallbackModelInfo();
  let nlp = nlpRaw ? {
    topics: nlpRaw.topics || [],
    clusters: nlpRaw.clusters || [],
    risk: nlpRaw.risk || { riskLevel: dashboard.riskLevel, riskScore: dashboard.heatIndex, reason: dashboard.judgment },
    mode: nlpRaw.mode || "fallback",
    warnings: nlpRaw.warnings || []
  } satisfies NlpAnalysisResult : basicSemanticResult(clean.records, keywords, dashboard, dataset.fieldMapping.dataProfile);

  if (!nlpRaw && sentimentRaw?.mode && sentimentRaw.mode !== "fallback") {
    nlp = {
      ...nlp,
      mode: "nlp",
      warnings: [
        ...nlp.warnings.filter((warning) => !warning.includes("Python NLP 服务不可用")),
        clean.records.length > fullAnalysisLimit
          ? `样本量 ${clean.records.length} 超过完整主题模型阈值 ${fullAnalysisLimit}，已优先调用后台 ${sentimentRaw.mode === "bert" ? "BERT" : "SnowNLP"} 情感模型，主题聚类使用本地可解释方案。`
          : `完整 NLP 分析未返回，已单独调用后台 ${sentimentRaw.mode === "bert" ? "BERT" : "SnowNLP"} 情感模型。`
      ]
    };
  } else if (!nlpStatus.ok) {
    nlp = {
      ...nlp,
      warnings: [...nlp.warnings, nlpStatus.reason || "NLP 服务未连接。"]
    };
  }

  if (sentimentRaw?.mode && sentimentRaw.mode !== "fallback") {
    modelInfo = modelInfo.map((item) => item.name.includes("BERT") || item.name.includes("情感")
      ? {
        ...item,
        status: "active",
        description: `已调用后台 ${sentimentRaw.mode === "bert" ? "BERT/Roberta" : "SnowNLP"} 情感模型，并叠加语境证据校准。`
      }
      : item);
  }

  if (dashboard.sourceMode === "object_review" && clean.records.length > 500 && (nlp.topics.length < 5 || nlp.clusters.length < 5)) {
    const semantic = buildReviewSemanticResult(clean.records, keywords, dashboard);
    nlp = {
      ...nlp,
      topics: semantic.topics,
      clusters: semantic.clusters,
      warnings: [...nlp.warnings, "主题结果过少，已启用电影评论可解释主题 fallback。"]
    };
  } else if (dashboard.sourceMode !== "object_review" && clean.records.length >= 100 && (nlp.topics.length < 3 || nlp.clusters.length < 3)) {
    const semantic = buildGenericSemanticResult(clean.records, keywords, dataset.fieldMapping.dataProfile);
    nlp = {
      ...nlp,
      topics: semantic.topics,
      clusters: semantic.clusters,
      warnings: [...nlp.warnings, "主题结果过少，已启用通用评论主题 fallback。"]
    };
  }

  nlp = {
    ...nlp,
    topics: enrichTopics(nlp.topics)
  };

  const baseEvent = buildEventAnalysis({
    records: clean.records,
    eventMaterial: dataset.eventMaterial,
    keywords,
    sentiment,
    trend,
    dashboard,
    topics: nlp.topics
  });
  const event = await refineEventAnalysisWithDeepSeek(baseEvent, {
    records: clean.records,
    eventMaterial: dataset.eventMaterial,
    keywords,
    sentiment,
    trend,
    dashboard,
    topics: nlp.topics
  });

  dashboard = {
    ...dashboard,
    overallStatus: event.stage,
    judgment: `${event.summary}${event.prediction.result}${event.prediction.advice}`
  };

  nlp = {
    ...nlp,
    risk: {
      ...nlp.risk,
      riskLevel: dashboard.riskLevel,
      reason: dashboard.judgment
    }
  };

  return {
    id: taskId,
    datasetId: dataset.id,
    dataset,
    clean,
    keywords,
    lexicon,
    sentiment,
    trend,
    timeline,
    dashboard,
    nlp,
    event,
    analysisMode: nlpRaw || (sentimentRaw?.mode && sentimentRaw.mode !== "fallback") ? "nlp" : "basic",
    modelInfo,
    createdAt: new Date().toISOString()
  };
}
