const neutralEmojiTokens = new Set([
  "doge",
  "call",
  "打call",
  "允悲",
  "笑cry",
  "二哈",
  "摊手",
  "吃瓜",
  "裂开",
  "苦涩",
  "泪",
  "泪目",
  "哈哈",
  "哈哈哈",
  "haha",
  "hhh",
  "xswl",
  "awsl",
  "lol"
]);

const lowInformationLatinTokens = new Set([
  "doge",
  "call",
  "haha",
  "hhh",
  "xswl",
  "awsl",
  "lol"
]);

function compactEmojiToken(value: string) {
  return value.replace(/[\s_~-]+/g, "").trim().toLowerCase();
}

export function normalizeSocialText(value: string) {
  return String(value || "")
    .replace(/\[([^[\]]{1,24})\]/g, (_match, raw: string) => {
      const token = compactEmojiToken(raw);
      return neutralEmojiTokens.has(token) ? " " : " ";
    })
    .replace(/(^|[\s,，。?!？！:：])doge(?=$|[\s,，。?!？！:：])/gi, " ")
    .replace(/(^|[\s,，。?!？！:：])(?:打\s*)?call(?=$|[\s,，。?!？！:：])/gi, " ");
}

export function isLowInformationLatinToken(token: string) {
  return lowInformationLatinTokens.has(token.toLowerCase());
}
