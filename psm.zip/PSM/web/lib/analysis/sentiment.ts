import type { OpinionRecord, SentimentLabel, SentimentRecord, SentimentSummary } from "@/lib/types";

const positiveWords = [
  "支持", "认可", "满意", "理解", "期待", "希望", "赞同", "合理", "有效", "接受", "喜欢", "推荐",
  "精彩", "好看", "优秀", "很棒", "真好", "挺好", "不错", "厉害", "太棒", "牛", "点赞", "赞",
  "漂亮", "超级漂亮", "精致", "想买", "值得买", "抢手", "热门", "爆款",
  "种草", "惊艳", "有创意", "有质感", "审美在线", "设计感", "文化底蕴", "国潮",
  "祝贺", "恭喜", "开心", "高兴", "快乐", "好消息", "成功", "胜利", "骄傲", "自豪", "感动",
  "文化自信", "申遗成功", "春节申遗", "保护得好", "传承得好",
  "珍贵", "珍惜", "认同", "鼓励", "欢迎", "壮观", "有排面", "泪目", "感谢", "正能量",
  "合作共赢", "共赢", "和平发展", "友好", "真诚", "诚意", "求同存异", "携手共进",
  "震撼", "太帅", "好帅", "帅炸", "燃", "热血", "绝了", "炸裂", "牛逼", "有生命力",
  "看哭", "开眼", "起鸡皮疙瘩", "有功夫", "气势", "整齐", "阳刚", "英姿", "传承下去",
  "驱祸避恶", "招福献瑞", "万世永昌", "断孽破邪",
  "华夏", "活过来", "青山", "妩媚", "山水", "舞美", "配色", "国风", "绝美", "封神",
  "高级", "文艺复兴", "只此青绿", "千里江山", "备受震惊"
];

const negativeWords = [
  "失望", "质疑", "担心", "愤怒", "离谱", "敷衍", "糟糕", "不满", "欺骗", "风险", "混乱",
  "拖延", "隐瞒", "不信任", "反对", "无聊", "尴尬", "疲劳", "退票", "没回应", "博弈",
  "波动", "笑话", "恶心", "丢人", "造假", "抄袭", "争议", "无语", "太贵", "刺耳", "不合理",
  "杂乱", "严重", "没有美感", "过度商业化", "割韭菜", "同质化", "伪国潮", "质量差",
  "侵权", "翻译争议", "误读", "担忧", "黑", "骂", "不好看", "不喜欢", "不值", "买不起",
  "没舍得买", "没钱", "太大了", "排队", "排不到", "没货", "缺货", "劝退", "坑",
  "不需要", "不划算", "不值得", "溢价", "下不去手", "消费不起", "价格劝退",
  "智商税", "套路", "拉胯", "不思进取", "不考虑创新", "接不住", "没法正常", "差距大",
  "坏处", "抢掉", "抢名额", "预约名额", "预约不上", "约不上", "难约", "抢门票", "名额被抢",
  "黄牛", "倒卖", "代购", "加价", "被挤占", "挤占", "正常想逛", "抢到第三个星期"
];

const lowInfoPatterns = [
  /^(\[?(doge|call|允悲|笑cry|哈哈|哈哈哈|嘻嘻|666|good|ok|回复|转发)\]?)+$/i,
  /^[\s\p{P}\p{S}]{1,8}$/u,
  /^回复\s*@/i
];

function compact(content: string) {
  return content.replace(/\s+/g, "").trim();
}

function hasNegationBefore(text: string, index: number) {
  const prefix = text.slice(Math.max(0, index - 5), index);
  return /(不|没|没有|无|别|并不|不是|讨厌|反感)$/.test(prefix);
}

function contrastNeutralContext(content: string) {
  return /(没看过|没看懂|看不懂|不熟|不了解).{0,24}(但是|但|不过|然而|可是|却|只是).{0,32}(震惊|备受震惊|记住|印象|有点意思|还行)/.test(content);
}

function literaryQuoteNeutralContext(content: string) {
  const body = content.replace(/[\s，,。！？!?.；;：:、]+/g, "");
  return body === "小山重叠金明灭";
}

function culturalPerformancePositiveContext(content: string) {
  return /华夏.*活过来|活过来.*华夏|青山.*妩媚|料青山.*如是|文化自信|文艺复兴|只此青绿|千里江山|国风.*(美|绝|高级)|舞美.*(好|美|绝)|配色.*(好|美|舒服)|审美.*(好|高级|绝)/.test(content);
}

function scoreWords(text: string) {
  let positive = 0;
  let negative = 0;
  for (const word of positiveWords) {
    let index = text.indexOf(word);
    while (index >= 0) {
      if (hasNegationBefore(text, index)) negative += 1.35;
      else positive += word.length >= 4 ? 1.25 : 1;
      index = text.indexOf(word, index + word.length);
    }
  }
  for (const word of negativeWords) {
    let index = text.indexOf(word);
    while (index >= 0) {
      if (hasNegationBefore(text, index)) positive += 0.8;
      else negative += word.length >= 3 ? 1.35 : 1;
      index = text.indexOf(word, index + word.length);
    }
  }
  return { positive, negative };
}

function phraseBoost(content: string) {
  let positive = 0;
  let negative = 0;
  if (/申遗.*成功|成功.*申遗|春节.*成功|好消息|太棒了|我们的|属于我们|文化自信|传统文化.*传承/.test(content)) positive += 2.4;
  if (/祝贺|恭喜|骄傲|自豪|厉害|点赞|支持|期待|终于/.test(content)) positive += 1;
  if (/震撼|太帅|好帅|帅炸|燃|热血|绝了|炸裂|牛逼|有生命力|看哭|开眼|起鸡皮疙瘩|有功夫|气势.*足|鼓点.*(强|震撼|带劲)|整齐|阳刚|英姿|传承下去/.test(content)) positive += 2.1;
  if (/(上春晚|全国看到|让更多人看到|走出去|出圈|火起来|发扬光大|继续传承)/.test(content)) positive += 2;
  if (/(但是|但|不过|然而|可是|却|只是).*(英歌|英歌舞|传统文化|非遗).*(能|一定|想|值得|应该|必须|可以).*(爬起来|看|看到|支持|传承|出圈|火|上春晚)/.test(content)) positive += 3;
  if (culturalPerformancePositiveContext(content)) positive += 3;
  if (/(超级)?漂亮|好看|精致|想买|值得买|抢手|爆款|太热门/.test(content)) positive += 1.8;
  if (/(漂亮|好看|精致|想买|值得买).*(抢|没抢上|抢不到|一个多月)/.test(content) && !/(预约名额|名额被抢|抢掉|黄牛|倒卖|加价|正常想逛)/.test(content)) positive += 2.2;
  if (/不是我们的|被偷|抢走|文化被偷|翻译.*争议|韩国.*农历|担心.*误读/.test(content)) negative += 1.4;
  if (/太贵|价格.*高|价格.*贵|价格.*不需要|价格.*劝退|没舍得买|买不起|不需要|不划算|不值得|不值|下不去手|割韭菜|抄袭|质量差|过度商业化|不配|丢人|恶心|无语/.test(content)) negative += 2.4;
  if (/(价格|售价|定价|卖|要)\s*[0-9０-９]{1,5}\s*(元|块|￥)?/.test(content) && /(不需要|劝退|不值|不划算|下不去手|买不起|瞬间|算了|放弃)/.test(content)) negative += 3.2;
  if (/不思进取|不考虑创新|不懂.*消费|接不住|没法正常|差距.*大|劝退|排队.*(久|长)|抢不到|排不到/.test(content)) negative += 2.2;
  if (/坏处|预约名额.*抢|抢.*预约名额|名额.*被.*抢|门票.*(抢|约不上|难约)|正常想逛.*抢|抢掉|黄牛|倒卖|代购|加价/.test(content)) negative += 3.2;
  if (/阴阳怪气|呵呵|笑死|真会|服了/.test(content) && /(不|没|贵|差|烂|坑|离谱|无语)/.test(content)) negative += 1.4;
  return { positive, negative };
}

function splitClauses(content: string) {
  return content
    .replace(/(但是|但|不过|然而|可是|却|只是)/g, "，$1")
    .split(/[，,。；;！!？?\n\r]+/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function isContrastClause(clause: string) {
  return /^(但是|但|不过|然而|可是|却|只是)/.test(clause);
}

function consumerNegativeContext(content: string) {
  return /(价格|售价|定价|卖|要)\s*[0-9０-９]{1,5}\s*(元|块|￥)?/.test(content) && /(不需要|劝退|不值|不划算|下不去手|买不起|瞬间|算了|放弃)/.test(content);
}

function scoreTextEvidence(content: string) {
  const clauses = splitClauses(content);
  if (!clauses.length) {
    const scored = scoreWords(content);
    const boosted = phraseBoost(content);
    return { positive: scored.positive + boosted.positive, negative: scored.negative + boosted.negative };
  }

  let positive = 0;
  let negative = 0;
  let contrastNegative = false;
  let repeatedNegativeClauses = 0;
  let repeatedPositiveClauses = 0;

  clauses.forEach((clause, index) => {
    const scored = scoreWords(clause);
    const boosted = phraseBoost(clause);
    const clausePositive = scored.positive + boosted.positive;
    const clauseNegative = scored.negative + boosted.negative;
    const laterWeight = 1 + Math.min(index, 3) * 0.08;
    const contrastWeight = isContrastClause(clause) ? 1.85 : 1;
    const weight = laterWeight * contrastWeight;

    positive += clausePositive * weight;
    negative += clauseNegative * weight;

    if (clausePositive >= 1) repeatedPositiveClauses += 1;
    if (clauseNegative >= 1) repeatedNegativeClauses += 1;
    if (isContrastClause(clause) && clauseNegative >= clausePositive) contrastNegative = true;
  });

  const whole = phraseBoost(content);
  positive += whole.positive * 0.35;
  negative += whole.negative * 0.45;

  if (contrastNegative) negative += 1.6;
  if (repeatedNegativeClauses >= 2) negative += 1.4;
  if (repeatedPositiveClauses >= 2) positive += 1.1;
  if (consumerNegativeContext(content)) negative += 2.8;

  return { positive, negative };
}

function textSignal(content: string) {
  const body = compact(content);
  if (!body || body.length <= 2) return { label: "neutral" as SentimentLabel, strength: 0.15 };
  if (lowInfoPatterns.some((pattern) => pattern.test(body))) {
    return { label: "neutral" as SentimentLabel, strength: 0.2 };
  }
  if (literaryQuoteNeutralContext(content)) return { label: "neutral" as SentimentLabel, strength: 0.78 };
  if (contrastNeutralContext(content)) return { label: "neutral" as SentimentLabel, strength: 0.82 };

  const { positive, negative } = scoreTextEvidence(content);

  if (positive < 1 && negative < 1) return { label: "neutral" as SentimentLabel, strength: 0.22 };
  if (positive >= negative + 0.9) {
    const raw = (positive - negative) / Math.max(positive + negative, 1);
    return { label: "positive" as SentimentLabel, strength: Math.min(0.38 + raw * 0.62, 1) };
  }
  if (negative >= positive + 0.75) {
    const raw = (negative - positive) / Math.max(positive + negative, 1);
    return { label: "negative" as SentimentLabel, strength: Math.min(0.38 + raw * 0.62, 1) };
  }
  return { label: "neutral" as SentimentLabel, strength: 0.3 };
}

function ratingSignal(rating?: number | null) {
  if (rating === null || rating === undefined || !Number.isFinite(rating)) return null;
  if (rating >= 4) return { label: "positive" as SentimentLabel, score: rating >= 5 ? 94 : 82 };
  if (rating <= 2 && rating > 0) return { label: "negative" as SentimentLabel, score: rating <= 1 ? 92 : 78 };
  return { label: "neutral" as SentimentLabel, score: 58 };
}

export function classifySentiment(record: OpinionRecord): SentimentRecord {
  const rating = ratingSignal(record.rating);
  const text = textSignal(record.content);

  if (rating) {
    const sameDirection = text.label === rating.label || text.label === "neutral";
    const adjustedScore = sameDirection ? rating.score : Math.max(50, rating.score - 12);
    return { ...record, sentiment: rating.label, score: adjustedScore };
  }

  if (text.label === "positive") return { ...record, sentiment: "positive", score: Math.round(58 + text.strength * 36) };
  if (text.label === "negative") return { ...record, sentiment: "negative", score: Math.round(58 + text.strength * 36) };
  return { ...record, sentiment: "neutral", score: Math.round(50 + text.strength * 40) };
}

export function analyzeSentiment(records: OpinionRecord[]): SentimentSummary {
  const enriched = records.map(classifySentiment);
  const total = Math.max(enriched.length, 1);
  const share = (label: SentimentLabel) => enriched.filter((item) => item.sentiment === label).length / total;
  const trendMap = new Map<string, { date: string; positive: number; neutral: number; negative: number }>();

  enriched.forEach((item) => {
    if (!item.publishTime || item.missingFields?.includes("publishTime")) return;
    const date = item.publishTime.slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return;
    const row = trendMap.get(date) || { date, positive: 0, neutral: 0, negative: 0 };
    row[item.sentiment] += 1;
    trendMap.set(date, row);
  });

  const examples = (["positive", "neutral", "negative"] as SentimentLabel[])
    .flatMap((label) => enriched.filter((item) => item.sentiment === label).sort((a, b) => b.likeCount - a.likeCount).slice(0, 2))
    .slice(0, 6);

  return {
    positive: share("positive"),
    neutral: share("neutral"),
    negative: share("negative"),
    records: enriched,
    trend: [...trendMap.values()].sort((a, b) => a.date.localeCompare(b.date)),
    examples,
    basis: records.some((record) => record.rating !== null && record.rating !== undefined)
      ? "评论文本 + 用户评分"
      : "后台模型不可用时的本地语义词典校准"
  };
}
