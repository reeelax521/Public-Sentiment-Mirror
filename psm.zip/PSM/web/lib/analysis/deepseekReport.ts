import { createDeepSeekChatCompletion, isDeepSeekConfigured } from "@/lib/deepseekClient";
import { buildReportHtml, generateReport } from "@/lib/analysis/report";
import type { AnalysisTask, OpinionRecord, Report, SentimentLabel } from "@/lib/types";

function percent(value: number) {
  return `${Math.round(value * 100)}%`;
}

function clip(value: string | undefined, max = 140) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text.length > max ? `${text.slice(0, max)}...` : text;
}

function terms(items: Array<{ word?: string; term?: string; count: number }> | undefined, limit = 8) {
  return items?.slice(0, limit).map((item) => `${item.word || item.term}(${item.count})`).join("、") || "无";
}

function topicSummary(task: AnalysisTask) {
  const topics = task.nlp?.topics || [];
  if (!topics.length) return "未形成稳定主题";
  return topics.slice(0, 6)
    .map((topic) => `${topic.name}：${topic.percentage.toFixed(1)}%，关键词 ${topic.keywords.slice(0, 5).join("、") || "无"}`)
    .join("\n");
}

function platformSummary(task: AnalysisTask) {
  const platforms = task.dashboard.platformDistribution || [];
  if (!platforms.length) return "无明确平台字段";
  const total = Math.max(platforms.reduce((sum, item) => sum + item.count, 0), 1);
  return platforms
    .slice(0, 6)
    .map((item) => `${item.platform}：${item.count}条，约${Math.round((item.count / total) * 100)}%`)
    .join("；");
}

function riskRadarSummary(task: AnalysisTask) {
  const radar = task.dashboard.riskRadar || [];
  if (!radar.length) return "无风险雷达数据";
  return radar.map((item) => `${item.metric}=${item.value}`).join("；");
}

function sentimentExamples(task: AnalysisTask, label: SentimentLabel, limit = 3) {
  return task.sentiment.records
    .filter((record) => record.sentiment === label)
    .sort((a, b) => b.likeCount - a.likeCount)
    .slice(0, limit)
    .map((record) => `- ${clip(record.content, 120)}`)
    .join("\n") || "- 无";
}

function topRecord(records: OpinionRecord[]) {
  const record = [...records].sort((a, b) => b.likeCount - a.likeCount)[0];
  if (!record) return "无";
  return `${clip(record.content, 160)}（点赞 ${record.likeCount}）`;
}

function trendDigest(task: AnalysisTask) {
  if (!task.trend.length) return "未识别到有效时间序列";
  const peak = task.trend.reduce((best, item) => item.heat > best.heat ? item : best, task.trend[0]);
  return `时间范围 ${task.trend[0].date} 至 ${task.trend[task.trend.length - 1].date}；峰值日期 ${peak.date}，热度 ${peak.heat}，评论 ${peak.comments}，点赞 ${peak.likes}`;
}

function buildDeepSeekPrompt(task: AnalysisTask) {
  return `你是中文网络舆情分析师。请基于下面结构化结果，为报告生成一个额外的 Markdown 小节。

要求：
1. 只输出一个小节，标题固定为 "## 智能辅助摘要"。
2. 使用中文，控制在 900 字以内。
3. 必须包含三个三级标题："### 核心判断"、"### 风险关注"、"### 后续建议"。
4. 必须解释平台来源图、词云图、关键词排行图、主题分布图、风险雷达图各自说明了什么。
5. 先解释事件与公众关注，再解释风险；不要一开始就下风险结论。
6. 最终判断必须围绕事件本身，不要只复述比例和表格。
7. 不要编造输入中没有的数据，不要输出代码块，不要重复完整表格。
8. 用稳健、克制的研判语气，面向公众可读报告，不要暴露任何后端模型或供应商名称。

结构化分析结果：
- 数据集：${task.dataset.name}
- 有效样本：${task.clean.validCount}/${task.clean.originalCount}
- 数据类型：${task.dashboard.sourceMode}
- 事件名称：${task.event?.name || "未识别"}
- 事件类别：${task.event?.category || "未识别"}
- 事件类型：${task.event?.eventType || "未识别"}
- 核心主体：${task.event?.subjects?.join("、") || "未识别"}
- 核心争议：${task.event?.coreIssues?.join("、") || "未识别"}
- 当前阶段：${task.event?.stage || task.dashboard.overallStatus}
- 短期趋势：${task.event?.prediction?.result || "未识别"}
- 优先关注：${task.event?.prediction?.advice || "未识别"}
- 主要平台：${task.dashboard.majorPlatform || "未识别"}
- 平台来源图：${platformSummary(task)}
- 综合状态：${task.dashboard.overallStatus}
- 风险等级：${task.dashboard.riskLevel}
- 风险判断：${task.dashboard.judgment}
- 风险雷达图：${riskRadarSummary(task)}
- 情感分布：正面 ${percent(task.sentiment.positive)}，中性 ${percent(task.sentiment.neutral)}，负面 ${percent(task.sentiment.negative)}
- 热度趋势：${trendDigest(task)}
- 词云与关键词排行：${terms(task.keywords, 10)}
- 议题词：${terms(task.lexicon.targets, 8)}
- 情绪词：${terms(task.lexicon.emotions, 8)}
- 立场词：${terms(task.lexicon.stances, 8)}
- 主题摘要：
${topicSummary(task)}
- 点赞最高评论：${topRecord(task.clean.records)}
- 负面代表评论：
${sentimentExamples(task, "negative")}
- 正面代表评论：
${sentimentExamples(task, "positive")}`;
}

function normalizeDeepSeekSection(content: string) {
  const stripped = content
    .replace(/^```(?:markdown)?/i, "")
    .replace(/```$/i, "")
    .trim();

  return stripped.startsWith("## 智能辅助摘要")
    ? stripped
    : `## 智能辅助摘要\n\n${stripped}`;
}

function insertAfterTitle(markdown: string, section: string) {
  const firstSection = markdown.indexOf("\n## ");
  if (firstSection === -1) return `${markdown}\n\n${section}`;
  return `${markdown.slice(0, firstSection)}\n\n${section}\n${markdown.slice(firstSection)}`;
}

export async function generateReportWithDeepSeek(task: AnalysisTask): Promise<Report> {
  const baseReport = generateReport(task);
  if (!isDeepSeekConfigured()) return baseReport;

  try {
    const completion = await createDeepSeekChatCompletion({
      maxTokens: 1300,
      messages: [
        {
          role: "system",
          content: "你负责把结构化舆情分析结果转写为可靠、克制、可复核的中文研判摘要。"
        },
        {
          role: "user",
          content: buildDeepSeekPrompt(task)
        }
      ]
    });

    if (!completion?.content) return baseReport;

    const deepSeekSection = normalizeDeepSeekSection(completion.content);
    const markdown = insertAfterTitle(baseReport.markdown, deepSeekSection);

    return {
      ...baseReport,
      markdown,
      txt: markdown.replace(/^#+\s/gm, ""),
      html: buildReportHtml(markdown)
    };
  } catch (error) {
    console.warn("DeepSeek report enhancement failed", error);
    return baseReport;
  }
}
