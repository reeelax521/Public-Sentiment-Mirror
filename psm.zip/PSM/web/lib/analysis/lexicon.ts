import { extractKeywords } from "@/lib/analysis/keywords";
import type { DataProfile, LexiconAnalysis, LexiconItem, OpinionRecord } from "@/lib/types";

const publicTargets = [
  "官方", "政府", "部门", "机构", "企业", "品牌", "商家", "学校", "景区", "博物馆", "博物院",
  "国家博物馆", "故宫", "文创品牌", "平台", "消费者", "游客", "产品", "作品", "政策", "规则", "公告",
  "凤冠冰箱贴", "冰箱贴", "文创产品"
];

const movieContentObjects = ["剧情", "叙事", "故事", "节奏", "逻辑", "结尾", "彩蛋", "漫威", "电影", "续集"];
const movieCharacters = ["角色", "英雄", "反派", "钢铁侠", "美国队长", "绿巨人", "雷神", "黑寡妇", "鹰眼", "女巫", "快银", "奥创", "复仇者"];
const movieExperience = ["特效", "视觉", "场面", "打斗", "动作", "配乐", "镜头", "翻译", "字幕", "影院", "观影", "好看", "精彩"];
const movieEmotion = [
  { term: "好看", tone: "positive" },
  { term: "精彩", tone: "positive" },
  { term: "推荐", tone: "positive" },
  { term: "燃", tone: "positive" },
  { term: "感动", tone: "positive" },
  { term: "失望", tone: "negative" },
  { term: "疲劳", tone: "negative" },
  { term: "无聊", tone: "negative" },
  { term: "一般", tone: "neutral" },
  { term: "普通", tone: "neutral" }
] as const;
const movieControversy = ["剧情薄弱", "节奏混乱", "反派", "翻译", "剪辑", "套路", "审美疲劳", "口碑分化", "不如", "失望"];

const publicEmotion = [
  { term: "担心", tone: "negative" },
  { term: "质疑", tone: "negative" },
  { term: "不满", tone: "negative" },
  { term: "失望", tone: "negative" },
  { term: "愤怒", tone: "negative" },
  { term: "焦虑", tone: "negative" },
  { term: "没回答", tone: "negative" },
  { term: "敷衍", tone: "negative" },
  { term: "安心", tone: "positive" },
  { term: "满意", tone: "positive" },
  { term: "认可", tone: "positive" },
  { term: "理解", tone: "positive" },
  { term: "支持", tone: "positive" },
  { term: "期待", tone: "positive" },
  { term: "期盼", tone: "positive" },
  { term: "盼", tone: "positive" },
  { term: "愉快", tone: "positive" },
  { term: "厉害", tone: "positive" },
  { term: "豪华", tone: "positive" },
  { term: "重大", tone: "positive" },
  { term: "共赢", tone: "positive" },
  { term: "哈哈", tone: "positive" },
  { term: "观望", tone: "neutral" },
  { term: "希望", tone: "neutral" }
] as const;

const publicStance = [
  { term: "支持", tone: "positive" },
  { term: "反对", tone: "negative" },
  { term: "质疑", tone: "negative" },
  { term: "建议", tone: "neutral" },
  { term: "要求", tone: "negative" },
  { term: "接受", tone: "positive" },
  { term: "观望", tone: "neutral" },
  { term: "不信任", tone: "negative" },
  { term: "需要解释", tone: "negative" },
  { term: "可以理解", tone: "positive" },
  { term: "继续观察", tone: "neutral" },
  { term: "合作共赢", tone: "positive" },
  { term: "求同存异", tone: "positive" },
  { term: "携手共进", tone: "positive" },
  { term: "和平发展", tone: "positive" },
  { term: "以礼相待", tone: "positive" },
  { term: "以诚相交", tone: "positive" },
  { term: "希望尽快", tone: "neutral" }
] as const;

const genericTargetStopwords = new Set([
  "哈哈", "评论", "内容", "事情", "什么", "一个", "没有", "这个", "那个", "可以", "普通", "精彩", "故事",
  "这次", "带来", "一定", "更多", "作为", "就是", "还是", "感觉", "真的",
  "回复", "视频", "弹幕", "观点", "平台", "媒体", "用户", "网友", "数据", "文本", "样本",
  "转发", "点赞", "播放", "投币", "收藏", "评论区", "原帖", "正文", "标题", "来源", "发布",
  "回应", "处理", "结果", "反馈", "很多", "下面", "主要", "看到", "更多", "大家", "有人",
  "这么", "怎么", "地方", "好看", "喜欢", "漂亮", "确实", "一般", "精致", "便宜", "流量",
  "博物", "旅游", "还有", "不到", "排队", "网上"
]);

const targetDenyTerms = new Set([
  ...publicEmotion.map((item) => item.term),
  ...publicStance.map((item) => item.term),
  "价格", "质量", "体验", "安全", "风险", "投诉", "活动", "项目", "遗产", "文化", "传统", "非遗",
  "服务", "消费", "商业化", "真实性", "争议", "翻译", "传播", "合作", "发展", "期待"
]);

const targetSuffixPattern = /(馆|院|宫|局|部|会|司|店|校|府|景区|品牌|机构|企业|公司|官方|产品|作品|冰箱贴|文创|游客|消费者)$/;
const concreteObjectPattern = /(凤冠|冰箱贴|文创|盲盒|周边|产品|作品|博物馆|博物院|景区|品牌|学校|企业|机构|官方)/;

function isTargetLikeTerm(term: string) {
  if (!term || genericTargetStopwords.has(term)) return false;
  if (targetDenyTerms.has(term)) return false;
  if (/^\d+$/.test(term)) return false;
  if (/^(回复|评论|视频|弹幕|内容|观点|平台|媒体|用户|网友|来源|标题|正文)$/.test(term)) return false;
  if (/^(第|一个|一种|一些|这个|那个|可以|应该|怎么|什么)/.test(term)) return false;
  if (term.length < 2 || term.length > 12) return false;
  if (/^(好|很|太|真|挺|不|没|还|又|再|都|这|那)/.test(term) && !concreteObjectPattern.test(term)) return false;
  return publicTargets.includes(term) || targetSuffixPattern.test(term) || concreteObjectPattern.test(term);
}

function collectTerms(
  records: OpinionRecord[],
  terms: ReadonlyArray<string | { term: string; tone?: LexiconItem["tone"] }>,
  limit = 12
): LexiconItem[] {
  return terms
    .map((entry) => {
      const term = typeof entry === "string" ? entry : entry.term;
      const matches = records.filter((record) => record.content.includes(term));
      return {
        term,
        count: matches.length,
        tone: typeof entry === "string" ? undefined : entry.tone,
        examples: matches.slice(0, 2).map((record) => record.content)
      };
    })
    .filter((item) => item.count > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, limit);
}

function uniqueObjectTerms(records: OpinionRecord[]) {
  const names = new Map<string, LexiconItem>();
  records.forEach((record) => {
    if (!record.objectName) return;
    const item = names.get(record.objectName) || { term: record.objectName, count: 0, examples: [] };
    item.count += 1;
    if (item.examples.length < 2) item.examples.push(record.content);
    names.set(record.objectName, item);
  });
  return [...names.values()].sort((a, b) => b.count - a.count).slice(0, 8);
}

function keywordTargets(records: OpinionRecord[], existing: LexiconItem[], limit = 8) {
  const used = new Set(existing.map((item) => item.term));
  return extractKeywords(records, 24)
    .filter((item) => !used.has(item.word) && isTargetLikeTerm(item.word))
    .filter((item) => item.count >= 2)
    .slice(0, limit)
    .map((item) => ({
      term: item.word,
      count: item.count,
      examples: records.filter((record) => record.content.includes(item.word)).slice(0, 2).map((record) => record.content)
    }));
}

export function extractLexicon(records: OpinionRecord[], dataProfile?: DataProfile): LexiconAnalysis {
  const isMovieReview = dataProfile === "movie_review";
  if (isMovieReview) {
    const contentObjects = collectTerms(records, movieContentObjects);
    const characters = collectTerms(records, movieCharacters);
    const viewingExperience = collectTerms(records, movieExperience);
    const emotionEvaluations = collectTerms(records, movieEmotion);
    const controversyFocus = collectTerms(records, movieControversy);
    return {
      targets: [...uniqueObjectTerms(records), ...contentObjects].slice(0, 12),
      emotions: emotionEvaluations,
      stances: controversyFocus,
      contentObjects,
      characters,
      viewingExperience,
      emotionEvaluations,
      controversyFocus
    };
  }

  const targets = collectTerms(records, publicTargets).filter((item) => isTargetLikeTerm(item.term));
  const emotions = collectTerms(records, publicEmotion);
  const stances = collectTerms(records, publicStance);
  const mergedTargets = [...targets, ...keywordTargets(records, targets)]
    .filter((item, index, all) => all.findIndex((other) => other.term === item.term) === index)
    .sort((a, b) => b.count - a.count)
    .slice(0, 12);
  return {
    targets: mergedTargets,
    emotions,
    stances
  };
}
