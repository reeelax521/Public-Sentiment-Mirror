export type SentimentLabel = "positive" | "neutral" | "negative";
export type RiskLevel = "low" | "medium" | "high" | "critical";
export type ModelStatus = "active" | "fallback" | "planned";
export type DatasetKind = "platform_opinion" | "object_review" | "generic_comment";
export type DataProfile = "movie_review" | "news_comment" | "danmaku" | "platform_comment" | "plain_text" | "generic_comment";

export interface FieldMapping {
  textField?: string;
  timeField?: string;
  ratingField?: string;
  likeField?: string;
  userField?: string;
  userIdField?: string;
  objectField?: string;
  objectAliasField?: string;
  collectedAtField?: string;
  platformField?: string;
  staticPlatform?: string;
  sourceUrlField?: string;
  areaField?: string;
  metadataFields?: string[];
  availableFields?: string[];
  dataProfile?: DataProfile;
  ignoredFields: string[];
  detectedKind: DatasetKind;
}

export interface OpinionRecord {
  id: string;
  platform: string;
  content: string;
  publishTime: string;
  likeCount: number;
  commentCount: number;
  repostCount: number;
  objectName?: string;
  objectAlias?: string;
  username?: string;
  userId?: string;
  rating?: number | null;
  collectedAt?: string;
  sourceUrl?: string;
  area?: string;
  metadata?: Record<string, string | number | boolean | null>;
  missingFields?: string[];
  inferredFields?: string[];
}

export interface DatasetSourceFile {
  id: string;
  name: string;
  recordsParsed: number;
  recordsIncluded: number;
  sampled: boolean;
  kind: DatasetKind;
  dataProfile?: DataProfile;
  platformName?: string;
  objectName?: string;
  fieldMapping: FieldMapping;
}

export interface Dataset {
  id: string;
  name: string;
  source: string;
  records: OpinionRecord[];
  createdAt: string;
  kind: DatasetKind;
  fieldMapping: FieldMapping;
  sourceFiles?: DatasetSourceFile[];
  eventMaterial?: string;
}

export interface DataQualityIssue {
  field: string;
  label: string;
  count: number;
  rate: number;
  severity: "info" | "warning" | "critical";
  impact: string;
}

export interface DataQualitySummary {
  missingContentCount: number;
  missingPublishTimeCount: number;
  missingPlatformCount: number;
  missingLikeCount: number;
  missingRatingCount: number;
  missingUserCount: number;
  inferredPublishTimeCount: number;
  validTimeCount: number;
  completenessScore: number;
  issues: DataQualityIssue[];
}

export interface CleanIssueSample {
  id: string;
  content: string;
  platform?: string;
  publishTime?: string;
  username?: string;
  likeCount?: number;
  reason: string;
}

export interface CleanResult {
  originalCount: number;
  duplicateCount: number;
  emptyCount: number;
  validCount: number;
  tooShortCount: number;
  lowQualityCount: number;
  semanticAnomalyCount: number;
  issueSamples?: {
    tooShort: CleanIssueSample[];
    lowQuality: CleanIssueSample[];
    semanticAnomaly: CleanIssueSample[];
  };
  records: OpinionRecord[];
  quality: DataQualitySummary;
}

export interface KeywordItem {
  word: string;
  count: number;
  weight: number;
}

export interface LexiconItem {
  term: string;
  count: number;
  tone?: SentimentLabel | "mixed";
  examples: string[];
}

export interface LexiconAnalysis {
  targets: LexiconItem[];
  emotions: LexiconItem[];
  stances: LexiconItem[];
  contentObjects?: LexiconItem[];
  characters?: LexiconItem[];
  viewingExperience?: LexiconItem[];
  emotionEvaluations?: LexiconItem[];
  controversyFocus?: LexiconItem[];
}

export interface SentimentRecord extends OpinionRecord {
  sentiment: SentimentLabel;
  score: number;
}

export interface SentimentSummary {
  positive: number;
  neutral: number;
  negative: number;
  records: SentimentRecord[];
  trend: Array<{ date: string; positive: number; neutral: number; negative: number }>;
  examples: SentimentRecord[];
  basis: string;
}

export interface TrendPoint {
  date: string;
  heat: number;
  comments: number;
  interactions: number;
  likes: number;
  negativeRate: number;
  movingAverage: number;
}

export interface TimelineNode {
  stage: string;
  time: string;
  summary: string;
  volume: number;
  heat: number;
  emotionChange: string;
  risk: RiskLevel;
}

export interface DashboardData {
  totalComments: number;
  heatIndex: number;
  negativeRate: number;
  peakTime: string;
  majorPlatform: string;
  riskLevel: RiskLevel;
  platformDistribution: Array<{ platform: string; count: number }>;
  objectDistribution: Array<{ objectName: string; objectAlias?: string; count: number }>;
  sourceMode: DatasetKind;
  objectName?: string;
  objectAlias?: string;
  ratingAverage?: number;
  ratingDistribution?: Array<{ rating: string; count: number }>;
  totalLikes: number;
  topLikedComment?: SentimentRecord;
  collectedAt?: string;
  peakCommentCount: number;
  peakLikeCount: number;
  relativeGrowthRate: number;
  propagationHeat: "低" | "中" | "高";
  negativeRisk: "低" | "中" | "高";
  overallStatus: string;
  riskRadar: Array<{ metric: string; value: number }>;
  judgment: string;
}

export interface ClusterItem {
  clusterId: number;
  label: string;
  size: number;
  percentage: number;
  topTerms: string[];
  representativeTexts: string[];
  coordinates?: Array<{ x: number; y: number; clusterId: number; text?: string }>;
  sentimentTendency?: "正面" | "中性" | "负面" | "分化";
  riskLevel?: "低" | "中" | "高";
  judgment?: string;
}

export interface TopicItem {
  topicId: number;
  name: string;
  size: number;
  percentage: number;
  keywords: string[];
  representativeTexts: string[];
  sentimentTendency?: "正面" | "中性" | "负面" | "分化";
  riskLevel?: "低" | "中" | "高";
  judgment?: string;
}

export interface EventKeywordGroups {
  eventSubjects: LexiconItem[];
  culturalValues: LexiconItem[];
  consumerEvaluations: LexiconItem[];
  riskDisputes: LexiconItem[];
  growthHotspots: LexiconItem[];
}

export interface SentimentDriver {
  label: "正面" | "中性" | "负面";
  reasons: string[];
  representativeExpressions: string[];
}

export interface ShortTermPrediction {
  heatSlope: "上升" | "平稳" | "下降" | "不足";
  negativeChange: "上升" | "持平" | "下降" | "不足";
  growthKeywords: string[];
  result: string;
  confidence: "低" | "中" | "高";
  basis: string;
  advice: string;
}

export interface EventTimelineInsight {
  time: string;
  eventNode: string;
  dataSignal: string;
  systemJudgment: string;
}

export interface EventBrief {
  what?: string;
  when?: string;
  where?: string;
  who: string[];
  why?: string;
  how?: string;
}

export interface EventDynamicField {
  label: string;
  value: string;
  evidence?: string;
  confidence?: "低" | "中" | "高";
}

export interface EventAnalysis {
  name: string;
  category: string;
  eventType: string;
  subjects: string[];
  coreIssues: string[];
  stage: string;
  summary: string;
  materialExcerpt?: string;
  brief: EventBrief;
  dynamicFields: EventDynamicField[];
  recognitionMode?: "deepseek" | "rules";
  keywordGroups: EventKeywordGroups;
  sentimentDrivers: SentimentDriver[];
  prediction: ShortTermPrediction;
  timeline: EventTimelineInsight[];
  opportunities: string[];
  risks: string[];
  recommendations: Array<{ target: string; advice: string }>;
}

export interface NlpRiskResult {
  riskLevel: RiskLevel;
  riskScore: number;
  reason: string;
}

export interface NlpAnalysisResult {
  topics: TopicItem[];
  clusters: ClusterItem[];
  risk: NlpRiskResult;
  mode: "nlp" | "fallback" | "basic";
  warnings: string[];
}

export interface AnalysisModelInfo {
  name: string;
  role: string;
  status: ModelStatus;
  description: string;
}

export interface AnalysisTask {
  id: string;
  datasetId: string;
  dataset: Dataset;
  clean: CleanResult;
  keywords: KeywordItem[];
  lexicon: LexiconAnalysis;
  sentiment: SentimentSummary;
  trend: TrendPoint[];
  timeline: TimelineNode[];
  dashboard: DashboardData;
  nlp: NlpAnalysisResult;
  event: EventAnalysis;
  analysisMode: "nlp" | "basic";
  modelInfo: AnalysisModelInfo[];
  createdAt: string;
}

export interface Report {
  id: string;
  taskId: string;
  markdown: string;
  txt: string;
  html: string;
  createdAt: string;
}
