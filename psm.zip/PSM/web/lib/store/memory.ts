import type { AnalysisTask, Dataset, Report } from "@/lib/types";

const globalForStore = globalThis as unknown as {
  psmDatasets?: Map<string, Dataset>;
  psmTasks?: Map<string, AnalysisTask>;
  psmReports?: Map<string, Report>;
};

export const datasets = globalForStore.psmDatasets ?? new Map<string, Dataset>();
export const tasks = globalForStore.psmTasks ?? new Map<string, AnalysisTask>();
export const reports = globalForStore.psmReports ?? new Map<string, Report>();

globalForStore.psmDatasets = datasets;
globalForStore.psmTasks = tasks;
globalForStore.psmReports = reports;

