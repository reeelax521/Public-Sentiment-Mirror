type DeepSeekRole = "system" | "user" | "assistant";

export interface DeepSeekMessage {
  role: DeepSeekRole;
  content: string;
}

interface DeepSeekChatResponse {
  choices?: Array<{
    message?: {
      content?: string;
    };
  }>;
  error?: {
    message?: string;
  };
}

export interface DeepSeekRequestOptions {
  messages: DeepSeekMessage[];
  maxTokens?: number;
  responseFormat?: "json_object";
}

function getDeepSeekConfig() {
  const apiKey = process.env.DEEPSEEK_API_KEY;
  const baseUrl = (process.env.DEEPSEEK_BASE_URL || "https://api.deepseek.com").replace(/\/$/, "");
  const model = process.env.DEEPSEEK_MODEL || "deepseek-v4-flash";
  const timeoutMs = Number(process.env.DEEPSEEK_TIMEOUT_MS || 45000);
  const thinkingType = process.env.DEEPSEEK_THINKING === "enabled" ? "enabled" : "disabled";
  const reasoningEffort = process.env.DEEPSEEK_REASONING_EFFORT || "high";
  const temperature = Number(process.env.DEEPSEEK_TEMPERATURE || 0.2);

  return {
    apiKey,
    baseUrl,
    model,
    timeoutMs,
    thinkingType,
    reasoningEffort,
    temperature
  };
}

export function isDeepSeekConfigured() {
  return Boolean(getDeepSeekConfig().apiKey);
}

export async function createDeepSeekChatCompletion(options: DeepSeekRequestOptions) {
  const config = getDeepSeekConfig();
  if (!config.apiKey) return null;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), config.timeoutMs);

  const body: Record<string, unknown> = {
    model: config.model,
    messages: options.messages,
    stream: false,
    max_tokens: options.maxTokens || 1200,
    thinking: { type: config.thinkingType }
  };

  if (options.responseFormat === "json_object") {
    body.response_format = { type: "json_object" };
  }

  if (config.thinkingType === "enabled") {
    body.reasoning_effort = config.reasoningEffort;
  } else {
    body.temperature = config.temperature;
  }

  try {
    const response = await fetch(`${config.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${config.apiKey}`
      },
      body: JSON.stringify(body),
      signal: controller.signal
    });

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      throw new Error(`DeepSeek request failed: ${response.status} ${detail}`);
    }

    const data = (await response.json()) as DeepSeekChatResponse;
    const content = data.choices?.[0]?.message?.content?.trim();
    if (!content) {
      throw new Error(data.error?.message || "DeepSeek returned an empty response");
    }

    return {
      content,
      model: config.model
    };
  } finally {
    clearTimeout(timeout);
  }
}
