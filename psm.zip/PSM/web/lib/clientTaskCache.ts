export function clearLegacyTaskCache() {
  if (typeof window === "undefined") return;
  try {
    for (let index = window.localStorage.length - 1; index >= 0; index -= 1) {
      const key = window.localStorage.key(index);
      if (key?.startsWith("psm-task-")) window.localStorage.removeItem(key);
    }
  } catch {
    // Storage can be blocked or full. The app can continue without browser task cache.
  }
}
