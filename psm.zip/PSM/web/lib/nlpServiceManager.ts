import { spawn } from "child_process";
import { existsSync } from "fs";
import path from "path";

const baseUrl = (process.env.NLP_SERVICE_URL || "http://localhost:8000").replace(/\/$/, "");
const autostartEnabled = process.env.NLP_SERVICE_AUTOSTART !== "false";
const warmupEnabled = process.env.NLP_SENTIMENT_WARMUP !== "false";

type NlpServiceStatus = {
  ok: boolean;
  started: boolean;
  reason?: string;
};

let startPromise: Promise<NlpServiceStatus> | null = null;

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function parseServiceUrl() {
  try {
    return new URL(baseUrl);
  } catch {
    return null;
  }
}

function isLocalService(url: URL | null) {
  if (!url) return false;
  return ["localhost", "127.0.0.1", "::1"].includes(url.hostname);
}

async function healthCheck(timeoutMs = 2500) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${baseUrl}/health`, { signal: controller.signal });
    return response.ok;
  } catch {
    return false;
  } finally {
    clearTimeout(timeout);
  }
}

async function warmupSentiment(timeoutMs = Number(process.env.NLP_SENTIMENT_WARMUP_TIMEOUT_MS || 180000)) {
  if (!warmupEnabled) return { ok: true, mode: "skipped" };
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${baseUrl}/warmup`, { signal: controller.signal });
    if (!response.ok) return { ok: false, mode: "unavailable", reason: `warmup status ${response.status}` };
    const data = await response.json() as { ok?: boolean; sentiment?: { mode?: string; engine?: string; ok?: boolean } };
    return {
      ok: Boolean(data.ok || data.sentiment?.ok),
      mode: data.sentiment?.mode || data.sentiment?.engine || "unknown"
    };
  } catch (error) {
    return {
      ok: false,
      mode: "unavailable",
      reason: error instanceof Error ? error.message : String(error)
    };
  } finally {
    clearTimeout(timeout);
  }
}

function nlpServiceDir() {
  return process.env.NLP_SERVICE_DIR || path.resolve(process.cwd(), "..", "nlp_service");
}

function pythonExecutable(serviceDir: string) {
  if (process.env.NLP_SERVICE_PYTHON) return process.env.NLP_SERVICE_PYTHON;
  const candidates = process.platform === "win32"
    ? [path.join(serviceDir, ".venv", "Scripts", "python.exe")]
    : [path.join(serviceDir, ".venv", "bin", "python")];
  return candidates.find((candidate) => existsSync(candidate)) || "python";
}

async function startAndWait(): Promise<NlpServiceStatus> {
  if (await healthCheck()) return { ok: true, started: false };

  const url = parseServiceUrl();
  if (!autostartEnabled) {
    return { ok: false, started: false, reason: "NLP_SERVICE_AUTOSTART=false，已关闭自动启动。" };
  }
  if (!isLocalService(url)) {
    return { ok: false, started: false, reason: `NLP 服务地址 ${baseUrl} 不是本机地址，无法由 Next.js 自动启动。` };
  }

  const serviceDir = nlpServiceDir();
  if (!existsSync(path.join(serviceDir, "main.py"))) {
    return { ok: false, started: false, reason: `未找到 Python NLP 服务目录：${serviceDir}` };
  }

  const host = url?.hostname === "localhost" ? "127.0.0.1" : url?.hostname || "127.0.0.1";
  const port = url?.port || "8000";
  const python = pythonExecutable(serviceDir);

  try {
    const child = spawn(python, ["-m", "uvicorn", "main:app", "--host", host, "--port", port], {
      cwd: serviceDir,
      detached: true,
      stdio: "ignore",
      windowsHide: true,
      env: {
        ...process.env,
        SENTIMENT_ENGINE: process.env.SENTIMENT_ENGINE || "bert",
        BERT_SENTIMENT_MODEL: process.env.BERT_SENTIMENT_MODEL || "uer/roberta-base-finetuned-jd-binary-chinese",
        SENTIMENT_RETURN_ITEMS_MAX: process.env.SENTIMENT_RETURN_ITEMS_MAX || "20000"
      }
    });
    child.unref();
  } catch (error) {
    return { ok: false, started: false, reason: `启动 NLP 服务失败：${error instanceof Error ? error.message : String(error)}` };
  }

  const waitMs = Number(process.env.NLP_SERVICE_STARTUP_TIMEOUT_MS || 45000);
  const startedAt = Date.now();
  while (Date.now() - startedAt < waitMs) {
    if (await healthCheck(4000)) {
      const warmup = await warmupSentiment();
      return warmup.ok
        ? { ok: true, started: true }
        : { ok: false, started: true, reason: `NLP 服务已启动，但情感模型预热失败：${warmup.reason || warmup.mode}` };
    }
    await delay(1200);
  }

  return { ok: false, started: true, reason: `NLP 服务已尝试启动，但 ${Math.round(waitMs / 1000)} 秒内未通过健康检查。` };
}

export async function ensureNlpService(): Promise<NlpServiceStatus> {
  if (await healthCheck()) {
    const warmup = await warmupSentiment();
    return warmup.ok
      ? { ok: true, started: false }
      : { ok: false, started: false, reason: `NLP 服务已连接，但情感模型预热失败：${warmup.reason || warmup.mode}` };
  }
  if (!startPromise) {
    startPromise = startAndWait().finally(() => {
      startPromise = null;
    });
  }
  return startPromise;
}
