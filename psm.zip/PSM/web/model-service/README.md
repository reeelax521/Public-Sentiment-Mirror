# Advanced Analysis Model Service

This optional FastAPI service is the planned production analysis layer for:

- SBERT semantic embeddings
- BERTopic topic modeling
- BERT sentiment classification

The Next.js app works without this service. When the service is running, set this environment variable before starting Next.js:

```bash
ADVANCED_ANALYSIS_URL=http://127.0.0.1:8600
```

## Local Run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 127.0.0.1 --port 8600
```

## Default Models

```bash
SBERT_MODEL=shibing624/text2vec-base-chinese
BERT_SENTIMENT_MODEL=uer/roberta-base-finetuned-jd-binary-chinese
```

The 2C2G ECS can run the Next.js app comfortably, but full BERTopic and transformer inference may need more memory. If model startup is slow or killed by the system, keep the model service on a larger machine and point `ADVANCED_ANALYSIS_URL` to that service.
