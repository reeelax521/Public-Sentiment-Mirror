# -*- coding: utf-8 -*-
import os
import re
from collections import Counter, defaultdict
from functools import lru_cache
from typing import Literal

from fastapi import FastAPI
from pydantic import BaseModel, Field


SentimentLabel = Literal["positive", "neutral", "negative"]


class OpinionRecord(BaseModel):
    id: str
    platform: str = "未知来源"
    content: str
    publishTime: str
    likeCount: int = 0
    commentCount: int = 0
    repostCount: int = 0


class AnalyzeRequest(BaseModel):
    datasetId: str
    records: list[OpinionRecord] = Field(default_factory=list)


app = FastAPI(title="Public Sentiment Mirror Advanced Model Service")

STOPWORDS = {
    "一个", "这个", "那个", "我们", "你们", "他们", "因为", "所以", "但是", "还是",
    "可以", "已经", "真的", "觉得", "需要", "大家", "问题", "进行", "没有"
}


@lru_cache(maxsize=1)
def get_sbert_model():
    from sentence_transformers import SentenceTransformer

    model_name = os.getenv("SBERT_MODEL", "shibing624/text2vec-base-chinese")
    return SentenceTransformer(model_name)


@lru_cache(maxsize=1)
def get_sentiment_pipeline():
    from transformers import pipeline

    model_name = os.getenv("BERT_SENTIMENT_MODEL", "uer/roberta-base-finetuned-jd-binary-chinese")
    return pipeline("text-classification", model=model_name, tokenizer=model_name, truncation=True)


def tokenize(text: str) -> list[str]:
    try:
        import jieba

        tokens = jieba.lcut(text)
    except Exception:
        tokens = re.findall(r"[\u4e00-\u9fa5]{2,}|[a-zA-Z0-9]{2,}", text)
    return [token.strip().lower() for token in tokens if len(token.strip()) > 1 and token.strip() not in STOPWORDS]


def fallback_keywords(texts: list[str], limit: int = 30):
    counter = Counter()
    for text in texts:
        counter.update(tokenize(text))
    if not counter:
        return []
    max_count = max(counter.values())
    return [
        {"word": word, "count": count, "weight": round((count / max_count) * 100)}
        for word, count in counter.most_common(limit)
    ]


def extract_bertopic_keywords(texts: list[str], limit: int = 30):
    if len(texts) < 8:
        return fallback_keywords(texts, limit)

    try:
        import jieba
        from bertopic import BERTopic
        from sklearn.feature_extraction.text import CountVectorizer

        embeddings = get_sbert_model().encode(texts, normalize_embeddings=True, show_progress_bar=False)
        vectorizer = CountVectorizer(tokenizer=jieba.lcut, stop_words=list(STOPWORDS), token_pattern=None)
        topic_model = BERTopic(vectorizer_model=vectorizer, calculate_probabilities=False, verbose=False)
        topics, _ = topic_model.fit_transform(texts, embeddings)

        topic_words: defaultdict[str, float] = defaultdict(float)
        for topic_id in set(topics):
            if topic_id == -1:
                continue
            for word, weight in topic_model.get_topic(topic_id) or []:
                word = str(word).strip()
                if len(word) > 1 and word not in STOPWORDS:
                    topic_words[word] += float(weight)

        if not topic_words:
            return fallback_keywords(texts, limit)

        max_weight = max(topic_words.values())
        return [
            {"word": word, "count": max(1, round(weight * 100)), "weight": round((weight / max_weight) * 100)}
            for word, weight in sorted(topic_words.items(), key=lambda item: item[1], reverse=True)[:limit]
        ]
    except Exception:
        return fallback_keywords(texts, limit)


def normalize_sentiment(label: str, confidence: float) -> tuple[SentimentLabel, int]:
    normalized = label.lower()
    if confidence < 0.6:
        return "neutral", round(confidence * 100)
    if "positive" in normalized or "pos" in normalized or normalized.endswith("_1"):
        return "positive", round(50 + confidence * 50)
    if "negative" in normalized or "neg" in normalized or normalized.endswith("_0"):
        return "negative", round(50 - confidence * 50)
    return "neutral", 50


def analyze_bert_sentiment(records: list[OpinionRecord]):
    classifier = get_sentiment_pipeline()
    predictions = classifier([record.content[:512] for record in records])
    enriched = []
    trend_map: dict[str, dict[str, int | str]] = {}

    for record, prediction in zip(records, predictions):
        label, score = normalize_sentiment(str(prediction["label"]), float(prediction["score"]))
        item = record.model_dump()
        item.update({"sentiment": label, "score": score})
        enriched.append(item)

        date = record.publishTime[:10]
        row = trend_map.setdefault(date, {"date": date, "positive": 0, "neutral": 0, "negative": 0})
        row[label] = int(row[label]) + 1

    total = max(len(enriched), 1)
    count = Counter(item["sentiment"] for item in enriched)
    examples = sorted(enriched, key=lambda item: abs(50 - int(item["score"])), reverse=True)[:4]

    return {
        "positive": count["positive"] / total,
        "neutral": count["neutral"] / total,
        "negative": count["negative"] / total,
        "records": enriched,
        "trend": sorted(trend_map.values(), key=lambda item: str(item["date"])),
        "examples": examples
    }


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/analyze")
def analyze(payload: AnalyzeRequest):
    records = [record for record in payload.records if record.content.strip()]
    texts = [record.content for record in records]
    keywords = extract_bertopic_keywords(texts)
    sentiment = analyze_bert_sentiment(records) if records else {
        "positive": 0,
        "neutral": 0,
        "negative": 0,
        "records": [],
        "trend": [],
        "examples": []
    }

    return {
        "keywords": keywords,
        "sentiment": sentiment,
        "modelInfo": [
            {
                "name": "SBERT",
                "role": "语义向量与相似文本聚类",
                "status": "active",
                "description": "使用 Sentence-BERT 生成中文文本向量，为相似评论聚类和 BERTopic 主题建模提供语义空间。"
            },
            {
                "name": "BERTopic",
                "role": "主题建模与主题词解释",
                "status": "active",
                "description": "基于 SBERT 向量聚类，并使用 c-TF-IDF 提取更稳定的主题关键词。"
            },
            {
                "name": "BERT 情感模型",
                "role": "中文情感倾向识别",
                "status": "active",
                "description": "使用中文 BERT/Roberta 情感分类器识别正面、中性、负面倾向。"
            }
        ]
    }
