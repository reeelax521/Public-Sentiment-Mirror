"use client";

import { Background } from "@/components/Background";
import { Button } from "@/components/ui/Button";
import { Panel } from "@/components/ui/Panel";
import { clearLegacyTaskCache } from "@/lib/clientTaskCache";
import {
  Activity,
  ArrowRight,
  BarChart3,
  Database,
  FileText,
  Gauge,
  LineChart,
  Network,
  Radar,
  UploadCloud
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";

const features = [
  {
    icon: UploadCloud,
    title: "多源数据接入",
    desc: "CSV、TXT、Excel、文本粘贴和示例数据都能进入同一套字段映射流程。"
  },
  {
    icon: Network,
    title: "语义分析流程",
    desc: "围绕评论文本提取关键词、情绪倾向、主题簇、热度变化和风险状态。"
  },
  {
    icon: Radar,
    title: "风险研判",
    desc: "把传播热度、负面风险、主题集中度拆开呈现，避免单一结论误导。"
  },
  {
    icon: FileText,
    title: "报告导出",
    desc: "生成 Markdown 和 Word 报告，图表跟随对应章节进入正文。"
  }
];

const flow = ["导入数据", "确认字段", "清洗样本", "识别主题", "观察趋势", "生成报告"];

export default function LandingPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function useDemo() {
    setLoading(true);
    const datasetRes = await fetch("/api/demo-dataset", { method: "POST" });
    const { dataset } = await datasetRes.json();
    const taskRes = await fetch("/api/analysis", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ datasetId: dataset.id })
    });
    const { task } = await taskRes.json();
    clearLegacyTaskCache();
    router.push(`/analysis/${task.id}`);
  }

  return (
    <main className="relative min-h-screen overflow-hidden">
      <Background />

      <section className="relative mx-auto flex min-h-screen max-w-7xl flex-col px-5 py-6 lg:px-8">
        <nav className="flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => router.push("/")}
            className="text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan/35"
          >
            <p className="text-xs font-medium uppercase tracking-[0.28em] text-cyan">Public Sentiment Mirror</p>
            <h1 className="mt-1 text-lg font-semibold text-foreground">网络舆情检索与智能分析平台</h1>
          </button>
          <div className="hidden items-center gap-2 md:flex">
            <Button variant="ghost" onClick={useDemo} loading={loading}>示例数据</Button>
            <Button onClick={() => router.push("/upload")}>开始分析</Button>
          </div>
        </nav>

        <div className="grid flex-1 items-center gap-10 py-10 lg:grid-cols-[minmax(0,0.96fr)_minmax(410px,0.74fr)] lg:py-14">
          <div>
            <div className="mb-6 inline-flex items-center gap-2 rounded-lg border border-cyan/20 bg-white/72 px-3 py-2 text-sm text-cyan">
              <Activity className="h-4 w-4" />
              Responsive analysis workspace
            </div>
            <h2 className="max-w-3xl text-5xl font-semibold leading-[1.04] tracking-[-0.02em] text-foreground md:text-6xl">
              把分散评论整理成可以判断的舆情线索
            </h2>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-muted">
              上传微博、新闻评论、弹幕、电影评论或社交媒体文本后，系统会先确认字段，再进入数据清洗、关键词、情感、主题聚类、趋势和报告生成。
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button onClick={() => router.push("/upload")}>
                开始分析
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button variant="secondary" loading={loading} onClick={useDemo}>使用示例数据</Button>
            </div>

            <div className="mt-10 grid max-w-2xl grid-cols-3 gap-3">
              {[
                ["9", "分析步骤"],
                ["3", "报告格式"],
                ["0", "登录门槛"]
              ].map(([value, label]) => (
                <div key={label} className="surface-panel-quiet px-4 py-3">
                  <p className="text-2xl font-semibold text-foreground">{value}</p>
                  <p className="mt-1 text-sm text-muted">{label}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="absolute -left-4 top-8 hidden h-[74%] w-px bg-cyan/20 lg:block" />
            <Panel className="dashboard-float-motion animate-breathe overflow-hidden p-0">
              <div className="border-b border-slate-200/70 bg-white/62 px-5 py-4">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-medium uppercase tracking-[0.2em] text-muted">Situation overview</p>
                    <h3 className="mt-1 text-xl font-semibold">态势总览</h3>
                  </div>
                  <LineChart className="h-6 w-6 text-cyan" />
                </div>
              </div>

              <div className="p-5">
                <div className="grid grid-cols-2 gap-3">
                  {[
                    ["总评论数", "2,840", Database],
                    ["热度指数", "82", Gauge],
                    ["负面率", "36%", BarChart3],
                    ["综合状态", "观察", Radar]
                  ].map(([label, value, Icon]) => (
                    <div key={label as string} className="rounded-lg border border-slate-200/80 bg-white/66 p-4">
                      <Icon className="mb-4 h-5 w-5 text-cyan" />
                      <p className="text-xs text-muted">{label as string}</p>
                      <p className="mt-1 text-2xl font-semibold">{value as string}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-5 rounded-lg border border-cyan/15 bg-[linear-gradient(135deg,rgba(19,182,209,.1),rgba(108,124,255,.07))] p-4">
                  <div className="mb-4 flex items-center justify-between text-sm">
                    <span className="font-medium text-foreground">热度趋势</span>
                    <span className="text-muted">7 日移动观察</span>
                  </div>
                  <div className="flex h-44 items-end gap-2">
                    {[32, 44, 38, 62, 78, 96, 70, 54, 42, 36].map((height, index) => (
                      <div
                        key={index}
                        className="flex-1 rounded-t bg-cyan/70 transition hover:bg-indigo"
                        style={{ height: `${height}%` }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </Panel>
          </div>
        </div>
      </section>

      <section className="page-band px-5 py-16 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.72fr_1.28fr]">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.24em] text-cyan">Workflow</p>
            <h2 className="mt-3 text-3xl font-semibold text-foreground">先确认数据，再进入分析</h2>
            <p className="mt-4 max-w-xl leading-7 text-muted">
              平台不预设固定场景。电影评论、新闻评论、B 站弹幕和平台舆情会根据实际字段切换展示模块。
            </p>
          </div>
          <div className="grid gap-3 md:grid-cols-3">
            {flow.map((item, index) => (
              <div key={item} className="surface-panel-quiet p-4">
                <p className="text-sm font-semibold text-cyan">0{index + 1}</p>
                <p className="mt-3 text-base font-semibold text-foreground">{item}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-16 lg:px-8">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => (
            <Panel key={feature.title} className="h-full">
              <feature.icon className="mb-5 h-7 w-7 text-cyan" />
              <h3 className="text-lg font-semibold">{feature.title}</h3>
              <p className="mt-3 text-sm leading-6 text-muted">{feature.desc}</p>
            </Panel>
          ))}
        </div>
      </section>
    </main>
  );
}
