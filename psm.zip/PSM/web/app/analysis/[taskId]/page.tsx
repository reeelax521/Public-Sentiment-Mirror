"use client";

import { Background } from "@/components/Background";
import { EventTrendTimeline, KeywordBar, PlatformPie, RiskRadar, SentimentDonut, TrendLine } from "@/components/Charts";
import { WordCloud } from "@/components/WordCloud";
import { WorkflowShell } from "@/components/WorkflowShell";
import { Button } from "@/components/ui/Button";
import { MetricCard, Panel } from "@/components/ui/Panel";
import { clearLegacyTaskCache } from "@/lib/clientTaskCache";
import { downloadTextFile, downloadWordReport } from "@/lib/reportDownload";
import type { AnalysisTask, CleanIssueSample, ClusterItem, DatasetSourceFile, FieldMapping, LexiconAnalysis, LexiconItem, Report, RiskLevel, TopicItem } from "@/lib/types";
import { cn, formatPercent } from "@/lib/utils";
import { motion } from "framer-motion";
import { AlertTriangle, Copy, Download, FileText, Layers3, Sparkles } from "lucide-react";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

const riskLabel: Record<RiskLevel, string> = {
  low: "低风险",
  medium: "中风险",
  high: "较高风险",
  critical: "高风险"
};

const sentimentLabel: Record<string, string> = {
  positive: "正面",
  neutral: "中性",
  negative: "负面"
};

const emptyLexicon: LexiconAnalysis = { targets: [], emotions: [], stances: [] };
const negativeHints = ["失望", "质疑", "不满", "担心", "抵制", "差评", "道歉", "退票", "退款", "欺骗", "崩", "烂", "愤怒", "疲劳", "无聊", "没回答", "敷衍", "博弈", "波动", "别光说不练", "风险", "不能看说什么", "被偷", "抢走", "抢掉", "抢名额", "预约名额", "黄牛", "倒卖", "加价", "恶心", "丢人", "造假", "抄袭", "争议", "阴阳怪气", "无语", "吵", "太大了", "刺耳", "不合理", "杂乱", "严重", "没有美感", "人机", "不需要", "不值", "不划算", "劝退", "下不去手", "买不起", "溢价", "价格劝退"];

export default function AnalysisPage() {
  const params = useParams<{ taskId: string }>();
  const router = useRouter();
  const [task, setTask] = useState<AnalysisTask | null>(null);
  const [current, setCurrent] = useState(0);
  const [report, setReport] = useState<Report | null>(null);

  useEffect(() => {
    clearLegacyTaskCache();
    fetch(`/api/analysis/${params.taskId}`).then(async (res) => {
      if (!res.ok) return;
      const data = await res.json();
      setTask(data.task);
    });
  }, [params.taskId]);

  const sentimentChart = useMemo(() => task ? [
    { name: "正面", value: Math.round(task.sentiment.positive * 100) },
    { name: "中性", value: Math.round(task.sentiment.neutral * 100) },
    { name: "负面", value: Math.round(task.sentiment.negative * 100) }
  ] : [], [task]);

  async function generate() {
    if (!task) return;
    const res = await fetch("/api/reports/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ taskId: task.id })
    });
    if (res.ok) {
      const data = await res.json();
      setReport(data.report);
    } else {
      const { generateReport } = await import("@/lib/analysis/report");
      setReport(generateReport(task));
    }
  }

  if (!task) {
    return (
      <main className="flex min-h-screen items-center justify-center px-5">
        <Background />
        <Panel className="max-w-lg text-center">
          <Sparkles className="mx-auto mb-4 h-8 w-8 text-cyan" />
          <h1 className="text-2xl font-semibold">正在载入分析任务</h1>
          <p className="mt-3 text-muted">如果任务已经失效，请重新上传数据或使用示例数据创建任务。</p>
          <Button className="mt-5" onClick={() => router.push("/upload")}>返回上传中心</Button>
        </Panel>
      </main>
    );
  }

  const lexicon = task.lexicon || emptyLexicon;
  const steps = [
    <Overview key="overview" task={task} />,
    <Cleaning key="cleaning" task={task} lexicon={lexicon} />,
    <Keywords key="keywords" task={task} lexicon={lexicon} />,
    <Sentiment key="sentiment" task={task} sentimentChart={sentimentChart} />,
    <TopicClustering key="topics" task={task} />,
    <Trend key="trend" task={task} />,
    <Timeline key="timeline" task={task} />,
    <Dashboard key="dashboard" task={task} sentimentChart={sentimentChart} />,
    <ReportStep key="report" task={task} report={report} generate={generate} sentimentChart={sentimentChart} />
  ];

  return (
    <main className="min-h-screen">
      <Background />
      <WorkflowShell current={current} setCurrent={setCurrent}>
        <motion.div key={current} initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
          {steps[current]}
        </motion.div>
      </WorkflowShell>
    </main>
  );
}

function isTechnicalObjectName(value?: string) {
  if (!value) return true;
  const trimmed = value.trim();
  if (!trimmed) return true;
  if (/^[a-z0-9_-]{2,24}$/i.test(trimmed) && !/[\u4e00-\u9fa5]/.test(trimmed)) return true;
  if (/^BV[a-zA-Z0-9]+$/.test(trimmed)) return true;
  return false;
}

function discussionObjects(task: AnalysisTask) {
  const rows: Array<{ name: string; sub?: string; count: number }> = [];
  const eventName = task.event?.name?.trim();
  if (eventName && !/^(综合评论事件|评论事件|未知事件|未识别)/.test(eventName) && !isTechnicalObjectName(eventName)) {
    rows.push({
      name: eventName,
      sub: task.event?.subjects?.length ? `核心主体：${task.event.subjects.slice(0, 4).join("、")}` : task.event?.coreIssues?.length ? `核心议题：${task.event.coreIssues.slice(0, 4).join("、")}` : undefined,
      count: task.clean.validCount
    });
  }

  if (rows.length && task.dashboard.sourceMode !== "object_review") return rows;

  for (const item of task.dashboard.objectDistribution) {
    if (isTechnicalObjectName(item.objectName)) continue;
    if (rows.some((row) => row.name === item.objectName || row.name.includes(item.objectName) || item.objectName.includes(row.name))) continue;
    rows.push({ name: item.objectName, sub: item.objectAlias, count: item.count });
  }

  return rows.slice(0, 6);
}

function Overview({ task }: { task: AnalysisTask }) {
  const lastTrend = task.trend[task.trend.length - 1];
  const isObjectReview = task.dashboard.sourceMode === "object_review";
  const platforms = task.dashboard.platformDistribution.map((item) => item.platform);
  const hasPlatform = task.dashboard.platformDistribution.length > 0;
  const objects = discussionObjects(task);
  const hasObject = objects.length > 0;
  const timeRange = task.trend.length ? `${task.trend[0]?.date || "-"} 至 ${lastTrend?.date || "-"}` : "未提供有效时间";

  if (isObjectReview) {
    return (
      <div className="space-y-6">
        {task.analysisMode === "basic" && <BasicModeNotice />}
        <SourceFilesSummary files={task.dataset.sourceFiles || []} />
        <EventOverviewCard task={task} />
        <div className="grid gap-4 md:grid-cols-4">
          <MetricCard label="分析对象" value={task.dashboard.objectName || "未知作品"} sub={task.dashboard.objectAlias ? `英文名称：${task.dashboard.objectAlias}` : undefined} />
          <MetricCard label="评论数量" value={task.clean.validCount} />
          <MetricCard label="时间范围" value={timeRange} />
          <MetricCard label="平均评分" value={task.dashboard.ratingAverage ?? "无评分"} />
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          <MetricCard label="总点赞数" value={task.dashboard.totalLikes} />
          <MetricCard label="最高点赞评论" value={task.dashboard.topLikedComment?.likeCount ?? 0} sub={task.dashboard.topLikedComment?.content.slice(0, 34)} />
          <MetricCard label="数据采集时间" value={task.dashboard.collectedAt || "未识别"} />
        </div>
        <div className="grid gap-5 xl:grid-cols-[0.9fr_1.1fr]">
          <Panel>
            <h2 className="mb-4 text-xl font-semibold">分析对象信息</h2>
            <InfoRows rows={[
              ["作品名称", task.dashboard.objectName || "未知"],
              ["英文名称", task.dashboard.objectAlias || "无"],
              ["评论字段", task.dataset.fieldMapping.textField || "未识别"],
              ["评分字段", task.dataset.fieldMapping.ratingField || "无"],
              ["平台字段", task.dataset.fieldMapping.platformField || task.dataset.fieldMapping.staticPlatform || "空"]
            ]} />
          </Panel>
          {Boolean(task.dashboard.ratingDistribution?.length) && (
            <Panel className="report-chart" data-chart-title="评分分布">
              <h2 className="mb-4 text-xl font-semibold">评分分布</h2>
              <KeywordBar data={(task.dashboard.ratingDistribution || []).map((item) => ({ word: item.rating, count: item.count }))} />
            </Panel>
          )}
          <Panel className="report-chart" data-chart-title="点赞趋势">
            <h2 className="mb-4 text-xl font-semibold">点赞与热度趋势</h2>
            <TrendLine data={task.trend} />
          </Panel>
          <Panel>
            <h2 className="mb-4 text-xl font-semibold">数据字段识别结果</h2>
            <FieldMappingRows mapping={task.dataset.fieldMapping} />
          </Panel>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {task.analysisMode === "basic" && <BasicModeNotice />}
      <SourceFilesSummary files={task.dataset.sourceFiles || []} />
      <EventOverviewCard task={task} />
      <div className="grid gap-4 md:grid-cols-4">
        <MetricCard label="总文本数" value={task.clean.originalCount} />
        <MetricCard label="有效文本数" value={task.clean.validCount} />
        <MetricCard label={hasPlatform ? "平台来源" : "数据来源"} value={hasPlatform ? `${platforms.length} 个平台` : "通用文本"} sub={platforms.join("、") || task.dataset.name} />
        <MetricCard label="时间范围" value={timeRange} />
      </div>
      {hasObject && (
        <Panel>
          <h2 className="mb-4 text-xl font-semibold">事件讨论对象</h2>
          <div className="grid gap-3 md:grid-cols-3">
            {objects.map((item) => (
              <div key={item.name} className="rounded-lg border border-slate-200/80 bg-white/60 p-4">
                <p className="font-semibold">{item.name}</p>
                {item.sub && <p className="mt-1 text-sm text-muted">{item.sub}</p>}
                <p className="mt-3 text-sm text-cyan">{item.count} 条文本</p>
              </div>
            ))}
          </div>
        </Panel>
      )}
      <div className="grid gap-5 lg:grid-cols-[0.95fr_1.05fr]">
        {hasPlatform && (
          <Panel className="report-chart" data-chart-title="平台来源分布">
            <h2 className="mb-4 text-xl font-semibold">平台来源构成</h2>
            <PlatformPie data={task.dashboard.platformDistribution} />
          </Panel>
        )}
        <DataPreview records={task.clean.records.slice(0, 7).map((record) => [record.platform || record.username || record.objectName || "评论", record.content])} />
      </div>
    </div>
  );
}

function Cleaning({ task, lexicon }: { task: AnalysisTask; lexicon: LexiconAnalysis }) {
  const [openIssue, setOpenIssue] = useState<string | null>(null);
  const issueSamples = task.clean.issueSamples || { tooShort: [], lowQuality: [], semanticAnomaly: [] };
  const issueCards = [
    {
      key: "tooShort",
      label: "过短文本",
      count: task.clean.tooShortCount,
      samples: issueSamples.tooShort,
      description: "文本过短，仍保留在有效样本中，但不适合过度解释。"
    },
    {
      key: "lowQuality",
      label: "低质量文本",
      count: task.clean.lowQualityCount,
      samples: issueSamples.lowQuality,
      description: "可能包含较多符号、表情或噪声，语义信息较弱。"
    },
    {
      key: "semanticAnomaly",
      label: "语义异常文本",
      count: task.clean.semanticAnomalyCount,
      samples: issueSamples.semanticAnomaly,
      description: "可能是重复字符、纯数字符号或难以解释的文本。"
    }
  ].filter((item) => item.count > 0);
  const lexiconPanels = [
    {
      title: task.dashboard.sourceMode === "object_review" ? "内容对象" : "目标对象",
      items: task.dashboard.sourceMode === "object_review" ? lexicon.contentObjects || [] : lexicon.targets
    },
    {
      title: task.dashboard.sourceMode === "object_review" ? "观影体验" : "情绪倾向词汇",
      items: task.dashboard.sourceMode === "object_review" ? lexicon.viewingExperience || [] : lexicon.emotions
    },
    {
      title: task.dashboard.sourceMode === "object_review" ? "争议焦点" : "立场表达",
      items: task.dashboard.sourceMode === "object_review" ? lexicon.controversyFocus || [] : lexicon.stances
    }
  ].filter((item) => item.items.length > 0);
  const path = [
    ["原始数据", task.clean.originalCount],
    ...(task.clean.emptyCount > 0 ? [["去空值", task.clean.originalCount - task.clean.emptyCount]] : []),
    ...(task.clean.duplicateCount > 0 ? [["去重复", task.clean.originalCount - task.clean.emptyCount - task.clean.duplicateCount]] : []),
    ["有效样本", task.clean.validCount]
  ];
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard label="原始数据量" value={task.clean.originalCount} />
        {task.clean.duplicateCount > 0 && <MetricCard label="去重数量" value={task.clean.duplicateCount} />}
        {task.clean.emptyCount > 0 && <MetricCard label="空值数量" value={task.clean.emptyCount} />}
        <MetricCard label="有效样本" value={task.clean.validCount} />
      </div>
      <Panel>
        <h2 className="mb-6 text-xl font-semibold">清洗路径</h2>
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {path.map(([label, value], index) => (
            <div key={label as string} className="rounded-lg border border-cyan/18 bg-cyan/[0.06] p-4">
              <p className="text-sm text-muted">Step {index + 1}</p>
              <p className="mt-2 text-lg font-semibold">{label as string}</p>
              <p className="mt-3 text-3xl text-cyan">{value as number}</p>
            </div>
          ))}
        </div>
      </Panel>
      {issueCards.length > 0 && (
        <Panel>
          <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="text-xl font-semibold">需谨慎解释的文本</h2>
              <p className="mt-2 text-sm text-muted">这些记录没有从有效样本中剔除，点击卡片可查看具体文本。</p>
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {issueCards.map((item) => (
              <CleanIssueCard
                key={item.key}
                active={openIssue === item.key}
                count={item.count}
                description={item.description}
                label={item.label}
                onClick={() => setOpenIssue(openIssue === item.key ? null : item.key)}
              />
            ))}
          </div>
          {issueCards.map((item) => (
            openIssue === item.key ? <IssueSampleList key={item.key} title={item.label} samples={item.samples} /> : null
          ))}
        </Panel>
      )}
      {lexiconPanels.length > 0 && (
        <div className="grid gap-5 lg:grid-cols-3">
          {lexiconPanels.map((item) => (
            <TermPanel key={item.title} title={item.title} items={item.items} />
          ))}
        </div>
      )}
    </div>
  );
}

function CleanIssueCard({
  active,
  count,
  description,
  label,
  onClick
}: {
  active: boolean;
  count: number;
  description: string;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-expanded={active}
      onClick={onClick}
      className={cn(
        "min-h-[148px] rounded-xl border p-4 text-left transition hover:-translate-y-0.5 hover:border-cyan/50 focus:outline-none focus:ring-2 focus:ring-cyan/40",
        active ? "border-cyan/60 bg-cyan/10" : "border-slate-200/80 bg-white/60"
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">{label}</p>
          <p className="mt-3 text-3xl font-semibold leading-none text-foreground">{count}</p>
        </div>
        <span className={cn("rounded-full px-2 py-1 text-xs", active ? "bg-cyan text-white" : "bg-slate-100 text-muted")}>
          {active ? "收起" : "查看"}
        </span>
      </div>
      <p className="mt-3 text-sm leading-6 text-muted">{description}</p>
    </button>
  );
}

function IssueSampleList({ title, samples }: { title: string; samples: CleanIssueSample[] }) {
  return (
    <div className="mt-4 overflow-hidden rounded-xl border border-slate-200/80 bg-white/70">
      <div className="flex items-center justify-between gap-3 border-b border-slate-200/80 px-4 py-3">
        <h3 className="font-semibold">{title}样本</h3>
        <span className="text-sm text-muted">展示前 {Math.min(samples.length, 20)} 条</span>
      </div>
      {samples.length ? (
        <div className="max-h-[360px] overflow-auto">
          {samples.slice(0, 20).map((sample, index) => (
            <div key={`${sample.id}-${index}`} className="border-b border-slate-200/70 px-4 py-3 last:border-b-0">
              <div className="mb-2 flex flex-wrap items-center gap-2 text-xs text-muted">
                <span>#{index + 1}</span>
                {sample.platform && <span>{sample.platform}</span>}
                {sample.publishTime && <span>{sample.publishTime}</span>}
                {sample.username && <span>{sample.username}</span>}
                {typeof sample.likeCount === "number" && sample.likeCount > 0 && <span>点赞 {sample.likeCount}</span>}
              </div>
              <p className="text-sm leading-6 text-foreground">{sample.content}</p>
              <p className="mt-2 text-xs text-muted">{sample.reason}</p>
            </div>
          ))}
        </div>
      ) : (
        <p className="px-4 py-5 text-sm text-muted">当前任务来自旧缓存，重新上传或重新开始分析后可查看具体样本。</p>
      )}
    </div>
  );
}

function Keywords({ task, lexicon }: { task: AnalysisTask; lexicon: LexiconAnalysis }) {
  const isObjectReview = task.dashboard.sourceMode === "object_review";
  const isDiplomatic = task.event.category.includes("外交");
  const eventGroups = [
    ["事件主体词", task.event.keywordGroups.eventSubjects],
    [isDiplomatic ? "关系与议题词" : "文化价值词", task.event.keywordGroups.culturalValues],
    [isDiplomatic ? "互动反馈词" : "消费评价词", task.event.keywordGroups.consumerEvaluations],
    [isDiplomatic ? "核心议题词" : "风险争议词", task.event.keywordGroups.riskDisputes],
    ["增长热点词", task.event.keywordGroups.growthHotspots]
  ].filter(([, items]) => items.length > 0) as Array<[string, LexiconItem[]]>;
  const groups = isObjectReview
    ? [
      ["内容对象", lexicon.contentObjects || []],
      ["角色人物", lexicon.characters || []],
      ["观影体验", lexicon.viewingExperience || []],
      ["情绪评价", lexicon.emotionEvaluations || []],
      ["争议焦点", lexicon.controversyFocus || []]
    ] as const
    : [
      ["对象焦点", lexicon.targets],
      ["情绪焦点", lexicon.emotions],
      ["舆论立场", lexicon.stances]
    ] as const;
  return (
    <div className="space-y-5">
      <Panel>
        <h2 className="mb-4 text-xl font-semibold">高频词云</h2>
        <WordCloud words={task.keywords} />
      </Panel>
      <Panel className="report-chart" data-chart-title="关键词排行">
        <h2 className="mb-4 text-xl font-semibold">Top 20 关键词</h2>
        <KeywordBar data={task.keywords} height={420} />
      </Panel>
      <Panel>
        <h2 className="mb-2 text-xl font-semibold">事件线索词分层</h2>
        <p className="mb-4 text-sm leading-6 text-muted">这些分类用于判断谁被讨论、价值如何被理解、风险集中在哪里，以及哪些词正在成为新热点。</p>
        {eventGroups.length ? (
          <div className="grid gap-4 lg:grid-cols-5">
            {eventGroups.map(([title, items]) => <TermPanel key={title} title={title} items={items} compact />)}
          </div>
        ) : (
          <p className="rounded-lg border border-slate-200/80 bg-white/60 p-4 text-sm leading-6 text-muted">
            当前样本未识别到稳定的事件线索词，系统不会强行生成分类。
          </p>
        )}
      </Panel>
      <Panel>
        <h2 className="mb-4 text-xl font-semibold">{isObjectReview ? "评论表达补充" : "舆论表达补充"}</h2>
        <div className={cn("grid gap-4", isObjectReview ? "lg:grid-cols-5" : "lg:grid-cols-3")}>
          {groups.map(([title, items]) => <TermPanel key={title} title={title} items={items} compact />)}
        </div>
      </Panel>
    </div>
  );
}

function Sentiment({ task, sentimentChart }: { task: AnalysisTask; sentimentChart: Array<{ name: string; value: number }> }) {
  return (
    <div className="space-y-6">
      <Panel className="border-cyan/25 bg-cyan/5 p-4">
        <p className="text-sm text-cyan">情感分析依据：{task.sentiment.basis}</p>
      </Panel>
      <div className="grid gap-4 md:grid-cols-3">
        <MetricCard label="正面比例" value={formatPercent(task.sentiment.positive)} />
        <MetricCard label="中性比例" value={formatPercent(task.sentiment.neutral)} />
        <MetricCard label="负面比例" value={formatPercent(task.sentiment.negative)} />
      </div>
      <SentimentDriversPanel task={task} />
      <div className="grid gap-5 lg:grid-cols-2">
        <Panel className="report-chart" data-chart-title="情感分布">
          <h2 className="mb-4 text-xl font-semibold">情感分布</h2>
          <SentimentDonut data={sentimentChart} />
        </Panel>
        <Panel>
          <h2 className="mb-4 text-xl font-semibold">情绪与热度关系</h2>
          <TrendLine data={task.trend} />
        </Panel>
      </div>
      <Panel>
        <h2 className="mb-4 text-xl font-semibold">典型评论</h2>
        <p className="mb-4 text-sm leading-6 text-muted">
          置信度表示系统对当前情感标签的把握程度。后台模型返回时取模型概率换算为 0-100；本地校准模式下根据正负向语义证据差值换算，明确负向证据会覆盖模型的中性或正向误判。
        </p>
        <div className="grid gap-3 md:grid-cols-2">
          {task.sentiment.examples.map((record) => (
            <div key={record.id} className="rounded-lg border border-slate-200/80 bg-white/60 p-4">
              <p className="text-sm leading-6 text-muted">{record.content}</p>
              <p className="mt-3 text-xs uppercase tracking-[0.16em] text-cyan">
                {sentimentLabel[record.sentiment] || record.sentiment} · 置信度 {record.score} · 点赞 {record.likeCount}
              </p>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

function SentimentDriversPanel({ task }: { task: AnalysisTask }) {
  return (
    <Panel>
      <h2 className="mb-4 text-xl font-semibold">情绪驱动因素</h2>
      <div className="grid gap-3 lg:grid-cols-3">
        {task.event.sentimentDrivers.map((item) => (
          <div key={item.label} className="rounded-lg border border-slate-200/80 bg-white/60 p-4">
            <div className="flex items-center justify-between gap-3">
              <h3 className="font-semibold">{item.label}</h3>
              <span className="rounded-lg bg-cyan/10 px-2 py-1 text-xs text-cyan">原因拆解</span>
            </div>
            <p className="mt-3 text-sm leading-6 text-muted">{item.reasons.join("、")}</p>
            {item.representativeExpressions[0] && (
              <p className="mt-3 rounded-lg bg-white/70 p-3 text-sm leading-6 text-muted">“{item.representativeExpressions[0]}”</p>
            )}
          </div>
        ))}
      </div>
    </Panel>
  );
}

function TopicClustering({ task }: { task: AnalysisTask }) {
  const topics = task.nlp?.topics || [];
  const clusters = task.nlp?.clusters || [];
  const riskyTopic = findRiskyTopic(topics);
  const topicChart = buildTopicChartData(topics, task.keywords);
  const semanticPoints = buildSemanticPoints(clusters);

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        <MetricCard label="主题类别数量" value={`${topics.length || 1} 类`} />
        <MetricCard label="最大主题类别" value={topics[0] ? displayTopicName(topics[0]) : "基础主题"} sub={topics[0] ? `${topics[0].percentage.toFixed(1)}%` : "样本语义摘要"} />
        <MetricCard label="高负面风险主题" value={riskyTopic ? displayTopicName(riskyTopic) : "未见集中负面风险"} />
        <MetricCard label="评论立场分布" value={dominantQuadrant(semanticPoints)} />
      </div>
      <Panel className="border-cyan/25 bg-cyan/5 p-4">
        <p className="text-sm leading-6 text-muted">
          主题风险按“负面语义强度 + 主题占比/热度 + 是否出现争议词”综合判断。热度高本身不等于高风险，正向高热主题会标记为高关注议题，只有负面表达与较高讨论规模同时出现时，才会进入高风险或优先关注范围。
        </p>
      </Panel>

      <div className="grid gap-5 xl:grid-cols-[1.05fr_0.95fr]">
        <Panel className="report-chart" data-chart-title="主题分布">
          <h2 className="mb-4 text-xl font-semibold">主题分布</h2>
          <KeywordBar data={topicChart} />
        </Panel>
        <Panel>
          <h2 className="mb-2 text-xl font-semibold">情绪立场象限图</h2>
          <p className="mb-4 text-sm leading-6 text-muted">横轴表示评论倾向，左侧偏负面，中部偏中性，右侧偏正面；纵轴表示表达强度和互动热度。每个点代表一条代表性评论，鼠标悬停可查看原文。</p>
          <ClusterScatter points={semanticPoints} />
        </Panel>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Panel>
          <h2 className="mb-4 flex items-center gap-2 text-xl font-semibold">
            <Layers3 className="h-5 w-5 text-cyan" />
            主题卡片
          </h2>
          <div className="space-y-3">
            {(topics.length ? topics : fallbackTopics(task)).slice(0, 8).map((topic) => (
              <TopicCard key={topic.topicId} topic={topic} risky={topic.topicId === riskyTopic?.topicId} />
            ))}
          </div>
        </Panel>
        <Panel>
          <h2 className="mb-4 flex items-center gap-2 text-xl font-semibold">
            <Sparkles className="h-5 w-5 text-cyan" />
            象限洞察
          </h2>
          <QuadrantInsights points={semanticPoints} />
        </Panel>
      </div>
    </div>
  );
}

function Trend({ task }: { task: AnalysisTask }) {
  if (!task.trend.length) {
    return (
      <div className="space-y-6">
        <Panel className="border-amber-300/70 bg-amber-50/80 p-5">
          <h2 className="text-xl font-semibold text-amber-900">热度趋势已降级</h2>
          <p className="mt-2 text-sm leading-6 text-amber-800">
            当前数据没有可用发布时间。系统不会用任务创建时间或随机时间填充，因此不生成日期趋势、峰值时间和增长率结论；其他关键词、情感、主题与风险模块仍可继续分析。
          </p>
        </Panel>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        <MetricCard label="峰值评论量" value={task.dashboard.peakCommentCount} />
        <MetricCard label="峰值点赞量" value={task.dashboard.peakLikeCount} />
        <MetricCard label="热度指数" value={task.dashboard.heatIndex} />
        <MetricCard label="相对升温幅度" value={`${task.dashboard.relativeGrowthRate}%`} />
      </div>
      <Panel className="border-amber-300/70 bg-amber-50/80 p-4">
        <div className="grid gap-3 text-sm leading-6 text-amber-800 md:grid-cols-2">
          <p><span className="font-semibold">热度指数公式：</span>日热度原值 = 评论量 × 1.8 + ln(1 + 点赞量) × 5 + ln(1 + 总互动量) × 3；再使用 3 日或 7 日移动平均，最后按样本内最大值归一化到 0-100。它表示本次样本内部的相对热度，不等同于全网绝对热度。</p>
          <p><span className="font-semibold">相对升温幅度公式：</span>(峰值热度指数 - 峰值前热度中位数) / max(峰值前热度中位数, 30) × 100%，并将展示值限制在 0-200%。这样可以避免起始阶段样本很少时出现上千百分比。</p>
        </div>
      </Panel>
      <PredictionPanel task={task} />
      <Panel className="report-chart" data-chart-title="热度趋势">
        <h2 className="mb-2 text-xl font-semibold">热度趋势</h2>
        <p className="mb-4 text-sm text-muted">按日期聚合后使用移动平均处理，减少曲线在 0 与 100 之间频繁跳动。</p>
        <TrendLine data={task.trend} />
      </Panel>
    </div>
  );
}

function PredictionPanel({ task }: { task: AnalysisTask }) {
  const prediction = task.event.prediction;
  return (
    <Panel>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-semibold">短期趋势辅助判断</h2>
          <p className="mt-2 text-sm leading-6 text-muted">基于样本内近3日热度和负面占比变化，不等同于对全网未来舆情的精准预测。</p>
        </div>
      </div>
      <div className="grid gap-3 md:grid-cols-4">
        {[
          ["近3日热度斜率", prediction.heatSlope],
          ["近3日负面变化", prediction.negativeChange],
          ["样本内增长词", prediction.growthKeywords.slice(0, 3).join("、") || "未识别到可靠增长词"],
          ["预测结果", prediction.result.replace(/[。.]$/, "")]
        ].map(([label, value]) => (
          <div key={label} className="rounded-lg border border-slate-200/80 bg-white/60 p-4">
            <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">{label}</p>
            <p className="mt-3 text-lg font-semibold leading-6 text-foreground">{value}</p>
          </div>
        ))}
      </div>
      <p className="mt-4 text-sm leading-6 text-muted">{prediction.basis}{prediction.advice}</p>
    </Panel>
  );
}

function Timeline({ task }: { task: AnalysisTask }) {
  if (!task.trend.length || !task.timeline.length) {
    return (
      <div className="space-y-6">
        <Panel className="border-amber-300/70 bg-amber-50/80 p-5">
          <h2 className="text-xl font-semibold text-amber-900">时间轴已降级</h2>
          <p className="mt-2 text-sm leading-6 text-amber-800">
            当前数据缺少可用发布时间，无法可靠判断事件阶段。请补充发布时间字段后再查看热度趋势和时间轴。
          </p>
        </Panel>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Panel className="report-chart" data-chart-title="热度趋势与事件转折">
        <h2 className="mb-2 text-xl font-semibold">{task.dashboard.sourceMode === "object_review" ? "评论时间轴" : "事件时间轴"}</h2>
        <p className="mb-4 text-sm text-muted">折线使用 0-100 指数展示热度与评论量变化，阶段卡片保留真实评论量和点赞量。</p>
        <EventTrendTimeline trend={task.trend} timeline={task.timeline} />
      </Panel>
      <Panel>
        <h2 className="mb-4 text-xl font-semibold">事件节点与数据表现</h2>
        <div className="overflow-hidden rounded-lg border border-slate-200/80 bg-white/50">
          {task.event.timeline.map((item, index) => (
            <div key={`${item.time}-${index}`} className="grid gap-3 border-b border-slate-200/70 p-4 text-sm last:border-b-0 md:grid-cols-[120px_1fr_1fr_1fr]">
              <span className="font-medium text-cyan">{item.time}</span>
              <span className="text-foreground">{item.eventNode}</span>
              <span className="text-muted">{item.dataSignal}</span>
              <span className="text-muted">{item.systemJudgment}</span>
            </div>
          ))}
        </div>
      </Panel>
      <div className="grid gap-4 lg:grid-cols-3">
        {task.timeline.map((node) => (
          <Panel key={`${node.stage}-${node.time}`} className="p-4">
            <p className="text-sm font-medium text-cyan">{node.time}</p>
            <h3 className="mt-2 font-semibold">{node.stage}</h3>
            <p className="mt-2 text-sm leading-6 text-muted">{node.summary}</p>
            <p className="mt-3 text-xs text-muted">评论量 {node.volume} · 热度指数 {node.heat} · {riskLabel[node.risk]} · {node.emotionChange}</p>
          </Panel>
        ))}
      </div>
    </div>
  );
}

function Dashboard({ task, sentimentChart }: { task: AnalysisTask; sentimentChart: Array<{ name: string; value: number }> }) {
  const topics = task.nlp?.topics || [];
  const topicChart = buildTopicChartData(topics, task.keywords);
  const isObjectReview = task.dashboard.sourceMode === "object_review";
  const lastTrend = task.trend[task.trend.length - 1];
  const timeRange = task.trend.length ? `${task.trend[0]?.date || "-"} 至 ${lastTrend?.date || "-"}` : "未提供有效时间";
  const platforms = task.dashboard.platformDistribution.map((item) => item.platform);
  const sourceValue = platforms.length ? `${platforms.length} 个平台` : isObjectReview ? task.dashboard.objectName || "单对象评论" : "通用文本";
  const sourceSub = platforms.length ? platforms.join("、") : task.dataset.name;

  return (
    <div className="space-y-6">
      <EventOverviewCard task={task} />
      <div className="grid gap-4 md:grid-cols-4">
        <MetricCard label="总文本数" value={task.clean.originalCount} />
        <MetricCard label="有效文本数" value={task.clean.validCount} />
        <MetricCard label={platforms.length ? "平台来源" : "数据来源"} value={sourceValue} sub={sourceSub} />
        <MetricCard label="样本时间范围" value={timeRange} />
      </div>
      <div className="grid gap-5 xl:grid-cols-[1.05fr_0.95fr]">
        <Panel className="report-chart" data-chart-title="高频词云">
          <h2 className="mb-4 text-xl font-semibold">高频词云</h2>
          <WordCloud words={task.keywords} />
        </Panel>
        <Panel className="report-chart" data-chart-title="情感分布">
          <h2 className="mb-4 text-xl font-semibold">情感分布</h2>
          <SentimentDonut data={sentimentChart} />
        </Panel>
      </div>
      <div className="grid gap-5 xl:grid-cols-[1.18fr_0.82fr]">
        {task.trend.length ? (
          <Panel className="report-chart" data-chart-title="趋势图">
            <h2 className="mb-2 text-xl font-semibold">热度趋势</h2>
            <p className="mb-4 text-sm leading-6 text-muted">热度曲线展示样本内部的相对变化，需结合真实评论量和点赞量理解。</p>
            <TrendLine data={task.trend} />
          </Panel>
        ) : (
          <Panel><h2 className="mb-4 text-xl font-semibold">热度趋势</h2><p className="text-sm leading-6 text-muted">缺少可用发布时间，趋势图已降级。</p></Panel>
        )}
        <Panel className="report-chart" data-chart-title="主题分布">
          <h2 className="mb-4 text-xl font-semibold">主题分布</h2>
          <KeywordBar data={topicChart} />
        </Panel>
      </div>
      <div className="grid gap-5 xl:grid-cols-2">
        {isObjectReview && Boolean(task.dashboard.ratingDistribution?.length) ? (
          <Panel className="report-chart" data-chart-title="评分分布"><h2 className="mb-4 text-xl font-semibold">评分分布</h2><KeywordBar data={(task.dashboard.ratingDistribution || []).map((item) => ({ word: item.rating, count: item.count }))} /></Panel>
        ) : task.dashboard.platformDistribution.length ? (
          <Panel className="report-chart" data-chart-title="平台来源"><h2 className="mb-4 text-xl font-semibold">平台来源</h2><PlatformPie data={task.dashboard.platformDistribution} /></Panel>
        ) : null}
        <Panel className="report-chart" data-chart-title="风险结构">
          <h2 className="mb-2 text-xl font-semibold">风险结构</h2>
          <p className="mb-4 text-sm leading-6 text-muted">风险结构拆分为负面压力、负面高热、传播热度、互动集中和来源集中。热度高本身不等于高风险，只有负面表达与较高传播强度叠加时才会形成“负面高热”。</p>
          <RiskRadar data={task.dashboard.riskRadar} />
        </Panel>
        <Panel className="report-chart xl:col-span-2" data-chart-title="关键词排行">
          <h2 className="mb-4 text-xl font-semibold">关键词排行</h2>
          <KeywordBar data={task.keywords} />
        </Panel>
      </div>
    </div>
  );
}

function ReportStep({
  task,
  report,
  generate,
  sentimentChart
}: {
  task: AnalysisTask;
  report: Report | null;
  generate: () => Promise<void>;
  sentimentChart: Array<{ name: string; value: number }>;
}) {
  const isObjectReview = task.dashboard.sourceMode === "object_review";
  const topicChart = buildTopicChartData(task.nlp.topics, task.keywords);
  const reportBaseName = buildReportFileBase(task);
  return (
    <div className="space-y-6">
      <Panel>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-semibold">分析报告</h2>
            <p className="mt-2 text-muted">报告会根据当前数据、图表和综合判断自动生成，可下载为 Markdown 或 Word。</p>
          </div>
          <Button onClick={generate}><FileText className="h-4 w-4" />生成报告</Button>
        </div>
      </Panel>

      <div className="grid gap-5 xl:grid-cols-2">
        {isObjectReview && Boolean(task.dashboard.ratingDistribution?.length) ? (
          <Panel className="report-chart" data-chart-title="报告图表：评分分布"><h3 className="mb-4 font-semibold">评分分布</h3><KeywordBar data={(task.dashboard.ratingDistribution || []).map((item) => ({ word: item.rating, count: item.count }))} /></Panel>
        ) : task.dashboard.platformDistribution.length ? (
          <Panel className="report-chart" data-chart-title="报告图表：平台来源"><h3 className="mb-4 font-semibold">平台来源</h3><PlatformPie data={task.dashboard.platformDistribution} /></Panel>
        ) : null}
        <Panel className="report-chart xl:col-span-2" data-chart-title="报告图表：高频词云"><h3 className="mb-4 font-semibold">高频词云</h3><ReportWordCloud words={task.keywords} /></Panel>
        <Panel className="report-chart" data-chart-title="报告图表：关键词排行"><h3 className="mb-4 font-semibold">关键词排行</h3><KeywordBar data={task.keywords} /></Panel>
        <Panel className="report-chart" data-chart-title="报告图表：情感分布"><h3 className="mb-4 font-semibold">情感分布</h3><SentimentDonut data={sentimentChart} /></Panel>
        <Panel className="report-chart" data-chart-title="报告图表：主题分布"><h3 className="mb-4 font-semibold">主题分布</h3><KeywordBar data={topicChart} /></Panel>
        <Panel className="report-chart" data-chart-title="报告图表：风险雷达"><h3 className="mb-4 font-semibold">风险雷达</h3><RiskRadar data={task.dashboard.riskRadar} /></Panel>
        {task.trend.length && task.timeline.length ? (
          <Panel className="report-chart xl:col-span-2" data-chart-title="报告图表：热度趋势与事件转折"><h3 className="mb-4 font-semibold">热度趋势与事件转折</h3><EventTrendTimeline trend={task.trend} timeline={task.timeline} /></Panel>
        ) : null}
      </div>

      {report ? (
        <>
          <Panel>
            <pre className="max-h-[560px] overflow-auto whitespace-pre-wrap text-sm leading-7 text-slate-700">{report.markdown}</pre>
          </Panel>
          <div className="flex flex-wrap gap-3">
            <Button variant="secondary" onClick={() => navigator.clipboard.writeText(report.markdown)}><Copy className="h-4 w-4" />复制报告</Button>
            <Button onClick={() => downloadTextFile(report.markdown, `${reportBaseName}.md`, "text/markdown;charset=utf-8")}><Download className="h-4 w-4" />Markdown</Button>
            <Button variant="secondary" onClick={() => downloadWordReport(report.markdown, `${reportBaseName}.docx`)}><Download className="h-4 w-4" />Word</Button>
          </div>
        </>
      ) : (
        <Panel>
          <p className="text-muted">点击“生成报告”后，这里会显示完整报告正文和下载按钮。</p>
        </Panel>
      )}
    </div>
  );
}

function BasicModeNotice() {
  return (
    <Panel className="border-amber-300/70 bg-amber-50/80 p-4">
      <p className="text-sm text-amber-800">当前使用基础分析模式：NLP 模型服务暂未连接，页面会继续展示可用分析结果。</p>
    </Panel>
  );
}

function EventOverviewCard({ task }: { task: AnalysisTask }) {
  const event = task.event;
  const briefRows = [
    ["What", event.brief?.what],
    ["When", event.brief?.when],
    ["Where", event.brief?.where],
    ["Who", event.brief?.who?.join("、")],
    ["Why", event.brief?.why],
    ["How", event.brief?.how]
  ].filter(([, value]) => isUsefulValue(value));
  const dynamicRows = event.dynamicFields?.length
    ? event.dynamicFields.map((item) => [item.label, item.evidence ? `${item.value}（依据：${item.evidence}）` : item.value] as [string, string])
    : [
      ["事件类别", event.category],
      ["事件类型", event.eventType],
      ["核心主体", event.subjects.join("、")],
      ["核心议题", event.coreIssues.join("、")],
      ["样本阶段", event.stage]
    ];
  const detailRows = dynamicRows.filter(([, value]) => isUsefulValue(value)) as Array<[string, string]>;

  return (
    <Panel className="border-cyan/24 bg-cyan/[0.045]">
      <div className="grid gap-5 lg:grid-cols-[1.1fr_0.9fr]">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-xs font-medium uppercase tracking-[0.16em] text-cyan">事件概览</p>
            {event.recognitionMode === "deepseek" && (
              <span className="rounded-md border border-cyan/20 bg-cyan/10 px-2 py-0.5 text-xs text-cyan">智能识别</span>
            )}
          </div>
          <h2 className="mt-2 text-2xl font-semibold text-foreground">{event.name}</h2>
          <p className="mt-3 max-w-3xl text-sm leading-7 text-muted">{event.summary}</p>
          {briefRows.length > 0 && (
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {briefRows.map(([label, value]) => (
                <div key={label} className="rounded-lg border border-slate-200/80 bg-white/65 p-3">
                  <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">{label}</p>
                  <p className="mt-1 text-sm leading-6 text-foreground">{value}</p>
                </div>
              ))}
            </div>
          )}
        </div>
        {detailRows.length > 0 ? <InfoRows rows={detailRows} /> : null}
      </div>
    </Panel>
  );
}

function isUsefulValue(value: string | number | undefined | null) {
  const text = String(value ?? "").trim();
  if (!text) return false;
  return !["无", "未知", "未识别", "未见集中争议", "时间信息不足"].includes(text);
}

function SourceFilesSummary({ files }: { files: DatasetSourceFile[] }) {
  if (files.length <= 1) return null;
  return (
    <Panel>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Source files</p>
          <h2 className="mt-1 text-xl font-semibold">多来源文件构成</h2>
        </div>
        <span className="rounded-lg border border-cyan/20 bg-cyan/10 px-3 py-1 text-sm text-cyan">
          {files.length} 个文件
        </span>
      </div>
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {files.map((file) => (
          <div key={file.id} className="rounded-lg border border-slate-200/80 bg-white/60 p-4">
            <p className="truncate font-semibold" title={file.name}>{file.name}</p>
            <p className="mt-2 text-sm text-muted">
              纳入 {file.recordsIncluded} 条{file.sampled ? "，已采样" : ""}
            </p>
            <p className="mt-2 text-sm text-cyan">
              {file.platformName ? `平台：${file.platformName}` : file.objectName ? `对象：${file.objectName}` : "通用文本来源"}
            </p>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function DataPreview({ records }: { records: Array<[string, string]> }) {
  return (
    <Panel>
      <h2 className="mb-4 text-xl font-semibold">数据预览</h2>
      <div className="overflow-hidden rounded-lg border border-slate-200/80 bg-white/50">
        {records.map(([label, content], index) => (
          <div key={`${label}-${index}`} className="grid grid-cols-[110px_1fr] gap-3 border-b border-slate-200/70 p-3 text-sm last:border-b-0">
            <span className="font-medium text-cyan">{label || "评论"}</span>
            <span className="text-muted">{content}</span>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function InfoRows({ rows }: { rows: Array<[string, string | number | undefined]> }) {
  return (
    <div className="space-y-2 text-sm">
      {rows.map(([label, value]) => (
        <div key={label} className="flex items-center justify-between gap-4 rounded-lg border border-slate-200/80 bg-white/60 px-3 py-2">
          <span className="text-muted">{label}</span>
          <span className="font-medium text-foreground">{value || "无"}</span>
        </div>
      ))}
    </div>
  );
}

function FieldMappingRows({ mapping }: { mapping: FieldMapping }) {
  return (
    <InfoRows rows={[
      ["评论内容字段", mapping.textField || "未识别"],
      ["时间字段", mapping.timeField || "未识别"],
      ["评分字段", mapping.ratingField || "无"],
      ["点赞字段", mapping.likeField || "无"],
      ["用户字段", mapping.userField || "无"],
      ["用户 ID 字段", mapping.userIdField || "无"],
      ["分析对象字段", mapping.objectField || "无"],
      ["来源链接字段", mapping.sourceUrlField || "无"],
      ["平台字段", mapping.platformField || mapping.staticPlatform || "空"]
    ]} />
  );
}

function TermPanel({ title, items, compact = false }: { title: string; items: LexiconItem[]; compact?: boolean }) {
  return (
    <Panel className={compact ? "p-4" : undefined}>
      <h3 className="font-semibold">{title}</h3>
      <div className="mt-4 flex flex-wrap gap-2">
        {items.length ? items.map((item) => (
          <span key={item.term} className="rounded-lg border border-cyan/20 bg-cyan/10 px-3 py-2 text-sm text-cyan">
            {item.term}<span className="ml-2 text-muted">{item.count}</span>
          </span>
        )) : <span className="text-sm text-muted">未识别到明显词汇</span>}
      </div>
      {!compact && items[0]?.examples[0] && (
        <p className="mt-4 text-sm leading-6 text-muted">例句：{items[0].examples[0]}</p>
      )}
    </Panel>
  );
}

function isReadableTopicChip(word: string) {
  const value = word.trim();
  if (!value) return false;
  if (/^\d+$/.test(value)) return false;
  if (/^[a-z0-9_]{1,}$/i.test(value) && !/^unesco$/i.test(value)) return false;
  if (value.length < 2 || value.length > 14) return false;
  if (/^(回复|评论|视频|弹幕|内容|观点|平台|媒体|用户|网友|这个|那个|这么|可以|应该|地方|还有|不到|网上|super|up|bip|call|doge)$/i.test(value)) return false;
  return true;
}

function isGenericTopicName(name: string) {
  return !name || /相关讨论|综合讨论|其他讨论|长尾|补充表达|基础主题|围绕“/.test(name);
}

function displayTopicName(topic: TopicItem) {
  const text = `${topic.name} ${topic.keywords.join(" ")} ${topic.representativeTexts.join(" ")}`;
  if (!isGenericTopicName(topic.name)) return topic.name;
  if (/预约|名额|门票|抢掉|抢不到|抢名额|约上|约不上|难约|看展|逛国博|参观/.test(text)) return "预约名额与参观体验冲突";
  if (/黄牛|倒卖|代购|加价|限购|抢购/.test(text)) return "抢购秩序与黄牛风险";
  if (/价格|太贵|性价比|割韭菜|值不值|不值/.test(text)) return "价格与消费体验争议";
  if (/消费|购买|淘宝|没抢上|抢不到|想买|到手|买到|售罄|缺货/.test(text)) return "购买体验与爆款供需";
  if (/凤冠|冰箱贴|国博|国家博物馆|文创产品|爆款|热卖|销量/.test(text)) return "爆款文创与销售热度";
  if (/好看|审美|拍照|种草|打卡|出圈|体验|发卡|卡头发|造型|漂亮|精致|设计/.test(text)) return "审美造型与体验评价";
  if (/先看|看看|等等|观望|给点时间|时间嘛|后续/.test(text)) return "观望等待与信息补充";
  if (/文化|传统|传承|非遗|申遗|春节|节日|遗产/.test(text)) return "文化认同与传统传承";
  if (/相关讨论|综合讨论|其他讨论/.test(topic.name)) {
    const readable = topic.keywords.filter(isReadableTopicChip).slice(0, 2);
    return readable.length ? `${readable.join("与")}相关讨论` : "长尾评论与补充表达";
  }
  return topic.name;
}

function buildTopicChartData(topics: TopicItem[], fallback: Array<{ word: string; count: number }>) {
  if (!topics.length) return fallback.slice(0, 8);
  const grouped = new Map<string, number>();
  topics.forEach((topic) => {
    const name = displayTopicName(topic);
    grouped.set(name, (grouped.get(name) || 0) + topic.size);
  });
  return [...grouped.entries()]
    .map(([word, count]) => ({ word, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);
}

const reportFileTerms: Array<[RegExp, string]> = [
  [/国家博物馆|国博/i, "NationalMuseum"],
  [/凤冠/i, "PhoenixCrown"],
  [/冰箱贴/i, "RefrigeratorMagnet"],
  [/春节/i, "SpringFestival"],
  [/申遗|非遗/i, "UNESCOIntangibleHeritage"],
  [/英歌舞/i, "YinggeDance"],
  [/只此青绿|青绿/i, "PoeticDance"],
  [/中轴线/i, "CentralAxis"],
  [/故宫/i, "ForbiddenCity"],
  [/文创/i, "CulturalCreative"],
  [/特朗普/i, "Trump"],
  [/访华/i, "ChinaVisit"]
];

function sanitizeAsciiFileName(value: string) {
  return value
    .replace(/[^a-z0-9]+/gi, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

function buildReportFileBase(task: AnalysisTask) {
  const source = [
    task.event?.name,
    task.event?.summary,
    task.dashboard.objectName,
    task.dataset.name
  ].filter(Boolean).join(" ");
  const matched = reportFileTerms
    .filter(([pattern]) => pattern.test(source))
    .map(([, label]) => label)
    .filter((label, index, all) => all.indexOf(label) === index);
  if (matched.length) return `${matched.join("-")}-analysis-report`;
  const ascii = sanitizeAsciiFileName(task.event?.name || task.dataset.name || "");
  return `${ascii || `event-${task.id.slice(-6)}`}-analysis-report`;
}

const reportWordPositions = [
  { x: 506, y: 205, rotate: 0, scale: 1.14 },
  { x: 376, y: 194, rotate: -7, scale: 0.86 },
  { x: 633, y: 196, rotate: 4, scale: 0.78 },
  { x: 505, y: 264, rotate: 0, scale: 0.68 },
  { x: 382, y: 254, rotate: -3, scale: 0.5 },
  { x: 625, y: 258, rotate: 5, scale: 0.48 },
  { x: 505, y: 145, rotate: 0, scale: 0.46 },
  { x: 292, y: 215, rotate: -8, scale: 0.42 },
  { x: 725, y: 220, rotate: 7, scale: 0.4 },
  { x: 330, y: 138, rotate: 6, scale: 0.36 },
  { x: 675, y: 138, rotate: -6, scale: 0.36 },
  { x: 420, y: 316, rotate: 4, scale: 0.35 },
  { x: 585, y: 318, rotate: -4, scale: 0.35 },
  { x: 250, y: 274, rotate: 7, scale: 0.32 },
  { x: 755, y: 278, rotate: -7, scale: 0.32 },
  { x: 245, y: 158, rotate: -4, scale: 0.3 },
  { x: 760, y: 158, rotate: 5, scale: 0.3 },
  { x: 455, y: 100, rotate: -5, scale: 0.29 },
  { x: 555, y: 102, rotate: 5, scale: 0.29 },
  { x: 320, y: 330, rotate: -5, scale: 0.28 },
  { x: 688, y: 333, rotate: 5, scale: 0.28 },
  { x: 185, y: 218, rotate: -7, scale: 0.26 },
  { x: 820, y: 220, rotate: 7, scale: 0.26 }
];

function ReportWordCloud({ words }: { words: Array<{ word: string; count: number; weight?: number }> }) {
  const items = words.slice(0, reportWordPositions.length);
  const maxCount = Math.max(...items.map((item) => item.count), 1);
  const colors = ["#13B6D1", "#6674F5", "#2DBE8F", "#0F7490", "#8B6EF2"];

  return (
    <svg role="img" aria-label="高频词云" viewBox="0 0 1000 390" width="100%" height="330" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="report-word-cloud-bg-main" cx="50%" cy="50%" r="55%">
          <stop offset="0%" stopColor="#D8F8FA" stopOpacity="0.78" />
          <stop offset="52%" stopColor="#D8F8FA" stopOpacity="0.34" />
          <stop offset="100%" stopColor="#D8F8FA" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="report-word-cloud-bg-cool" cx="50%" cy="50%" r="55%">
          <stop offset="0%" stopColor="#DDE4FF" stopOpacity="0.52" />
          <stop offset="70%" stopColor="#DDE4FF" stopOpacity="0.16" />
          <stop offset="100%" stopColor="#DDE4FF" stopOpacity="0" />
        </radialGradient>
        <filter id="report-word-cloud-soften" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="18" />
        </filter>
      </defs>
      <rect x="14" y="14" width="972" height="362" rx="22" fill="#F7FDFF" stroke="#BDECF4" />
      <ellipse cx="500" cy="202" rx="360" ry="132" fill="url(#report-word-cloud-bg-main)" filter="url(#report-word-cloud-soften)" />
      <ellipse cx="512" cy="205" rx="245" ry="86" fill="url(#report-word-cloud-bg-cool)" filter="url(#report-word-cloud-soften)" />
      <ellipse cx="500" cy="204" rx="300" ry="112" fill="#DFF8FA" opacity="0.16" />
      {items.map((item, index) => {
        const pos = reportWordPositions[index];
        const weight = Math.pow(item.count / maxCount, 0.54);
        const lengthPenalty = item.word.length > 5 ? Math.max(0.72, 1 - (item.word.length - 5) * 0.045) : 1;
        const size = Math.round((22 + weight * 46) * pos.scale * lengthPenalty);
        return (
          <text
            key={`${item.word}-${index}`}
            x={pos.x}
            y={pos.y}
            textAnchor="middle"
            dominantBaseline="middle"
            transform={`rotate(${pos.rotate} ${pos.x} ${pos.y})`}
            fontFamily="Microsoft YaHei, Arial, sans-serif"
            fontSize={Math.max(15, size)}
            fontWeight={index < 5 ? 700 : 600}
            fill={colors[index % colors.length]}
            opacity={index < 8 ? 0.95 : 0.72}
            style={{ paintOrder: "stroke", stroke: "rgba(247,253,255,.76)", strokeWidth: index < 5 ? 5 : 3 }}
          >
            {item.word}
          </text>
        );
      })}
    </svg>
  );
}

function displayTopicJudgment(topic: TopicItem, name: string) {
  if (name.includes("预约名额")) return "该主题直接指向爆款消费需求挤占正常参观名额的问题，属于体验受损型负面焦点，需要结合高点赞评论持续观察。";
  if (name.includes("抢购秩序")) return "该主题涉及抢购、倒卖或加价风险，风险来自秩序受损和公平性质疑，而不是单纯热度高。";
  if (name.includes("价格")) return "该主题围绕价格、购买门槛和消费值不值展开，若高互动吐槽持续增加，可能转化为消费体验争议。";
  if (name.includes("购买体验")) return "该主题集中在想买、购买渠道、是否抢得到和到手体验上。若表达以“漂亮、想买、抢手”为主，应理解为爆款热度；只有伴随黄牛、加价或预约挤占时才上升为风险。";
  if (name.includes("审美")) return "该主题主要讨论造型、佩戴体验和产品设计，既可能形成种草扩散，也可能暴露具体体验短板。";
  if (name.includes("爆款文创")) return "该主题反映文创产品销售热度和传播效果，热度本身不等同于风险，需要结合购买秩序和体验反馈判断。";
  if (name.includes("观望等待")) return "该主题多为等待信息补充或暂缓判断的表达，适合作为长尾观察线索。";
  if (name.includes("文化认同")) return "该主题偏向价值认同和文化传播表达，通常是正向关注点，除非同时出现误读、争议或排斥性表达。";
  if (topic.judgment && !/常规观察议题|可作为常规观察|负面风险较低/.test(topic.judgment)) return topic.judgment;
  return "该主题当前以分散表达为主，建议结合代表评论和互动量判断其后续是否形成明确议题。";
}

function TopicCard({ topic, risky }: { topic: TopicItem; risky: boolean }) {
  const displayName = displayTopicName(topic);
  const keywords = topic.keywords.filter(isReadableTopicChip).slice(0, 6);
  const judgment = displayTopicJudgment(topic, displayName);
  const attentionLevel = topic.percentage >= 25 ? "高关注" : topic.percentage >= 10 ? "中等关注" : "常规观察";
  const riskLevel = topic.riskLevel || "低";
  return (
    <div className={cn("rounded-lg border bg-white/60 p-4", risky ? "border-rose-300/80" : topic.percentage >= 25 ? "border-cyan/35" : "border-slate-200/80")}>
      <div className="flex items-center justify-between gap-3">
        <h3 className="font-semibold">{displayName}</h3>
        <span className="text-sm text-muted">{topic.percentage.toFixed(1)}%</span>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {keywords.length ? keywords.map((word) => <span key={word} className="rounded-lg bg-cyan/10 px-2 py-1 text-xs text-cyan">{word}</span>) : (
          <span className="rounded-lg bg-slate-100 px-2 py-1 text-xs text-muted">关键词不足，查看代表评论</span>
        )}
      </div>
      <div className="mt-3 flex flex-wrap gap-2 text-xs">
        <span className="rounded-lg border border-slate-200/80 bg-white/70 px-2 py-1 text-muted">情绪倾向：{topic.sentimentTendency || "中性"}</span>
        <span className={cn("rounded-lg px-2 py-1", riskLevel === "高" ? "bg-rose-50 text-rose-600" : riskLevel === "中" ? "bg-amber-50 text-amber-700" : "bg-emerald-50 text-emerald-700")}>负面风险：{riskLevel}</span>
        <span className="rounded-lg border border-cyan/20 bg-cyan/10 px-2 py-1 text-cyan">{attentionLevel}</span>
      </div>
      {topic.representativeTexts[0] && <p className="mt-3 text-sm leading-6 text-muted">{topic.representativeTexts[0]}</p>}
      <p className="mt-3 text-sm leading-6 text-muted">{judgment}</p>
      {risky && <p className="mt-3 inline-flex items-center gap-2 text-xs text-rose-600"><AlertTriangle className="h-3.5 w-3.5" />高负面风险主题</p>}
    </div>
  );
}

function ClusterCard({ cluster, risky }: { cluster: ClusterItem; risky: boolean }) {
  const terms = cluster.topTerms.filter(isReadableTopicChip).slice(0, 6);
  return (
    <div className={cn("rounded-lg border bg-white/60 p-4", risky ? "border-rose-300/80" : "border-slate-200/80")}>
      <div className="flex items-center justify-between gap-3">
        <h3 className="font-semibold">{cluster.label}</h3>
        <span className="text-sm text-muted">{cluster.size} 条</span>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {terms.length ? terms.map((word) => <span key={word} className="rounded-lg bg-indigo-50 px-2 py-1 text-xs text-indigo-600">{word}</span>) : (
          <span className="rounded-lg bg-slate-100 px-2 py-1 text-xs text-muted">关键词不足，查看代表评论</span>
        )}
      </div>
      {cluster.representativeTexts[0] && <p className="mt-3 text-sm leading-6 text-muted">{cluster.representativeTexts[0]}</p>}
      {risky && <p className="mt-3 inline-flex items-center gap-2 text-xs text-rose-600"><AlertTriangle className="h-3.5 w-3.5" />需要优先观察</p>}
    </div>
  );
}

type SemanticQuadrant = "高热正向" | "低热正向" | "高热负向" | "低热负向";
type SemanticPoint = {
  clusterId: number;
  text: string;
  label: string;
  plotX: number;
  plotY: number;
  quadrant: SemanticQuadrant;
};

const positiveHints = [
  "好看", "精彩", "推荐", "喜欢", "震撼", "燃", "感动", "不错", "流畅", "优秀", "特效",
  "漂亮", "超级漂亮", "精致", "想买", "值得买", "抢手", "爆款", "热门",
  "支持", "期待", "期盼", "希望", "厉害", "合作共赢", "共赢", "和平发展", "友好",
  "意义重大", "求同存异", "携手共进", "以礼相待", "以诚相交", "忠诚", "祝贺", "恭喜",
  "成功", "胜利", "开心", "高兴", "快乐", "好消息", "骄傲", "自豪", "点赞", "棒", "正能量"
];
const neutralHints = ["愉快", "哈哈", "咖啡", "鲜花", "假期", "评论", "新闻", "视频", "弹幕", "分钟"];
const quadrantMeta: Record<SemanticQuadrant, { title: string; desc: string; color: string; bg: string }> = {
  高热正向: { title: "高热正向", desc: "高关注且评价偏积极，常代表口碑亮点。", color: "bg-emerald-500", bg: "bg-emerald-50/70" },
  低热正向: { title: "低热正向", desc: "评价偏积极但传播强度较低，适合提炼稳定优点。", color: "bg-cyan", bg: "bg-cyan/5" },
  高热负向: { title: "高热负向", desc: "高关注且评价偏负面，需要优先解释其争议来源。", color: "bg-rose-500", bg: "bg-rose-50/80" },
  低热负向: { title: "低热负向", desc: "负向评价存在但扩散较弱，适合纳入长尾观察。", color: "bg-amber-500", bg: "bg-amber-50/80" }
};

function ClusterScatter({ points }: { points: SemanticPoint[] }) {
  return (
    <div className="relative h-[390px] overflow-hidden rounded-lg border border-cyan/20 bg-gradient-to-br from-white/90 to-cyan/5">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(19,182,209,0.08)_1px,transparent_1px),linear-gradient(90deg,rgba(19,182,209,0.08)_1px,transparent_1px)] bg-[size:34px_34px]" />
      <div className="absolute left-1/2 top-8 h-[292px] w-px bg-slate-300" />
      <div className="absolute left-12 right-8 top-1/2 h-px bg-slate-300" />
      <div className="absolute left-14 top-10 rounded bg-rose-50/90 px-2 py-1 text-xs text-rose-600">高热负向</div>
      <div className="absolute right-10 top-10 rounded bg-emerald-50/90 px-2 py-1 text-xs text-emerald-600">高热正向</div>
      <div className="absolute bottom-16 left-14 rounded bg-amber-50/90 px-2 py-1 text-xs text-amber-600">低热负向</div>
      <div className="absolute bottom-16 right-10 rounded bg-cyan/10 px-2 py-1 text-xs text-cyan">低热正向</div>
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-xs text-muted">情绪立场：负面 -1 ← 0 → +1 正面</div>
      <div className="absolute left-2 top-1/2 -translate-y-1/2 -rotate-90 text-xs text-muted">表达强度 / 互动热度</div>
      <span className="absolute bottom-[66px] left-12 text-[11px] text-muted">-1</span>
      <span className="absolute bottom-[66px] left-1/2 text-[11px] text-muted">0</span>
      <span className="absolute bottom-[66px] right-8 text-[11px] text-muted">+1</span>
      <span className="absolute left-8 top-9 text-[11px] text-muted">高</span>
      <span className="absolute bottom-20 left-8 text-[11px] text-muted">低</span>
      {points.map((point, index) => {
        const meta = quadrantMeta[point.quadrant];
        return (
          <span
            key={`${point.clusterId}-${index}`}
            title={`${point.label}｜${point.quadrant}\n${point.text}`}
            className={cn("absolute h-3 w-3 rounded-full shadow-glow transition hover:z-10 hover:scale-150", meta.color)}
            style={{ left: `${point.plotX}%`, top: `${100 - point.plotY}%` }}
          />
        );
      })}
    </div>
  );
}

function QuadrantInsights({ points }: { points: SemanticPoint[] }) {
  const total = Math.max(points.length, 1);
  const rows = (Object.keys(quadrantMeta) as SemanticQuadrant[]).map((quadrant) => {
    const items = points.filter((point) => point.quadrant === quadrant);
    return {
      quadrant,
      count: items.length,
      percent: Math.round((items.length / total) * 100),
      example: items[0]?.text || "暂无代表评论",
      labels: Array.from(new Set(items.map((item) => item.label))).slice(0, 2).join("、")
    };
  });

  return (
    <div className="space-y-3">
      {rows.map((row) => {
        const meta = quadrantMeta[row.quadrant];
        return (
          <div key={row.quadrant} className={cn("rounded-lg border border-slate-200/80 p-4", meta.bg)}>
            <div className="flex items-center justify-between gap-3">
              <h3 className="font-semibold">{meta.title}</h3>
              <span className="text-sm text-muted">{row.count} 条 · {row.percent}%</span>
            </div>
            <p className="mt-2 text-sm leading-6 text-muted">{meta.desc}</p>
            {row.labels && <p className="mt-2 text-xs text-cyan">主要关联：{row.labels}</p>}
            <p className="mt-2 line-clamp-2 text-sm leading-6 text-slate-600">{row.example}</p>
          </div>
        );
      })}
    </div>
  );
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function inferSentimentScore(text: string, label: string) {
  if (/(价格|售价|定价|卖|要)\s*[0-9０-９]{1,5}\s*(元|块|￥)?/.test(text) && /(不需要|劝退|不值|不划算|下不去手|买不起|瞬间|算了|放弃)/.test(text)) {
    return -0.75;
  }
  if (/(漂亮|好看|精致|想买|值得买).*(抢|没抢上|抢不到|一个多月)/.test(text) && !/(预约名额|名额被抢|抢掉|黄牛|倒卖|加价|正常想逛)/.test(text)) {
    return 0.62;
  }
  let positive = positiveHints.reduce((sum, word) => sum + (text.includes(word) || label.includes(word) ? 1 : 0), 0);
  let negative = negativeHints.reduce((sum, word) => sum + (text.includes(word) || label.includes(word) ? 1 : 0), 0);
  if (/(漂亮|好看|精致|想买|值得买).*(抢|没抢上|抢不到|一个多月)/.test(text) && !/(预约名额|名额被抢|抢掉|黄牛|倒卖|加价|正常想逛)/.test(text)) {
    positive += 3;
    negative = Math.max(0, negative - 1);
  }
  const neutral = neutralHints.reduce((sum, word) => sum + (text.includes(word) || label.includes(word) ? 1 : 0), 0);
  if (positive || negative) return clamp((positive - negative) / Math.max(positive + negative, 1), -1, 1);
  if (neutral) return 0;
  if (label.includes("视觉") || label.includes("动作")) return 0.45;
  if (label.includes("角色") || label.includes("英雄")) return 0.18;
  if (label.includes("反派") || label.includes("冲突")) return -0.22;
  if (label.includes("口碑") || label.includes("分化")) return -0.08;
  if (label.includes("合作") || label.includes("和平") || label.includes("正向")) return 0.55;
  if (label.includes("疑问") || label.includes("负向") || label.includes("风险")) return -0.55;
  if (label.includes("日常") || label.includes("低信息") || label.includes("长尾")) return 0;
  return 0;
}

function buildSemanticPoints(clusters: ClusterItem[]): SemanticPoint[] {
  const raw = clusters.flatMap((cluster) => {
    if (cluster.coordinates?.length) {
      return cluster.coordinates.slice(0, 42).map((point) => ({
        x: point.x,
        y: point.y,
        clusterId: cluster.clusterId,
        text: point.text || cluster.representativeTexts[0] || cluster.label,
        label: cluster.label
      }));
    }
    return cluster.representativeTexts.slice(0, 8).map((text, index) => ({
      x: cluster.clusterId,
      y: cluster.percentage + index,
      clusterId: cluster.clusterId,
      text,
      label: cluster.label
    }));
  });
  const points = raw.length ? raw : [{ x: 0, y: 0, clusterId: 0, text: "暂无可定位评论", label: "基础主题" }];
  const minY = Math.min(...points.map((point) => point.y));
  const maxY = Math.max(...points.map((point) => point.y));

  return points.map((point, index) => {
    const sentiment = inferSentimentScore(point.text, point.label);
    const normalizedY = maxY === minY ? 0.52 : (point.y - minY) / (maxY - minY);
    const intensity = clamp(0.18 + normalizedY * 0.68 + Math.abs(sentiment) * 0.12, 0.12, 0.94);
    const jitterX = ((index % 5) - 2) * 1.6;
    const jitterY = (((index + point.clusterId) % 5) - 2) * 1.4;
    const plotX = clamp(50 + sentiment * 35 + jitterX, 9, 91);
    const plotY = clamp(14 + intensity * 76 + jitterY, 13, 91);
    const quadrant: SemanticQuadrant = sentiment < 0
      ? intensity >= 0.55 ? "高热负向" : "低热负向"
      : intensity >= 0.55 ? "高热正向" : "低热正向";
    return { clusterId: point.clusterId, text: point.text, label: point.label, plotX, plotY, quadrant };
  });
}

function dominantQuadrant(points: SemanticPoint[]) {
  const counts = new Map<SemanticQuadrant, number>();
  points.forEach((point) => counts.set(point.quadrant, (counts.get(point.quadrant) || 0) + 1));
  return [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || "暂无";
}

function hasNegativeSignal(texts: string[]) {
  return texts.some((text) => negativeHints.some((hint) => text.includes(hint)));
}

function findRiskyTopic(topics: TopicItem[]) {
  return topics.find((topic) => topic.riskLevel === "高" && topic.percentage >= 12 && hasNegativeSignal([...topic.keywords, ...topic.representativeTexts]));
}

function findRiskyCluster(clusters: ClusterItem[]) {
  return clusters.find((cluster) => cluster.riskLevel === "高" && cluster.percentage >= 12 && hasNegativeSignal([...cluster.topTerms, ...cluster.representativeTexts]));
}

function fallbackTopics(task: AnalysisTask): TopicItem[] {
  return [{
    topicId: 0,
    name: task.dashboard.sourceMode === "object_review" ? "综合观影体验讨论" : "基础主题摘要",
    size: task.clean.validCount,
    percentage: 100,
    keywords: task.keywords.slice(0, 6).map((item) => item.word),
    representativeTexts: task.clean.records.slice(0, 2).map((item) => item.content)
  }];
}

function fallbackClusters(task: AnalysisTask): ClusterItem[] {
  return [{
    clusterId: 0,
    label: task.dashboard.sourceMode === "object_review" ? "综合观影体验" : "基础语义聚类",
    size: task.clean.validCount,
    percentage: 100,
    topTerms: task.keywords.slice(0, 6).map((item) => item.word),
    representativeTexts: task.clean.records.slice(0, 2).map((item) => item.content)
  }];
}
