import { NextRequest, NextResponse } from "next/server";
import { generateReportWithDeepSeek } from "@/lib/analysis/deepseekReport";
import { reports, tasks } from "@/lib/store/memory";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const { taskId } = await request.json();
  const task = tasks.get(taskId);
  if (!task) return NextResponse.json({ error: "Task not found" }, { status: 404 });
  const report = await generateReportWithDeepSeek(task);
  reports.set(report.id, report);
  return NextResponse.json({ report });
}

