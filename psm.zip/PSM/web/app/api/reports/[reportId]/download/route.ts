import { NextRequest, NextResponse } from "next/server";
import { reports } from "@/lib/store/memory";

const mimeMap = {
  markdown: "text/markdown;charset=utf-8",
  md: "text/markdown;charset=utf-8",
  word: "application/msword;charset=utf-8",
  doc: "application/msword;charset=utf-8"
} as const;

export async function GET(request: NextRequest, { params }: { params: { reportId: string } }) {
  const report = reports.get(params.reportId);
  if (!report) return NextResponse.json({ error: "Report not found" }, { status: 404 });
  const format = request.nextUrl.searchParams.get("format") || "markdown";
  const isWord = format === "word" || format === "doc";
  const content = isWord ? report.html : report.markdown;
  const suffix = isWord ? "doc" : "md";
  return new NextResponse(content, {
    headers: {
      "content-type": mimeMap[format as keyof typeof mimeMap] || mimeMap.markdown,
      "content-disposition": `attachment; filename="network-opinion-analysis-report.${suffix}"`
    }
  });
}
