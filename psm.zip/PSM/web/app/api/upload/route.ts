import { NextRequest, NextResponse } from "next/server";
import JSZip from "jszip";
import { MAX_TEXT_BYTES, parsePlainText, parseUploadedFile } from "@/lib/dataAdapter";
import type { Dataset, DatasetKind, DatasetSourceFile, FieldMapping, OpinionRecord } from "@/lib/types";
import { datasets } from "@/lib/store/memory";

export const runtime = "nodejs";

const MAX_COMBINED_RECORDS = 12000;
const MAX_EVENT_MATERIAL_BYTES = 4 * 1024 * 1024;

type UploadFileError = {
  name: string;
  reason: string;
};

function emptyMapping(): FieldMapping {
  return {
    ignoredFields: [],
    metadataFields: [],
    availableFields: [],
    detectedKind: "generic_comment",
    dataProfile: "generic_comment"
  };
}

function firstValue(records: OpinionRecord[], key: "platform" | "objectName") {
  return records.find((record) => record[key])?.[key] || undefined;
}

function mergeText(values: Array<string | undefined>) {
  const unique = Array.from(new Set(values.filter(Boolean) as string[]));
  if (!unique.length) return undefined;
  if (unique.length === 1) return unique[0];
  return `${unique.slice(0, 3).join(" / ")}${unique.length > 3 ? " 等" : ""}`;
}

function mergeArray(values: Array<string[] | undefined>) {
  return Array.from(new Set(values.flatMap((items) => items || []).filter(Boolean)));
}

function mergeDatasetKind(mappings: FieldMapping[]): DatasetKind {
  if (mappings.some((mapping) => mapping.detectedKind === "platform_opinion" || mapping.platformField || mapping.staticPlatform)) {
    return "platform_opinion";
  }
  if (mappings.some((mapping) => mapping.detectedKind === "object_review" || mapping.objectField)) {
    return "object_review";
  }
  return "generic_comment";
}

function mergeMappings(mappings: FieldMapping[]): FieldMapping {
  if (!mappings.length) return emptyMapping();
  const dataProfiles = Array.from(new Set(mappings.map((mapping) => mapping.dataProfile).filter(Boolean)));
  const staticPlatforms = Array.from(new Set(mappings.map((mapping) => mapping.staticPlatform).filter(Boolean) as string[]));
  return {
    textField: mergeText(mappings.map((mapping) => mapping.textField)),
    timeField: mergeText(mappings.map((mapping) => mapping.timeField)),
    ratingField: mergeText(mappings.map((mapping) => mapping.ratingField)),
    likeField: mergeText(mappings.map((mapping) => mapping.likeField)),
    userField: mergeText(mappings.map((mapping) => mapping.userField)),
    userIdField: mergeText(mappings.map((mapping) => mapping.userIdField)),
    objectField: mergeText(mappings.map((mapping) => mapping.objectField)),
    objectAliasField: mergeText(mappings.map((mapping) => mapping.objectAliasField)),
    collectedAtField: mergeText(mappings.map((mapping) => mapping.collectedAtField)),
    platformField: mergeText(mappings.map((mapping) => mapping.platformField)),
    staticPlatform: staticPlatforms.length === 1 ? staticPlatforms[0] : undefined,
    sourceUrlField: mergeText(mappings.map((mapping) => mapping.sourceUrlField)),
    areaField: mergeText(mappings.map((mapping) => mapping.areaField)),
    metadataFields: mergeArray(mappings.map((mapping) => mapping.metadataFields)),
    availableFields: mergeArray(mappings.map((mapping) => mapping.availableFields)),
    dataProfile: dataProfiles.length === 1 ? dataProfiles[0] : "generic_comment",
    ignoredFields: mergeArray(mappings.map((mapping) => mapping.ignoredFields)),
    detectedKind: mergeDatasetKind(mappings)
  };
}

function annotateRecords(records: OpinionRecord[], sourceName: string, sourceIndex: number, mapping: FieldMapping) {
  return records.map((record, index) => ({
    ...record,
    id: `${sourceIndex + 1}_${record.id || index + 1}`,
    metadata: {
      ...(record.metadata || {}),
      sourceFile: sourceName,
      sourceIndex: sourceIndex + 1,
      sourceDataProfile: mapping.dataProfile || "generic_comment"
    }
  }));
}

function decodeXmlEntities(value: string) {
  return value
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, "\"")
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, "&");
}

function wordDocumentXmlToText(xml: string) {
  return xml
    .replace(/<w:tab\s*\/>/g, "\t")
    .replace(/<w:br\s*\/>/g, "\n")
    .split(/<\/w:p>/)
    .map((paragraph) => decodeXmlEntities(paragraph.replace(/<[^>]+>/g, "").replace(/[ \t]+/g, " ").trim()))
    .filter(Boolean)
    .join("\n");
}

async function parseDocxEventMaterial(file: File) {
  const zip = await JSZip.loadAsync(Buffer.from(await file.arrayBuffer()));
  const documentXml = zip.file("word/document.xml");
  if (!documentXml) {
    throw new Error(`事件材料文件 ${file.name} 缺少 Word 正文内容，请确认文件为 .docx。`);
  }
  return wordDocumentXmlToText(await documentXml.async("string"));
}

async function parseEventMaterialFile(file: File) {
  const lowerName = file.name.toLowerCase();
  if (file.size > MAX_EVENT_MATERIAL_BYTES) {
    throw new Error(`事件材料文件 ${file.name} 超过 4MB，请精简后再上传。`);
  }
  if (lowerName.endsWith(".txt") || file.type.startsWith("text/")) {
    return file.text();
  }
  if (lowerName.endsWith(".docx")) {
    return parseDocxEventMaterial(file);
  }
  if (lowerName.endsWith(".doc")) {
    throw new Error("暂不支持旧版 .doc 事件材料，请另存为 .docx 或 .txt 后上传。");
  }
  throw new Error("事件材料文件仅支持 TXT 或 DOCX 格式。");
}

async function parseEventMaterialFiles(files: File[]) {
  const parts: string[] = [];
  const fileNames: string[] = [];
  for (const file of files) {
    const text = (await parseEventMaterialFile(file)).trim();
    if (!text) continue;
    fileNames.push(file.name);
    parts.push(`【${file.name}】\n${text}`);
  }
  return {
    text: parts.join("\n\n"),
    fileNames
  };
}

function mergeEventMaterial(parts: string[]) {
  return parts.map((part) => part.trim()).filter(Boolean).join("\n\n");
}

function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : String(error || "未知错误");
}

function isSupportedSourceFile(file: File) {
  const lower = file.name.toLowerCase();
  return lower.endsWith(".csv") || lower.endsWith(".txt") || lower.endsWith(".xlsx") || lower.endsWith(".xls");
}

function finalizeDataset(
  name: string,
  records: OpinionRecord[],
  fieldMapping: FieldMapping,
  sampled: boolean,
  sourceFiles: DatasetSourceFile[],
  eventMaterial?: string
): Dataset {
  return {
    id: `dataset_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    name: sampled ? `${name}（采样）` : name,
    source: sourceFiles.length > 1 ? "multi-upload" : "user",
    records,
    createdAt: new Date().toISOString(),
    kind: fieldMapping.detectedKind,
    fieldMapping,
    sourceFiles,
    eventMaterial: eventMaterial?.trim() || undefined
  };
}

async function parseSourceFile(file: File, sourceIndex: number, remainingSlots: number): Promise<{
  records: OpinionRecord[];
  mapping: FieldMapping;
  sourceFile: DatasetSourceFile;
  sampled: boolean;
}> {
  const parsed = await parseUploadedFile(file);
  const included = annotateRecords(parsed.records.slice(0, Math.max(remainingSlots, 0)), file.name, sourceIndex, parsed.mapping);
  const sampled = file.size > MAX_TEXT_BYTES || parsed.records.length > included.length;
  return {
    records: included,
    mapping: parsed.mapping,
    sampled,
    sourceFile: {
      id: `source_${sourceIndex + 1}`,
      name: file.name,
      recordsParsed: parsed.records.length,
      recordsIncluded: included.length,
      sampled,
      kind: parsed.mapping.detectedKind,
      dataProfile: parsed.mapping.dataProfile,
      platformName: firstValue(parsed.records, "platform"),
      objectName: firstValue(parsed.records, "objectName"),
      fieldMapping: parsed.mapping
    }
  };
}

function parsePastedSource(text: string, name: string, sourceIndex: number, remainingSlots: number) {
  const parsed = parsePlainText(text, name);
  const included = annotateRecords(parsed.records.slice(0, Math.max(remainingSlots, 0)), name, sourceIndex, parsed.mapping);
  const sampled = parsed.records.length > included.length;
  return {
    records: included,
    mapping: parsed.mapping,
    sampled,
    sourceFile: {
      id: `source_${sourceIndex + 1}`,
      name,
      recordsParsed: parsed.records.length,
      recordsIncluded: included.length,
      sampled,
      kind: parsed.mapping.detectedKind,
      dataProfile: parsed.mapping.dataProfile,
      platformName: firstValue(parsed.records, "platform"),
      objectName: firstValue(parsed.records, "objectName"),
      fieldMapping: parsed.mapping
    } satisfies DatasetSourceFile
  };
}

export async function POST(request: NextRequest) {
  const contentType = request.headers.get("content-type") || "";
  let records: OpinionRecord[] = [];
  let mappings: FieldMapping[] = [];
  let sourceFiles: DatasetSourceFile[] = [];
  let name = "上传数据集";
  let sampled = false;
  let eventMaterial = "";
  let eventMaterialFileNames: string[] = [];
  let eventMaterialWarning = "";
  const fileErrors: UploadFileError[] = [];

  if (contentType.includes("multipart/form-data")) {
    const form = await request.formData();
    const uploadedFiles = [...form.getAll("files"), ...form.getAll("file")]
      .filter((item): item is File => item instanceof File && item.size > 0);
    const eventMaterialFiles = form.getAll("eventMaterialFiles")
      .filter((item): item is File => item instanceof File && item.size > 0);
    const pastedText = String(form.get("text") || "");
    const pastedEventMaterial = String(form.get("eventMaterial") || form.get("eventText") || "");
    try {
      const parsedEventFiles = await parseEventMaterialFiles(eventMaterialFiles);
      eventMaterial = mergeEventMaterial([pastedEventMaterial, parsedEventFiles.text]);
      eventMaterialFileNames = parsedEventFiles.fileNames;
    } catch (error) {
      eventMaterial = mergeEventMaterial([pastedEventMaterial]);
      eventMaterialWarning = error instanceof Error ? error.message : "事件材料文件解析失败，已忽略该事件材料文件。";
    }
    sampled = String(form.get("sampled") || "") === "true";
    name = String(form.get("name") || (uploadedFiles.length > 1 ? `多来源数据集（${uploadedFiles.length} 个文件）` : "上传数据集"));

    let sourceIndex = 0;
    for (const file of uploadedFiles) {
      if (records.length >= MAX_COMBINED_RECORDS) break;
      if (!isSupportedSourceFile(file)) {
        fileErrors.push({ name: file.name, reason: "评论数据文件仅支持 CSV、TXT、XLSX、XLS。" });
        continue;
      }
      try {
        const parsed = await parseSourceFile(file, sourceIndex, MAX_COMBINED_RECORDS - records.length);
        if (!parsed.records.length) {
          fileErrors.push({ name: file.name, reason: "未识别到有效评论文本。" });
          continue;
        }
        records = records.concat(parsed.records);
        mappings.push(parsed.mapping);
        sourceFiles.push(parsed.sourceFile);
        sampled = sampled || parsed.sampled;
        sourceIndex += 1;
      } catch (error) {
        fileErrors.push({ name: file.name, reason: errorMessage(error) });
      }
    }

    if (pastedText.trim() && records.length < MAX_COMBINED_RECORDS) {
      const pastedName = uploadedFiles.length ? "粘贴文本" : name || "粘贴文本数据集";
      const parsed = parsePastedSource(pastedText, pastedName, sourceIndex, MAX_COMBINED_RECORDS - records.length);
      records = records.concat(parsed.records);
      mappings.push(parsed.mapping);
      sourceFiles.push(parsed.sourceFile);
      sampled = sampled || parsed.sampled;
    }
  } else {
    const body = await request.json();
    name = body.name || "粘贴文本数据集";
    eventMaterial = mergeEventMaterial([String(body.eventMaterial || body.eventText || "")]);
    if (body.text) {
      const parsed = parsePastedSource(body.text || "", name, 0, MAX_COMBINED_RECORDS);
      records = parsed.records;
      mappings = [parsed.mapping];
      sourceFiles = [parsed.sourceFile];
      sampled = parsed.sampled;
    }
  }

  if (!records.length) {
    const detail = fileErrors.length
      ? `失败文件：${fileErrors.slice(0, 5).map((item) => `${item.name}（${item.reason}）`).join("；")}${fileErrors.length > 5 ? " 等" : ""}`
      : "未收到可解析的评论数据文件。";
    return NextResponse.json({
      error: `请先上传评论数据文件。事件材料只用于背景梳理，不会作为评论参与情感分析。${detail}`,
      fileErrors
    }, { status: 400 });
  }

  const fieldMapping = mergeMappings(mappings);
  const dataset = finalizeDataset(name, records, fieldMapping, sampled, sourceFiles, eventMaterial);
  const objectName = dataset.records.find((record) => record.objectName)?.objectName;
  const platformName = dataset.records.find((record) => record.platform)?.platform;
  datasets.set(dataset.id, dataset);

  const clientDataset: Dataset = {
    ...dataset,
    records: dataset.records.slice(0, 20)
  };

  return NextResponse.json({
    dataset: clientDataset,
    meta: {
      sampled,
      maxRecords: MAX_COMBINED_RECORDS,
      recordsParsed: dataset.records.length,
      objectName,
      platformName,
      fieldMapping,
      sourceFiles,
      eventMaterialExcerpt: eventMaterial.trim().slice(0, 120),
      eventMaterialFileNames,
      eventMaterialWarning,
      fileErrors
    }
  });
}
