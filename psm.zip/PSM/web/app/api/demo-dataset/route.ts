import { NextResponse } from "next/server";
import type { Dataset } from "@/lib/types";
import { demoRecords } from "@/lib/mockData";
import { datasets } from "@/lib/store/memory";

export async function POST() {
  const dataset: Dataset = {
    id: `dataset_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    name: "校园服务争议示例数据",
    source: "demo",
    records: demoRecords,
    createdAt: new Date().toISOString(),
    kind: "platform_opinion",
    fieldMapping: {
      textField: "content",
      timeField: "publishTime",
      likeField: "likeCount",
      platformField: "platform",
      ignoredFields: [],
      detectedKind: "platform_opinion",
      dataProfile: "platform_comment"
    }
  };
  datasets.set(dataset.id, dataset);
  return NextResponse.json({ dataset });
}

