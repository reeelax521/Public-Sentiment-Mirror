import { NextRequest, NextResponse } from "next/server";
import { createAnalysisTask } from "@/lib/analysis";
import { datasets, tasks } from "@/lib/store/memory";

export async function POST(request: NextRequest) {
  const { datasetId } = await request.json();
  const dataset = datasets.get(datasetId);
  if (!dataset) return NextResponse.json({ error: "Dataset not found" }, { status: 404 });
  const task = await createAnalysisTask(dataset);
  tasks.set(task.id, task);
  return NextResponse.json({ task });
}

