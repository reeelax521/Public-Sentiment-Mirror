"use client";

import { Background } from "@/components/Background";
import { Button } from "@/components/ui/Button";
import { Panel } from "@/components/ui/Panel";
import { clearLegacyTaskCache } from "@/lib/clientTaskCache";
import type { Dataset, DatasetSourceFile, FieldMapping } from "@/lib/types";
import {
  ArrowRight,
  CheckCircle2,
  Database,
  FileText,
  Home,
  ScanLine,
  Trash2,
  UploadCloud
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";

const LARGE_FILE_BYTES = 12 * 1024 * 1024;

type LoadingMode = "upload" | "demo" | "analysis";

function formatFileSize(size: number) {
  if (size > 1024 * 1024) return `${(size / 1024 / 1024).toFixed(1)} MB`;
  if (size > 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${size} B`;
}

function fileKey(file: File) {
  return `${file.name}-${file.size}-${file.lastModified}`;
}

function mapLabel(value?: string) {
  return value || "未识别";
}

function LoadingPanel({
  mode,
  fileCount,
  totalSize,
  elapsedSeconds
}: {
  mode: LoadingMode;
  fileCount: number;
  totalSize: number;
  elapsedSeconds: number;
}) {
  const title = mode === "analysis" ? "正在创建分析任务" : mode === "demo" ? "正在准备示例数据" : "正在上传并识别字段";
  const detail = mode === "analysis"
    ? "系统正在清洗文本、计算关键词/情感/趋势，并会在可用时连接 NLP 模型服务。"
    : mode === "demo"
      ? "示例数据会直接进入完整分析流程。"
      : `${fileCount} 个文件，合计 ${formatFileSize(totalSize)}。`;
  const progress = Math.min(
    96,
    mode === "upload"
      ? 18 + elapsedSeconds * 7
      : mode === "analysis"
        ? 32 + elapsedSeconds * 3.5
        : 24 + elapsedSeconds * 6
  );
  const steps = mode === "analysis"
    ? ["读取字段映射", "数据清洗", "NLP/情感模型", "趋势与报告结构"]
    : mode === "upload"
      ? ["接收文件", "解析字段", "合并多来源", "等待确认"]
      : ["载入样本", "创建数据集", "进入工作台"];
  const activeIndex = Math.min(steps.length - 1, Math.floor((progress / 100) * steps.length));

  return (
    <div className="mx-5 mb-5 rounded-lg border border-cyan/25 bg-cyan/[0.055] p-4" aria-live="polite">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h3 className="font-semibold text-foreground">{title}</h3>
          <p className="mt-1 text-sm leading-6 text-muted">{detail}</p>
          <p className="mt-1 text-xs text-muted">
            已等待 {elapsedSeconds} 秒。首次启动 NLP 服务或处理多文件时可能稍慢，页面完成后会自动跳转。
          </p>
        </div>
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-cyan/20 border-t-cyan" />
      </div>
      <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/80">
        <div className="h-full rounded-full bg-cyan transition-all duration-500" style={{ width: `${progress}%` }} />
      </div>
      <div className="mt-3 grid gap-2 sm:grid-cols-4">
        {steps.map((step, index) => (
          <span
            key={step}
            className={`rounded-md px-2 py-1 text-xs ${index <= activeIndex ? "bg-cyan/10 text-cyan" : "bg-white/55 text-muted"}`}
          >
            {step}
          </span>
        ))}
      </div>
    </div>
  );
}

export default function UploadPage() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const eventFileInputRef = useRef<HTMLInputElement | null>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [eventFiles, setEventFiles] = useState<File[]>([]);
  const [eventMaterial, setEventMaterial] = useState("");
  const [loadingMode, setLoadingMode] = useState<LoadingMode | null>(null);
  const [notice, setNotice] = useState("");
  const [pendingDataset, setPendingDataset] = useState<Dataset | null>(null);
  const [fieldMapping, setFieldMapping] = useState<FieldMapping | null>(null);
  const [sourceFiles, setSourceFiles] = useState<DatasetSourceFile[]>([]);
  const [loadingSeconds, setLoadingSeconds] = useState(0);

  const totalFileSize = files.reduce((sum, file) => sum + file.size, 0);
  const isLargeFile = files.some((file) => file.size > LARGE_FILE_BYTES);

  useEffect(() => {
    if (!loadingMode) {
      setLoadingSeconds(0);
      return;
    }
    setLoadingSeconds(0);
    const timer = window.setInterval(() => setLoadingSeconds((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [loadingMode]);

  function clearRecognizedDataset() {
    setPendingDataset(null);
    setFieldMapping(null);
    setSourceFiles([]);
  }

  function addSelectedFiles(selected: FileList | null) {
    const nextFiles = Array.from(selected || []);
    if (!nextFiles.length) return;
    setFiles((current) => {
      const seen = new Set(current.map(fileKey));
      const merged = [...current];
      for (const file of nextFiles) {
        if (!seen.has(fileKey(file))) merged.push(file);
      }
      return merged;
    });
    clearRecognizedDataset();
    setNotice("");
  }

  function addEventFiles(selected: FileList | null) {
    const nextFiles = Array.from(selected || []).filter((file) => {
      const lower = file.name.toLowerCase();
      return lower.endsWith(".txt") || lower.endsWith(".docx") || file.type.startsWith("text/");
    });
    if (!nextFiles.length) return;
    setEventFiles((current) => {
      const seen = new Set(current.map(fileKey));
      const merged = [...current];
      for (const file of nextFiles) {
        if (!seen.has(fileKey(file))) merged.push(file);
      }
      return merged;
    });
    clearRecognizedDataset();
    setNotice("");
  }

  function removeFile(index: number) {
    setFiles((current) => current.filter((_, itemIndex) => itemIndex !== index));
    clearRecognizedDataset();
  }

  function removeEventFile(index: number) {
    setEventFiles((current) => current.filter((_, itemIndex) => itemIndex !== index));
    clearRecognizedDataset();
  }

  async function createTask(dataset: Dataset) {
    setLoadingMode("analysis");
    const taskRes = await fetch("/api/analysis", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ datasetId: dataset.id })
    });
    if (!taskRes.ok) throw new Error("分析任务创建失败");
    const { task } = await taskRes.json();
    clearLegacyTaskCache();
    router.push(`/analysis/${task.id}`);
  }

  async function submitUpload() {
    try {
      setLoadingMode("upload");
      setNotice("");
      const form = new FormData();
      files.forEach((file) => {
        const lower = file.name.toLowerCase();
        const shouldSample = file.size > LARGE_FILE_BYTES && (lower.endsWith(".csv") || lower.endsWith(".txt"));
        const uploadFile = shouldSample ? file.slice(0, LARGE_FILE_BYTES, file.type || "text/csv") : file;
        form.append("files", uploadFile, file.name);
        if (shouldSample) form.append("sampled", "true");
      });
      eventFiles.forEach((file) => form.append("eventMaterialFiles", file, file.name));
      if (eventMaterial.trim()) form.append("eventMaterial", eventMaterial);
      form.append("name", files.length > 1 ? `多来源数据集（${files.length} 个文件）` : files[0]?.name || "评论数据集");

      const res = await fetch("/api/upload", { method: "POST", body: form });
      if (!res.ok) {
        let message = "上传解析失败";
        try {
          const body = await res.json();
          message = body?.error || message;
        } catch {
          message = await res.text().catch(() => message);
        }
        throw new Error(message);
      }
      const { dataset, meta } = await res.json();
      setPendingDataset(dataset);
      setFieldMapping(meta?.fieldMapping || dataset.fieldMapping);
      setSourceFiles(meta?.sourceFiles || dataset.sourceFiles || []);
      const fileErrorText = meta?.fileErrors?.length
        ? ` 已跳过 ${meta.fileErrors.length} 个文件：${meta.fileErrors.slice(0, 3).map((item: { name: string; reason: string }) => `${item.name}（${item.reason}）`).join("；")}${meta.fileErrors.length > 3 ? " 等" : ""}。`
        : "";
      setNotice(`${meta?.eventMaterialWarning ? `${meta.eventMaterialWarning} 评论数据已继续解析。` : "数据已解析完成，"}当前纳入 ${meta?.recordsParsed || dataset.records.length} 条文本。${fileErrorText}请确认字段映射后开始分析。`);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "上传失败，请检查文件格式。");
    } finally {
      setLoadingMode(null);
    }
  }

  async function useDemo() {
    try {
      setLoadingMode("demo");
      const res = await fetch("/api/demo-dataset", { method: "POST" });
      if (!res.ok) throw new Error("示例数据创建失败");
      const { dataset } = await res.json();
      await createTask(dataset);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "示例数据创建失败");
      setLoadingMode(null);
    }
  }

  async function confirmAndAnalyze() {
    if (!pendingDataset) return;
    try {
      await createTask(pendingDataset);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "分析任务创建失败");
      setLoadingMode(null);
    }
  }

  return (
    <main className="min-h-screen px-5 py-6 lg:px-8">
      <Background />
      <div className="mx-auto max-w-7xl">
        <header className="mb-7 flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.28em] text-cyan">Upload Center</p>
            <h1 className="mt-2 text-4xl font-semibold tracking-[-0.01em] text-foreground">数据上传中心</h1>
            <p className="mt-3 max-w-2xl leading-7 text-muted">
              上传评论数据，并补充事件材料。事件材料只用于事件梳理与报告开头，不会被当作评论参与情感分析。
            </p>
          </div>
          <Button variant="ghost" onClick={() => router.push("/")}>
            <Home className="h-4 w-4" />
            返回首页
          </Button>
        </header>

        <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_380px]">
          <div className="space-y-5">
            <Panel className="relative overflow-hidden p-0">
              <div className="border-b border-slate-200/70 bg-white/62 px-5 py-4">
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan/10 text-cyan">
                    <UploadCloud className="h-5 w-5" />
                  </span>
                  <div>
                    <h2 className="text-xl font-semibold">选择数据来源</h2>
                    <p className="text-sm text-muted">支持 CSV、TXT、XLSX、XLS，可重复选择不同文件夹中的文件。</p>
                  </div>
                </div>
              </div>

              <div className="grid gap-5 p-5 lg:grid-cols-[0.9fr_1.1fr]">
                <div
                  className="relative flex min-h-[260px] cursor-pointer flex-col justify-between rounded-lg border border-dashed border-cyan/35 bg-cyan/[0.045] p-5 transition hover:bg-cyan/[0.07]"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <span className="absolute inset-x-5 top-5 h-px bg-cyan/18" />
                  <ScanLine className="h-9 w-9 text-cyan" />
                  <div>
                    <p className="text-lg font-semibold">
                      {files.length ? `已选择 ${files.length} 个文件` : "点击选择一个或多个评论数据文件"}
                    </p>
                    <p className="mt-2 text-sm leading-6 text-muted">
                      {files.length ? `合计大小：${formatFileSize(totalFileSize)}` : "可多次点击添加不同文件夹中的文件。"}
                    </p>
                    {files.length > 0 && (
                      <div className="mt-4 max-h-36 space-y-2 overflow-auto pr-1 text-left">
                        {files.map((item, index) => (
                          <div key={fileKey(item)} className="flex items-center justify-between gap-2 rounded-md bg-white/70 px-3 py-2 text-xs text-muted">
                            <div className="min-w-0">
                              <span className="block truncate font-medium text-foreground">{item.name}</span>
                              <span>{formatFileSize(item.size)}</span>
                            </div>
                            <button
                              type="button"
                              aria-label={`移除 ${item.name}`}
                              className="rounded-md p-1 text-muted transition hover:bg-slate-100 hover:text-foreground"
                              onClick={(event) => {
                                event.stopPropagation();
                                removeFile(index);
                              }}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    className="hidden"
                    accept=".csv,.txt,.xlsx,.xls"
                    onChange={(event) => {
                      addSelectedFiles(event.target.files);
                      event.currentTarget.value = "";
                    }}
                  />
                </div>

                <div>
                  <div className="mb-3 flex items-center gap-2 text-sm font-medium text-foreground">
                    <FileText className="h-4 w-4 text-cyan" />
                    事件材料
                  </div>
                  <div className="mb-3 rounded-lg border border-cyan/20 bg-cyan/[0.045] p-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <button
                        type="button"
                        className="inline-flex items-center gap-2 rounded-md border border-cyan/25 bg-white/70 px-3 py-2 text-sm font-medium text-cyan transition hover:bg-cyan/10"
                        onClick={() => eventFileInputRef.current?.click()}
                      >
                        <UploadCloud className="h-4 w-4" />
                        上传 TXT / DOCX
                      </button>
                      {eventFiles.length > 0 && (
                        <button
                          type="button"
                          className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs text-muted transition hover:bg-white/70 hover:text-foreground"
                          onClick={() => {
                            setEventFiles([]);
                            clearRecognizedDataset();
                          }}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          清空
                        </button>
                      )}
                    </div>
                    {eventFiles.length > 0 && (
                      <div className="mt-3 max-h-24 space-y-2 overflow-auto pr-1">
                        {eventFiles.map((item, index) => (
                          <div key={fileKey(item)} className="flex items-center justify-between gap-2 rounded-md bg-white/72 px-3 py-2 text-xs text-muted">
                            <span className="block truncate font-medium text-foreground">{item.name}</span>
                            <button type="button" className="rounded-md p-1 text-muted hover:bg-slate-100" onClick={() => removeEventFile(index)}>
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                    <input
                      ref={eventFileInputRef}
                      type="file"
                      multiple
                      className="hidden"
                      accept=".txt,.docx"
                      onChange={(event) => {
                        addEventFiles(event.target.files);
                        event.currentTarget.value = "";
                      }}
                    />
                  </div>
                  <textarea
                    value={eventMaterial}
                    onChange={(event) => {
                      setEventMaterial(event.target.value);
                      clearRecognizedDataset();
                    }}
                    placeholder="请粘贴事件背景材料，例如新闻正文、微博原帖、官方公告或事件说明。系统将自动提取事件名称、涉事主体、时间、核心争议和传播关键词。"
                    className="min-h-[228px] w-full rounded-lg border border-slate-200/80 bg-white/74 p-4 text-sm leading-6 text-foreground outline-none ring-cyan/20 placeholder:text-muted focus:ring-2"
                  />
                </div>
              </div>

              {isLargeFile && (
                <div className="mx-5 mb-5 rounded-lg border border-warning/30 bg-warning/10 p-3 text-sm leading-6 text-slate-700">
                  大文件会优先用于快速网页分析。后续全量分析更适合接入数据库或离线任务。
                </div>
              )}

              {notice && (
                <div className="mx-5 mb-5 flex items-start gap-3 rounded-lg border border-cyan/20 bg-cyan/10 p-3 text-sm leading-6 text-cyan">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
                  <span>{notice}</span>
                </div>
              )}

              {loadingMode && <LoadingPanel mode={loadingMode} fileCount={files.length} totalSize={totalFileSize} elapsedSeconds={loadingSeconds} />}

              <div className="flex flex-wrap gap-3 border-t border-slate-200/70 bg-white/50 px-5 py-4">
                <Button loading={Boolean(loadingMode)} disabled={!files.length || Boolean(loadingMode)} onClick={submitUpload}>
                  上传并识别字段
                  <ArrowRight className="h-4 w-4" />
                </Button>
                {pendingDataset && (
                  <Button loading={loadingMode === "analysis"} disabled={Boolean(loadingMode)} onClick={confirmAndAnalyze}>
                    确认并开始分析
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                )}
                {files.length > 0 && (
                  <Button
                    variant="ghost"
                    type="button"
                    onClick={() => {
                      setFiles([]);
                      clearRecognizedDataset();
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                    清空
                  </Button>
                )}
                <Button variant="secondary" loading={loadingMode === "demo"} disabled={Boolean(loadingMode)} onClick={useDemo}>
                  使用示例数据
                </Button>
              </div>
            </Panel>

          </div>

          <aside className="space-y-5 lg:sticky lg:top-6 lg:self-start">
            <FieldMappingPanel mapping={fieldMapping} dataset={pendingDataset} sourceFiles={sourceFiles} />
            <FormatGuide />
          </aside>
        </div>
      </div>
    </main>
  );
}

function FieldMappingPanel({
  mapping,
  dataset,
  sourceFiles
}: {
  mapping: FieldMapping | null;
  dataset: Dataset | null;
  sourceFiles: DatasetSourceFile[];
}) {
  return (
    <Panel>
      <div className="mb-4 flex items-center gap-3">
        <Database className="h-5 w-5 text-cyan" />
        <h2 className="text-lg font-semibold">字段识别</h2>
      </div>
      {mapping ? (
        <div className="space-y-3 text-sm">
          <FieldRow label="评论内容字段" value={mapLabel(mapping.textField)} />
          <FieldRow label="发布时间字段" value={mapLabel(mapping.timeField)} />
          <FieldRow label="评分字段" value={mapLabel(mapping.ratingField)} />
          <FieldRow label="点赞字段" value={mapLabel(mapping.likeField)} />
          <FieldRow label="用户字段" value={mapLabel(mapping.userField)} />
          <FieldRow label="分析对象字段" value={mapLabel(mapping.objectField)} />
          <FieldRow label="平台字段" value={mapLabel(mapping.platformField || mapping.staticPlatform)} />
          {dataset && <p className="pt-2 text-xs leading-6 text-muted">当前数据集：{dataset.records.length} 条文本</p>}
          {sourceFiles.length > 0 && (
            <div className="border-t border-slate-200/70 pt-3">
              <p className="mb-2 text-xs font-medium uppercase tracking-[0.18em] text-muted">来源文件</p>
              <div className="space-y-2">
                {sourceFiles.slice(0, 6).map((file) => (
                  <div key={file.id} className="rounded-md bg-white/62 p-2 text-xs text-muted">
                    <span className="block truncate font-medium text-foreground">{file.name}</span>
                    <span>{file.recordsIncluded} / {file.recordsParsed} 条</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <p className="text-sm leading-6 text-muted">上传数据后，系统会在这里展示识别到的字段映射。</p>
      )}
    </Panel>
  );
}

function FieldRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-md border border-slate-200/70 bg-white/62 px-3 py-2">
      <span className="text-muted">{label}</span>
      <span className="max-w-[180px] truncate font-medium text-foreground">{value}</span>
    </div>
  );
}

function FormatGuide() {
  return (
    <Panel>
      <div className="mb-4 flex items-center gap-3">
        <FileText className="h-5 w-5 text-cyan" />
        <h2 className="text-lg font-semibold">数据格式说明</h2>
      </div>
      <div className="space-y-3 text-sm leading-6 text-muted">
        <p>支持上传 CSV、TXT、XLSX、XLS 文件；Excel 文件会读取第一个工作表。</p>
        <p>评论数据建议包含：内容、发布时间、平台、用户、点赞数等字段。</p>
        <p>如果没有平台字段，系统不会强行生成平台来源，会切换为单对象或通用评论分析模式。</p>
        <p>事件材料用于解释事件背景和报告摘要，不参与评论情感统计。</p>
      </div>
    </Panel>
  );
}
