import type { Metadata } from "next";
import { SiteFooter } from "@/components/SiteFooter";
import "./globals.css";

export const metadata: Metadata = {
  title: "Public Sentiment Mirror",
  description: "网络舆情检索与智能分析平台"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-CN" className="dark">
      <body className="tech-shell antialiased">
        {children}
        <SiteFooter />
      </body>
    </html>
  );
}

