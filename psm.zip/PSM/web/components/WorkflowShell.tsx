"use client";

import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/utils";
import { ArrowLeft, ChevronLeft, ChevronRight, Home, Sparkles } from "lucide-react";
import Link from "next/link";

export const steps = [
  "事件与数据概览",
  "数据清洗",
  "关键词分析",
  "情感分析",
  "主题聚类",
  "热度趋势",
  "事件时间轴",
  "综合仪表盘",
  "分析报告"
];

export function WorkflowShell({
  current,
  setCurrent,
  children
}: {
  current: number;
  setCurrent: (value: number) => void;
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen px-4 py-5 lg:px-7">
      <header className="mx-auto mb-5 flex max-w-7xl items-center justify-between gap-3 rounded-lg border border-slate-200/70 bg-white/78 px-4 py-3 shadow-violet backdrop-blur">
        <Link href="/" className="group flex min-w-0 items-center gap-3 rounded-lg px-2 py-1 transition hover:bg-cyan/10">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-cyan text-white shadow-glow">
            <Home className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <p className="truncate text-xs font-medium uppercase tracking-[0.2em] text-cyan">Public Sentiment Mirror</p>
            <h1 className="truncate text-base font-semibold text-foreground group-hover:text-cyan">流程式分析工作台</h1>
          </div>
        </Link>

        <div className="hidden items-center gap-2 rounded-lg border border-cyan/20 bg-cyan/10 px-3 py-2 text-sm text-cyan sm:inline-flex">
          <Sparkles className="h-4 w-4" />
          {steps[current]}
        </div>
      </header>

      <div className="mx-auto grid max-w-7xl gap-5 lg:grid-cols-[260px_minmax(0,1fr)]">
        <aside className="lg:sticky lg:top-5 lg:self-start">
          <div className="surface-panel overflow-hidden p-3">
            <div className="px-2 pb-3 pt-1">
              <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted">Analysis steps</p>
              <p className="mt-2 text-sm leading-6 text-muted">点击步骤可直接跳转，底部按钮用于顺序复现工作流。</p>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-1 lg:block lg:space-y-1 lg:overflow-visible">
              {steps.map((step, index) => (
                <button
                  key={step}
                  onClick={() => setCurrent(index)}
                  className={cn(
                    "grid min-w-[150px] grid-cols-[28px_1fr] items-center gap-2 rounded-lg px-3 py-2.5 text-left text-sm transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan/35 lg:min-w-0",
                    current === index
                      ? "bg-cyan text-white shadow-glow"
                      : "text-muted hover:bg-white/76 hover:text-foreground"
                  )}
                >
                  <span
                    className={cn(
                      "flex h-7 w-7 items-center justify-center rounded-md text-xs font-semibold",
                      current === index ? "bg-white/18 text-white" : "bg-white/68 text-cyan"
                    )}
                  >
                    {index + 1}
                  </span>
                  <span className="truncate">{step}</span>
                </button>
              ))}
            </div>
          </div>
        </aside>

        <main className="min-w-0">
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
            <button onClick={() => setCurrent(0)} className="inline-flex items-center gap-2 text-sm text-muted transition hover:text-cyan">
              <ArrowLeft className="h-4 w-4" />
              回到第一步
            </button>
            <div className="inline-flex items-center gap-2 rounded-lg border border-slate-200/70 bg-white/72 px-3 py-2 text-sm text-muted">
              <span className="font-medium text-foreground">{current + 1}</span>
              <span>/</span>
              <span>{steps.length}</span>
            </div>
          </div>

          {children}

          <div className="mt-6 flex items-center justify-between border-t border-slate-200/70 pt-5">
            <Button variant="secondary" disabled={current === 0} onClick={() => setCurrent(Math.max(0, current - 1))}>
              <ChevronLeft className="h-4 w-4" />
              上一步
            </Button>
            <Button disabled={current === steps.length - 1} onClick={() => setCurrent(Math.min(steps.length - 1, current + 1))}>
              下一步
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </main>
      </div>
    </div>
  );
}
