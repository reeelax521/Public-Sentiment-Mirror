"use client";

import type { TimelineNode, TrendPoint } from "@/lib/types";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  LabelList,
  Legend,
  Line,
  Pie,
  PieChart,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Scatter,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";

const palette = ["#13B6D1", "#6C7CFF", "#A56EFF", "#2EC98F", "#F6B84B", "#FF6B87"];
const grid = "rgba(53, 92, 135, .18)";
const axis = "#5A708D";

type TooltipPayload = Array<{
  name?: string;
  value?: string | number;
  color?: string;
  dataKey?: string;
  payload?: Record<string, unknown>;
}>;

function cleanName(name?: string, dataKey?: string) {
  const value = name || dataKey || "";
  return ({
    count: "数量",
    heat: "热度指数",
    comments: "文本量",
    interactions: "互动量",
    likes: "点赞量",
    negativeRate: "负面率",
    movingAverage: "移动平均",
    commentIndex: "评论量指数",
    eventHeat: "事件节点",
    value: "数值",
    size: "主题规模"
  } as Record<string, string>)[value] || value;
}

function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: TooltipPayload; label?: string }) {
  const rows = (payload || []).filter((item) => item.value !== undefined && item.value !== null && item.value !== "");
  if (!active || rows.length === 0) return null;
  const event = rows.find((item) => item.payload?.stage)?.payload;
  const title = String(event?.stage || label || rows[0]?.payload?.platform || rows[0]?.payload?.name || rows[0]?.payload?.word || "");
  const eventSummary = typeof event?.summary === "string" ? event.summary : "";

  return (
    <div className="rounded-lg border border-cyan/25 bg-white/95 px-3 py-2 text-sm text-slate-800 shadow-xl backdrop-blur">
      {title && <p className="font-semibold text-slate-950">{title}</p>}
      {eventSummary && <p className="mt-1 max-w-xs text-xs leading-5 text-slate-600">{eventSummary}</p>}
      <div className="mt-2 space-y-1">
        {rows.map((item, index) => (
          <div key={`${item.dataKey}-${index}`} className="flex items-center justify-between gap-5">
            <span className="flex items-center gap-2 text-slate-600">
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: item.color || "#13B6D1" }} />
              {cleanName(item.name, item.dataKey)}
            </span>
            <span className="font-medium text-slate-950">{String(item.value)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function KeywordBar({ data, height = 360 }: { data: Array<{ word: string; count: number }>; height?: number }) {
  const rows = data.slice(0, 20);
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={rows} layout="vertical" margin={{ top: 12, right: 24, bottom: 12, left: 18 }}>
        <CartesianGrid stroke={grid} strokeDasharray="4 6" vertical={false} />
        <XAxis type="number" stroke={axis} fontSize={12} />
        <YAxis
          type="category"
          dataKey="word"
          stroke={axis}
          fontSize={12}
          width={130}
          tickLine={false}
          interval={0}
        />
        <Tooltip content={<ChartTooltip />} cursor={{ fill: "rgba(19, 182, 209, .08)" }} />
        <Bar dataKey="count" radius={[0, 7, 7, 0]} fill="#13B6D1" />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function SentimentDonut({ data }: { data: Array<{ name: string; value: number }> }) {
  const total = data.reduce((sum, item) => sum + item.value, 0) || 1;
  return (
    <ResponsiveContainer width="100%" height={270}>
      <PieChart>
        <Pie
          data={data}
          dataKey="value"
          nameKey="name"
          innerRadius={58}
          outerRadius={88}
          paddingAngle={4}
          label={(props: { name?: string; value?: number }) => `${props.name || ""} ${Math.round(((props.value || 0) / total) * 100)}%`}
          labelLine={false}
          isAnimationActive={false}
        >
          {data.map((_, index) => <Cell key={index} fill={palette[index]} />)}
        </Pie>
        <Tooltip content={<ChartTooltip />} />
        <Legend formatter={(value, entry) => <span className="text-sm text-slate-600">{value} {String((entry as { payload?: { value?: number } }).payload?.value ?? "")}%</span>} />
      </PieChart>
    </ResponsiveContainer>
  );
}

export function TrendLine<T extends { date: string; heat?: number; comments?: number }>({ data }: { data: T[] }) {
  return (
    <ResponsiveContainer width="100%" height={310}>
      <AreaChart data={data} margin={{ top: 14, right: 12, bottom: 8, left: 0 }}>
        <defs>
          <linearGradient id="heat" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#13B6D1" stopOpacity={0.42} />
            <stop offset="100%" stopColor="#13B6D1" stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke={grid} strokeDasharray="4 6" vertical={false} />
        <XAxis dataKey="date" stroke={axis} fontSize={12} />
        <YAxis stroke={axis} fontSize={12} />
        <Tooltip content={<ChartTooltip />} />
        <Area type="monotone" dataKey="heat" stroke="#13B6D1" fill="url(#heat)" strokeWidth={3} />
        <Line type="monotone" dataKey="comments" stroke="#A56EFF" strokeWidth={2.5} dot={false} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function EventTrendTimeline({ trend, timeline }: { trend: TrendPoint[]; timeline: TimelineNode[] }) {
  const maxComments = Math.max(...trend.map((point) => point.comments), 1);
  const eventMap = new Map(timeline.map((node) => [node.time, node]));
  const data = trend.map((point) => ({
    ...point,
    commentIndex: Math.round((point.comments / maxComments) * 100),
    eventHeat: eventMap.get(point.date)?.heat ?? null,
    stage: eventMap.get(point.date)?.stage,
    summary: eventMap.get(point.date)?.summary,
    risk: eventMap.get(point.date)?.risk
  }));

  return (
    <ResponsiveContainer width="100%" height={360}>
      <ComposedChart data={data} margin={{ top: 28, right: 22, bottom: 28, left: 4 }}>
        <defs>
          <linearGradient id="eventHeat" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#6C7CFF" stopOpacity={0.34} />
            <stop offset="100%" stopColor="#6C7CFF" stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke={grid} strokeDasharray="4 6" vertical={false} />
        <XAxis
          dataKey="date"
          stroke={axis}
          fontSize={12}
          label={{ value: "时间", position: "insideBottom", offset: -14, fill: axis, fontSize: 12 }}
        />
        <YAxis
          stroke={axis}
          fontSize={12}
          domain={[0, 100]}
          label={{ value: "指数 0-100", angle: -90, position: "insideLeft", fill: axis, fontSize: 12 }}
        />
        <Tooltip content={<ChartTooltip />} />
        <Legend />
        <Area type="monotone" dataKey="heat" name="热度指数" stroke="#6C7CFF" fill="url(#eventHeat)" strokeWidth={3} />
        <Line type="monotone" dataKey="commentIndex" name="评论量指数" stroke="#13B6D1" strokeWidth={2} dot={false} />
        <Scatter dataKey="eventHeat" name="事件节点" fill="#FF6B87">
          <LabelList dataKey="stage" position="top" className="fill-slate-700 text-[11px]" />
        </Scatter>
      </ComposedChart>
    </ResponsiveContainer>
  );
}

export function PlatformPie({ data }: { data: Array<{ platform: string; count: number }> }) {
  const total = data.reduce((sum, item) => sum + item.count, 0) || 1;
  return (
    <div>
      <ResponsiveContainer width="100%" height={260}>
        <PieChart>
          <Pie
            data={data}
            dataKey="count"
            nameKey="platform"
            outerRadius={92}
            label={(props: { platform?: string; count?: number; name?: string; value?: number }) => `${props.platform || props.name} ${props.count || props.value}`}
            labelLine={false}
          >
            {data.map((_, index) => <Cell key={index} fill={palette[index % palette.length]} />)}
          </Pie>
          <Tooltip content={<ChartTooltip />} />
        </PieChart>
      </ResponsiveContainer>
      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        {data.map((item, index) => (
          <div key={item.platform} className="flex items-center justify-between rounded-lg border border-slate-200/70 bg-white/60 px-3 py-2 text-sm">
            <span className="flex items-center gap-2 text-slate-700">
              <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: palette[index % palette.length] }} />
              {item.platform}
            </span>
            <span className="font-medium text-slate-950">{item.count} 条 · {Math.round((item.count / total) * 100)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function RiskRadar({ data }: { data: Array<{ metric: string; value: number }> }) {
  return (
    <ResponsiveContainer width="100%" height={290}>
      <RadarChart data={data}>
        <PolarGrid stroke={grid} />
        <PolarAngleAxis dataKey="metric" stroke={axis} fontSize={12} />
        <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fontSize: 10, fill: axis }} />
        <Radar dataKey="value" stroke="#13B6D1" fill="#13B6D1" fillOpacity={0.2} />
        <Tooltip content={<ChartTooltip />} />
      </RadarChart>
    </ResponsiveContainer>
  );
}
