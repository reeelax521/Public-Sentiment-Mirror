import Image from "next/image";

const icpRecordNumber = process.env.NEXT_PUBLIC_ICP_RECORD_NUMBER?.trim();
const policeRecordNumber = process.env.NEXT_PUBLIC_POLICE_RECORD_NUMBER?.trim();
const policeRecordUrl = process.env.NEXT_PUBLIC_POLICE_RECORD_URL?.trim();

export function SiteFooter() {
  if (!icpRecordNumber && !policeRecordNumber) {
    return null;
  }

  return (
    <footer className="relative border-t border-slate-200/70 bg-white/58 px-5 py-5 text-center text-xs text-muted backdrop-blur lg:px-8">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-5 gap-y-2">
        {icpRecordNumber ? (
          <a
            href="https://beian.miit.gov.cn/"
            target="_blank"
            rel="noreferrer"
            className="transition hover:text-cyan focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan/35"
          >
            {icpRecordNumber}
          </a>
        ) : null}

        {policeRecordNumber ? (
          <a
            href={policeRecordUrl || "https://beian.mps.gov.cn/"}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 transition hover:text-cyan focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan/35"
          >
            <Image src="/beian.png" alt="" width={20} height={20} aria-hidden />
            {policeRecordNumber}
          </a>
        ) : null}
      </div>
    </footer>
  );
}
