export function Background() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 tech-shell" />
      <div className="absolute inset-0 grid-overlay" />
      <div className="absolute inset-x-0 top-0 h-72 bg-gradient-to-b from-cyan/14 via-indigo/8 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-56 bg-gradient-to-t from-violet/10 to-transparent" />
    </div>
  );
}

