"use client";

import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";
import type { ButtonHTMLAttributes } from "react";

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost";
  loading?: boolean;
}

export function Button({ className, variant = "primary", loading, children, ...props }: Props) {
  return (
    <button
      className={cn(
        "inline-flex h-11 items-center justify-center gap-2 rounded-lg px-5 text-sm font-medium transition duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan/35 disabled:cursor-not-allowed disabled:opacity-55",
        variant === "primary" && "bg-cyan text-white shadow-glow hover:bg-cyan/90 active:bg-cyan/80",
        variant === "secondary" && "border border-cyan/25 bg-white/78 text-foreground hover:border-cyan/45 hover:bg-white active:bg-slate-50",
        variant === "ghost" && "text-muted hover:bg-white/70 hover:text-foreground active:bg-white",
        className
      )}
      {...props}
    >
      {loading && <Loader2 className="h-4 w-4 animate-spin" />}
      {children}
    </button>
  );
}

