import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

export function Panel({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("surface-panel p-5", className)} {...props} />;
}

export function MetricCard({ label, value, sub }: { label: string; value: string | number; sub?: string }) {
  return (
    <Panel className="min-h-[132px]">
      <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">{label}</p>
      <div className="mt-3 text-3xl font-semibold leading-none text-foreground">{value}</div>
      {sub && <p className="mt-3 text-sm leading-6 text-muted">{sub}</p>}
    </Panel>
  );
}

