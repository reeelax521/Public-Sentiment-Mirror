import type { KeywordItem } from "@/lib/types";

const slots = [
  { x: 506, y: 205, scale: 1.14, rotate: 0 },
  { x: 376, y: 194, scale: 0.86, rotate: -7 },
  { x: 633, y: 196, scale: 0.78, rotate: 4 },
  { x: 505, y: 264, scale: 0.68, rotate: 0 },
  { x: 382, y: 254, scale: 0.5, rotate: -3 },
  { x: 625, y: 258, scale: 0.48, rotate: 5 },
  { x: 505, y: 145, scale: 0.46, rotate: 0 },
  { x: 292, y: 215, scale: 0.42, rotate: -8 },
  { x: 725, y: 220, scale: 0.4, rotate: 7 },
  { x: 330, y: 138, scale: 0.36, rotate: 6 },
  { x: 675, y: 138, scale: 0.36, rotate: -6 },
  { x: 420, y: 316, scale: 0.35, rotate: 4 },
  { x: 585, y: 318, scale: 0.35, rotate: -4 },
  { x: 250, y: 274, scale: 0.32, rotate: 7 },
  { x: 755, y: 278, scale: 0.32, rotate: -7 },
  { x: 245, y: 158, scale: 0.3, rotate: -4 },
  { x: 760, y: 158, scale: 0.3, rotate: 5 },
  { x: 455, y: 100, scale: 0.29, rotate: -5 },
  { x: 555, y: 102, scale: 0.29, rotate: 5 },
  { x: 320, y: 330, scale: 0.28, rotate: -5 },
  { x: 688, y: 333, scale: 0.28, rotate: 5 },
  { x: 185, y: 218, scale: 0.26, rotate: -7 },
  { x: 820, y: 220, scale: 0.26, rotate: 7 }
];

const palette = ["#13B6D1", "#6674F5", "#2DBE8F", "#0F7490", "#8B6EF2"];

function fittedSize(item: KeywordItem, maxCount: number, scale: number) {
  const frequency = Math.pow(item.count / Math.max(maxCount, 1), 0.54);
  const lengthPenalty = item.word.length > 5 ? Math.max(0.72, 1 - (item.word.length - 5) * 0.045) : 1;
  return Math.max(15, Math.round((22 + frequency * 46) * scale * lengthPenalty));
}

export function WordCloud({ words }: { words: KeywordItem[] }) {
  const items = words.slice(0, slots.length);
  const maxCount = Math.max(...items.map((item) => item.count), 1);

  return (
    <svg
      role="img"
      aria-label="高频词云"
      className="block h-[320px] w-full"
      viewBox="0 0 1000 390"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <radialGradient id="word-cloud-bg-main" cx="50%" cy="50%" r="55%">
          <stop offset="0%" stopColor="#D8F8FA" stopOpacity="0.78" />
          <stop offset="52%" stopColor="#D8F8FA" stopOpacity="0.34" />
          <stop offset="100%" stopColor="#D8F8FA" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="word-cloud-bg-cool" cx="50%" cy="50%" r="55%">
          <stop offset="0%" stopColor="#DDE4FF" stopOpacity="0.52" />
          <stop offset="70%" stopColor="#DDE4FF" stopOpacity="0.16" />
          <stop offset="100%" stopColor="#DDE4FF" stopOpacity="0" />
        </radialGradient>
        <filter id="word-cloud-soften" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="18" />
        </filter>
      </defs>

      <rect x="14" y="14" width="972" height="362" rx="22" fill="#F7FDFF" stroke="#BDECF4" />
      <ellipse cx="500" cy="202" rx="360" ry="132" fill="url(#word-cloud-bg-main)" filter="url(#word-cloud-soften)" />
      <ellipse cx="512" cy="205" rx="245" ry="86" fill="url(#word-cloud-bg-cool)" filter="url(#word-cloud-soften)" />
      <ellipse cx="500" cy="204" rx="300" ry="112" fill="#DFF8FA" opacity="0.16" />

      {items.map((item, index) => {
        const slot = slots[index];
        const size = fittedSize(item, maxCount, slot.scale);
        const color = palette[index % palette.length];
        const opacity = index < 5 ? 0.98 : 0.78;

        return (
          <g key={`${item.word}-${index}`} transform={`translate(${slot.x} ${slot.y}) rotate(${slot.rotate})`}>
            <animateTransform
              attributeName="transform"
              type="scale"
              values="1;1.025;1"
              dur={`${5.6 + (index % 5) * 0.35}s`}
              begin={`${-(index % 6) * 0.28}s`}
              repeatCount="indefinite"
              additive="sum"
            />
            <text
              textAnchor="middle"
              dominantBaseline="middle"
              fontFamily="Microsoft YaHei, PingFang SC, Arial, sans-serif"
              fontSize={size}
              fontWeight={index < 5 ? 760 : 650}
              fill={color}
              opacity={opacity}
              style={{ paintOrder: "stroke", stroke: "rgba(247,253,255,.76)", strokeWidth: index < 5 ? 5 : 3 }}
            >
              {item.word}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
