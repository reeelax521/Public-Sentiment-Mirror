# Public Sentiment Mirror Literature Notes

These notes map the project methodology to the productized Next.js implementation.

## 1. Public Opinion Analysis Should Combine Emotion, Topics, and Time

Related literature:
- Xu Tan et al., *An Analysis of the Emotional Evolution of Large-Scale Internet Public Opinion Events Based on the BERT-LDA Hybrid Model*
- Wang Shihang and Tang Yanjun, research on sentiment classification and topic mining for online public opinion text

Implementation:
- Time trend: `web/lib/analysis/trend.ts`
- Event timeline: `web/lib/analysis/timeline.ts`
- Sentiment: `web/lib/analysis/sentiment.ts`
- Workflow page: `web/app/analysis/[taskId]/page.tsx`

## 2. Keywords, TF-IDF Style Signals, and Clustering Support Topic Discovery

Related literature:
- David M. Blei, Andrew Y. Ng, Michael I. Jordan, *Latent Dirichlet Allocation*
- Social media and tourism text-mining studies using frequency, TF-IDF, and clustering methods

Implementation:
- Keyword extraction: `web/lib/analysis/keywords.ts`
- Lexicon extraction: `web/lib/analysis/lexicon.ts`
- Topic and cluster fallback logic: `web/lib/analysis/index.ts`
- Topic enrichment: `web/lib/analysis/event.ts`

## 3. SBERT and BERTopic Are Optional Semantic Enhancements

Related literature:
- Maarten Grootendorst, *BERTopic: Neural topic modeling with a class-based TF-IDF procedure*
- Nils Reimers and Iryna Gurevych, *Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks*

Implementation:
- Optional standalone NLP service: `nlp_service/`
- Web fallback when model service is unavailable: `web/lib/analysis/advancedModels.ts`

The product app remains usable without the model service.

## 4. Social Media Summaries Need Cleaning, Noise Handling, and Reports

Related literature:
- Freddy Chong Tat Chua and Sitaram Asur, *Automatic Summarization of Events from Social Media*

Implementation:
- File and text parsing: `web/lib/dataAdapter.ts`
- Cleaning: `web/lib/analysis/clean.ts`
- Report generation: `web/lib/analysis/report.ts`
- Report download: `web/lib/reportDownload.ts`

## 5. Risk Assessment Is an Auxiliary Signal, Not a Truth Judgment

Related literature:
- Rumor detection and uncertainty-expression research in social networks
- Group polarization and public crisis response research

Implementation:
- Risk dashboard: `web/lib/analysis/risk.ts`
- Event risk and recommendation layer: `web/lib/analysis/event.ts`
- Dashboard charts: `web/components/Charts.tsx`

The system reports text-based risk signals and uncertainty indicators. It does not claim to determine factual truth.

## 6. Current Productized Architecture

- Product UI: `web/app/`
- API routes: `web/app/api/`
- Analysis pipeline: `web/lib/analysis/`
- Shared types: `web/lib/types.ts`
- Runtime task store: `web/lib/store/memory.ts`
- Optional model service: `nlp_service/`
