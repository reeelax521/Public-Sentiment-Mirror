# Public Sentiment Mirror

Productized public sentiment analysis workspace built with Next.js.

## Current App

- Frontend and API gateway: `web/`
- Optional NLP service: `nlp_service/`
- Demo data: `data/sample/`
- Project docs: `docs/`

The legacy prototype has been removed. Use the Next.js app as the only runtime entry.

## Local Development

```powershell
cd web
npm install
npm run dev
```

Open:

```text
http://localhost:3000
```

## Production Build

```powershell
cd web
npm install
npm run build
npm run start -- -p 3000
```

## Optional Advanced Model Service

The web app can call the Python model service for SBERT / BERTopic / BERT-style analysis. If it is not running, the app falls back to local lightweight analysis.

```powershell
cd nlp_service
python -m venv .venv
.\.venv\Scripts\python -m pip install -r requirements.txt
.\.venv\Scripts\python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

Then start the web app with `NLP_SERVICE_URL=http://localhost:8000`.

## Main Routes

- `/`
- `/upload`
- `/analysis/[taskId]`
- `/api/upload`
- `/api/analysis`
- `/api/reports/generate`
