@echo off
cd /d E:\undergraduate\Web\PSM\web
echo Starting Public Sentiment Mirror Next.js app...
echo.
npm run dev
echo.
echo Next.js dev server has stopped. Press any key to close this window.
pause > nul
