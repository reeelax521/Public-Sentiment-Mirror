# Deploy Public Sentiment Mirror

This project is now deployed as a Next.js app. The old prototype deployment path has been removed.

## Render

Use the root `render.yaml`, or create a Web Service manually:

```text
Environment: Node
Build Command: cd web && npm ci && npm run build
Start Command: cd web && npm run start -- -p $PORT
```

## ECS / VPS

Install Node.js 20 or newer, then:

```bash
cd /opt/public-sentiment-mirror/web
npm ci
npm run build
npm run start -- -p 3000
```

For a background service, use:

```bash
sudo cp /opt/public-sentiment-mirror/web/deploy-next-systemd.service /etc/systemd/system/public-sentiment-mirror.service
sudo systemctl daemon-reload
sudo systemctl enable --now public-sentiment-mirror
```

For Nginx reverse proxy, use:

```bash
sudo cp /opt/public-sentiment-mirror/web/nginx-next.conf /etc/nginx/sites-available/publicsentimentmirror
sudo ln -s /etc/nginx/sites-available/publicsentimentmirror /etc/nginx/sites-enabled/publicsentimentmirror
sudo nginx -t
sudo systemctl reload nginx
```

## Optional Model Service

If you want advanced semantic analysis, deploy `nlp_service` separately and set:

```bash
NLP_SERVICE_URL=http://127.0.0.1:8000
```
