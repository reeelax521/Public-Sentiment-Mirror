from datetime import datetime

from schemas.request_schema import MetadataItem


def build_trend(metadata: list[MetadataItem], sentiment_items: list[dict]) -> list[dict]:
    if not metadata:
        return []
    rows: dict[str, dict[str, float | int | str]] = {}
    for index, meta in enumerate(metadata[:len(sentiment_items)]):
        date = meta.createdAt or ""
        try:
            date = datetime.fromisoformat(date.replace("Z", "+00:00")).date().isoformat()
        except Exception:
            date = str(date)[:10] if date else "unknown"
        row = rows.setdefault(date, {"date": date, "count": 0, "heat": 0.0, "negative": 0})
        row["count"] = int(row["count"]) + 1
        row["heat"] = float(row["heat"]) + 1 + meta.likeCount * 0.05 + meta.repostCount * 0.12 + meta.commentCount * 0.08
        if sentiment_items[index]["label"] == "negative":
            row["negative"] = int(row["negative"]) + 1

    trend = []
    max_heat = max((float(row["heat"]) for row in rows.values()), default=1.0)
    for row in sorted(rows.values(), key=lambda item: str(item["date"])):
        count = int(row["count"])
        trend.append({
            "date": str(row["date"]),
            "heat": round(float(row["heat"]) / max_heat * 100, 2),
            "count": count,
            "negativeRate": round(int(row["negative"]) / max(count, 1) * 100, 2),
        })
    return trend


def compute_risk(sentiment: dict, topics: list[dict], clusters: list[dict], metadata: list[MetadataItem]) -> dict:
    negative_rate = float(sentiment.get("negativeRate", 0))
    interactions = sum((m.likeCount + m.repostCount * 2 + m.commentCount) for m in metadata)
    heat_score = min(100.0, interactions / max(len(metadata), 1) / 10) if metadata else 20.0
    largest_topic = max((float(topic.get("percentage", 0)) for topic in topics), default=0.0)
    negative_topic_bonus = 0.0
    negative_words = {"失望", "质疑", "担心", "反对", "不满", "风险", "敷衍", "糟糕", "抄袭", "太贵", "丢人", "造假"}

    for topic in topics:
        keywords = set(topic.get("keywords", []))
        text = " ".join([str(topic.get("name", "")), *[str(item) for item in topic.get("representativeTexts", [])]])
        if keywords & negative_words or any(word in text for word in negative_words):
            negative_topic_bonus = max(negative_topic_bonus, float(topic.get("percentage", 0)))

    heat_multiplier = 1.0 if heat_score >= 70 else 0.72 if heat_score >= 38 else 0.48
    negative_topic_pressure = negative_topic_bonus if negative_topic_bonus >= 12 else 0.0
    score = min(100.0, negative_rate * 1.55 * heat_multiplier + negative_topic_pressure * 0.38 + largest_topic * 0.05)

    if score >= 78:
        level = "critical"
    elif score >= 60:
        level = "high"
    elif score >= 32:
        level = "medium"
    else:
        level = "low"

    topic_names = [str(topic.get("name", "")) for topic in topics[:2] if topic.get("name")]
    reason = f"负面情绪比例为 {negative_rate:.1f}%，传播热度只作为放大因子，不单独决定风险等级。主要讨论集中在{'、'.join(topic_names) or '核心话题'}。"
    if negative_topic_bonus:
        reason += " 部分高占比主题包含明显负面或质疑表达，需要优先关注。"
    else:
        reason += " 暂未发现单一高风险主题显著主导整体讨论。"

    return {"riskLevel": level, "riskScore": round(score, 2), "reason": reason}
