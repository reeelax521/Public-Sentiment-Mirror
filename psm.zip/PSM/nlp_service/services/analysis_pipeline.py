from schemas.request_schema import AnalyzeRequest
from services.cleaning_service import clean_texts
from services.clustering_service import run_kmeans_clustering
from services.embedding_service import encode_texts
from services.keyword_service import extract_keywords
from services.risk_service import build_trend, compute_risk
from services.sentiment_service import analyze_sentiment
from services.topic_service import run_bertopic


def _align_metadata(request: AnalyzeRequest, kept_indices: list[int]):
    metadata = request.metadata or []
    aligned = []
    for index in kept_indices:
        if index < len(metadata):
            aligned.append(metadata[index])
    return aligned


def analyze_payload(request: AnalyzeRequest) -> dict:
    warnings: list[str] = []
    cleaned = clean_texts(request.texts)
    metadata = _align_metadata(request, cleaned.kept_indices)

    keywords = extract_keywords(cleaned.texts)
    embeddings, embedding_mode = encode_texts(cleaned.texts)
    if embedding_mode == "fallback":
        warnings.append("SBERT 模型不可用，已使用基础聚类降级方案。")

    clusters = run_kmeans_clustering(cleaned.texts, embeddings)
    topics = run_bertopic(cleaned.texts, embeddings)
    if len(cleaned.texts) < 20 or embedding_mode == "fallback":
        warnings.append("BERTopic 未运行或已降级为主题摘要。")

    sentiment = analyze_sentiment(cleaned.texts)
    if sentiment.get("mode") == "fallback":
        warnings.append("情感模型不可用，已使用本地词典规则。")
    elif sentiment.get("mode") == "snownlp":
        warnings.append("情感分析已使用 SnowNLP 轻量模型。")

    trend = build_trend(metadata, sentiment.get("items", []))
    risk = compute_risk(sentiment, topics, clusters, metadata)

    return {
        "taskId": request.taskId,
        "overview": {
            "totalTexts": cleaned.total_texts,
            "validTexts": cleaned.valid_texts,
            "removedDuplicates": cleaned.removed_duplicates,
            "removedEmpty": cleaned.removed_empty,
        },
        "keywords": keywords,
        "sentiment": sentiment,
        "clusters": clusters,
        "topics": topics,
        "trend": trend,
        "risk": risk,
        "mode": "nlp" if embedding_mode != "fallback" or sentiment.get("mode") != "fallback" else "fallback",
        "warnings": warnings,
    }
