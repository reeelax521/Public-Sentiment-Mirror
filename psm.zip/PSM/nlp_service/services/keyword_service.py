from utils.text_utils import keyword_counts


def extract_keywords(texts: list[str], limit: int = 30) -> list[dict[str, int]]:
    return keyword_counts(texts, limit)
