from collections import defaultdict

import numpy as np

from utils.text_utils import safe_percentage, top_terms


POSITIVE_HINTS = {"支持", "期待", "认可", "喜欢", "满意", "祝贺", "恭喜", "成功", "开心", "自豪", "骄傲", "好消息", "点赞", "好看", "漂亮", "超级漂亮", "精致", "想买", "爆款", "抢手"}
NEGATIVE_HINTS = {"质疑", "担心", "风险", "不满", "反对", "失望", "争议", "无语", "丢人", "造假", "抄袭", "太贵", "翻译争议", "黄牛", "倒卖", "加价", "抢掉", "预约名额"}
REQUEST_HINTS = {"建议", "要求", "希望", "回应", "处理", "解释", "解决", "改进", "公开", "透明"}
FACT_HINTS = {"事件", "话题", "公告", "政策", "时间", "地点", "主体", "新闻"}
CULTURE_HINTS = {"春节", "申遗", "传统文化", "文化遗产", "非遗", "传承", "英歌舞", "中轴线", "民俗", "文化自信"}
PRODUCT_HEAT_HINTS = {"凤冠", "冰箱贴", "国博", "国家博物馆", "文创", "文创产品", "爆款", "销量", "热卖"}
PURCHASE_HINTS = {"购买", "消费", "淘宝", "没抢上", "抢不到", "想买", "到手", "售罄", "缺货"}
CONSUMER_HINTS = {"价格", "太贵", "质量", "商业化", "同质化", "性价比", "割韭菜", "不值"}
DIPLOMATIC_HINTS = {"外交", "访华", "中美", "合作", "会晤", "经贸", "谈判", "和平发展"}


def readable_label(terms: list[str], fallback: str = "综合讨论") -> str:
    text = " ".join(terms)
    if any(term in text for term in CULTURE_HINTS) and any(term in text for term in POSITIVE_HINTS):
        return "文化认同与传统传承"
    if any(term in text for term in CULTURE_HINTS):
        return "文化议题与事件认知"
    if any(term in text for term in PRODUCT_HEAT_HINTS):
        return "爆款文创与销售热度"
    if any(term in text for term in PURCHASE_HINTS):
        return "购买体验与爆款供需"
    if any(term in text for term in CONSUMER_HINTS):
        return "消费体验与商业化讨论"
    if any(term in text for term in DIPLOMATIC_HINTS):
        return "合作发展与外交议题"
    if any(term in text for term in NEGATIVE_HINTS):
        return "质疑争议与风险关注"
    if any(term in text for term in POSITIVE_HINTS):
        return "正向态度与认可表达"
    if any(term in text for term in REQUEST_HINTS):
        return "诉求建议与回应期待"
    if any(term in text for term in FACT_HINTS):
        return "事实信息与事件描述"
    if terms:
        return f"{terms[0]}相关讨论"
    return fallback


def cluster_count(n_texts: int) -> int:
    if n_texts < 10:
        return 1
    if n_texts < 100:
        return 3
    if n_texts < 500:
        return 5
    return 8


def fallback_clusters(texts: list[str]) -> list[dict]:
    if not texts:
        return []
    terms = top_terms(texts, 8)
    return [{
        "clusterId": 0,
        "label": readable_label(terms),
        "size": len(texts),
        "percentage": 100.0,
        "topTerms": terms,
        "representativeTexts": texts[:5],
        "coordinates": [{"x": float(i % 12), "y": float(i // 12), "clusterId": 0, "text": text[:100]} for i, text in enumerate(texts[:160])],
    }]


def _coordinates(embeddings: np.ndarray, labels: np.ndarray, texts: list[str]) -> list[dict]:
    if embeddings.size == 0:
        return []
    try:
        from sklearn.decomposition import PCA

        reduced = PCA(n_components=2, random_state=42).fit_transform(embeddings)
    except Exception:
        reduced = np.column_stack((np.arange(len(texts)), labels))
    return [
        {
            "x": float(round(row[0], 4)),
            "y": float(round(row[1], 4)),
            "clusterId": int(labels[index]),
            "text": texts[index][:100],
        }
        for index, row in enumerate(reduced[:260])
    ]


def run_kmeans_clustering(texts: list[str], embeddings: np.ndarray) -> list[dict]:
    if not texts:
        return []
    if len(texts) < 10 or embeddings.size == 0:
        return fallback_clusters(texts)

    try:
        from sklearn.cluster import KMeans

        k = min(cluster_count(len(texts)), len(texts))
        model = KMeans(n_clusters=k, random_state=42, n_init="auto")
        labels = model.fit_predict(embeddings)
        centers = model.cluster_centers_
        grouped: dict[int, list[int]] = defaultdict(list)
        for index, label in enumerate(labels):
            grouped[int(label)].append(index)

        coords = _coordinates(embeddings, labels, texts)
        results = []
        for label, indices in sorted(grouped.items(), key=lambda item: len(item[1]), reverse=True):
            cluster_texts = [texts[index] for index in indices]
            terms = top_terms(cluster_texts, 8)
            distances = np.linalg.norm(embeddings[indices] - centers[label], axis=1)
            representative = [cluster_texts[i] for i in np.argsort(distances)[:5]]
            results.append({
                "clusterId": int(label),
                "label": readable_label(terms, f"聚类 {label}"),
                "size": len(indices),
                "percentage": safe_percentage(len(indices), len(texts)),
                "topTerms": terms,
                "representativeTexts": representative,
                "coordinates": [point for point in coords if point["clusterId"] == label],
            })
        return results
    except Exception:
        return fallback_clusters(texts)
