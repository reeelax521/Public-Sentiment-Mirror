from collections import Counter

import numpy as np

from services.clustering_service import readable_label, run_kmeans_clustering
from utils.text_utils import safe_percentage, top_terms


def fallback_topics(texts: list[str], embeddings: np.ndarray | None = None) -> list[dict]:
    clusters = run_kmeans_clustering(texts, embeddings if embeddings is not None else np.empty((0, 0)))
    return [
        {
            "topicId": cluster["clusterId"],
            "name": cluster["label"] or "综合讨论",
            "size": cluster["size"],
            "percentage": cluster["percentage"],
            "keywords": cluster["topTerms"],
            "representativeTexts": cluster["representativeTexts"],
        }
        for cluster in clusters
    ]


def run_bertopic(texts: list[str], embeddings: np.ndarray) -> list[dict]:
    if not texts:
        return []
    if len(texts) < 20 or embeddings.size == 0:
        return fallback_topics(texts, embeddings)

    try:
        from bertopic import BERTopic  # type: ignore
        from sklearn.feature_extraction.text import CountVectorizer

        try:
            import jieba  # type: ignore

            vectorizer = CountVectorizer(tokenizer=jieba.lcut, token_pattern=None)
        except Exception:
            vectorizer = CountVectorizer(token_pattern=r"(?u)\b\w+\b")

        model = BERTopic(
            vectorizer_model=vectorizer,
            calculate_probabilities=False,
            verbose=False,
            min_topic_size=max(5, min(30, len(texts) // 20)),
        )
        topic_ids, _ = model.fit_transform(texts, embeddings)
        counts = Counter(topic_ids)
        results = []
        for topic_id, size in counts.most_common():
            topic_texts = [texts[index] for index, label in enumerate(topic_ids) if label == topic_id]
            if topic_id == -1:
                keywords = top_terms(topic_texts, 8)
                name = "其他讨论"
            else:
                topic_words = model.get_topic(topic_id) or []
                keywords = [str(word) for word, _ in topic_words[:8]]
                name = readable_label(keywords, f"主题 {topic_id}")
            results.append({
                "topicId": int(topic_id),
                "name": name,
                "size": int(size),
                "percentage": safe_percentage(int(size), len(texts)),
                "keywords": keywords,
                "representativeTexts": topic_texts[:5],
            })
        if len(results) <= 1 and len(texts) >= 100:
            return fallback_topics(texts, embeddings)
        return results
    except Exception:
        return fallback_topics(texts, embeddings)
