import os
from functools import lru_cache

import numpy as np


DEFAULT_SBERT_MODEL = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"


@lru_cache(maxsize=1)
def get_embedding_model():
    model_name = os.getenv("SBERT_MODEL", DEFAULT_SBERT_MODEL)
    try:
        from sentence_transformers import SentenceTransformer  # type: ignore

        return SentenceTransformer(model_name)
    except Exception:
        return None


def encode_texts(texts: list[str]) -> tuple[np.ndarray, str]:
    model = get_embedding_model()
    if model is None or not texts:
        return np.empty((0, 0), dtype=float), "fallback"

    try:
        embeddings = model.encode(
            texts,
            batch_size=int(os.getenv("SBERT_BATCH_SIZE", "32")),
            normalize_embeddings=True,
            show_progress_bar=False,
        )
        return np.asarray(embeddings, dtype=float), "sbert"
    except Exception:
        return np.empty((0, 0), dtype=float), "fallback"
