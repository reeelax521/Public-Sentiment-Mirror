from dataclasses import dataclass

from utils.text_utils import normalize_text


@dataclass
class CleaningResult:
    texts: list[str]
    total_texts: int
    valid_texts: int
    removed_duplicates: int
    removed_empty: int
    kept_indices: list[int]


def clean_texts(texts: list[str]) -> CleaningResult:
    seen: set[str] = set()
    cleaned: list[str] = []
    kept_indices: list[int] = []
    removed_empty = 0
    removed_duplicates = 0

    for index, text in enumerate(texts):
        normalized = normalize_text(text)
        if not normalized:
            removed_empty += 1
            continue
        if normalized in seen:
            removed_duplicates += 1
            continue
        seen.add(normalized)
        cleaned.append(normalized)
        kept_indices.append(index)

    return CleaningResult(
        texts=cleaned,
        total_texts=len(texts),
        valid_texts=len(cleaned),
        removed_duplicates=removed_duplicates,
        removed_empty=removed_empty,
        kept_indices=kept_indices,
    )
