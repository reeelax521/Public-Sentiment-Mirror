import os
import re
from collections import defaultdict
from functools import lru_cache


POSITIVE_WORDS = {
    "支持", "认可", "满意", "理解", "期待", "希望", "赞同", "喜欢", "推荐", "精彩", "好看", "优秀",
    "很棒", "真好", "挺好", "不错", "厉害", "太棒", "牛", "点赞", "赞", "祝贺", "恭喜", "开心",
    "漂亮", "超级漂亮", "精致", "想买", "值得买", "抢手", "热门", "爆款",
    "种草", "惊艳", "有创意", "有质感", "审美在线", "设计感", "文化底蕴", "国潮",
    "高兴", "快乐", "好消息", "成功", "胜利", "骄傲", "自豪", "感动", "文化自信", "传统文化",
    "传承", "遗产", "申遗成功", "春节申遗", "春节", "非遗", "文化遗产", "珍贵", "珍惜", "认同",
    "鼓励", "欢迎", "壮观", "有排面", "泪目", "感谢", "正能量", "合作共赢", "共赢", "和平发展",
    "友好", "真诚", "诚意", "求同存异", "携手共进", "NB", "nb",
    "震撼", "太帅", "好帅", "帅炸", "燃", "热血", "绝了", "炸裂", "牛逼", "有生命力",
    "看哭", "开眼", "起鸡皮疙瘩", "有功夫", "气势", "整齐", "阳刚", "英姿", "传承下去",
    "驱祸避恶", "招福献瑞", "万世永昌", "断孽破邪",
    "华夏", "活过来", "青山", "妩媚", "山水", "舞美", "配色", "国风", "绝美", "封神",
    "高级", "文艺复兴", "只此青绿", "千里江山", "备受震惊",
}

NEGATIVE_WORDS = {
    "失望", "质疑", "担心", "愤怒", "离谱", "敷衍", "糟糕", "不满", "欺骗", "风险", "混乱",
    "拖延", "隐瞒", "不信任", "反对", "无聊", "尴尬", "疲劳", "退票", "没回应", "博弈", "波动",
    "笑话", "恶心", "丢人", "造假", "抄袭", "争议", "无语", "太贵", "刺耳", "不合理", "杂乱",
    "严重", "没有美感", "过度商业化", "割韭菜", "同质化", "伪国潮", "质量差", "侵权", "翻译争议",
    "误读", "担忧", "黑", "骂",
    "坏处", "抢掉", "抢名额", "预约名额", "预约不上", "约不上", "难约", "抢门票", "名额被抢",
    "黄牛", "倒卖", "代购", "加价", "被挤占", "挤占", "正常想逛",
    "不需要", "不划算", "不值得", "溢价", "下不去手", "消费不起", "价格劝退", "劝退",
}


@lru_cache(maxsize=1)
def get_sentiment_pipeline():
    model_name = os.getenv("BERT_SENTIMENT_MODEL", "uer/roberta-base-finetuned-jd-binary-chinese")
    try:
        from transformers import pipeline  # type: ignore

        return pipeline("text-classification", model=model_name, tokenizer=model_name, truncation=True)
    except Exception:
        return None


@lru_cache(maxsize=1)
def snownlp_available() -> bool:
    try:
        from snownlp import SnowNLP  # type: ignore  # noqa: F401

        return True
    except Exception:
        return False


def _count_hits(text: str, words: set[str]) -> int:
    return sum(1 for word in words if word in text)


def _phrase_boost(text: str) -> tuple[int, int]:
    positive = 0
    negative = 0
    if re.search(r"申遗.*成功|成功.*申遗|春节.*成功|好消息|太棒了|我们的|属于我们|文化自信|传统文化.*传承", text):
        positive += 2
    if re.search(r"祝贺|恭喜|骄傲|自豪|厉害|点赞|支持|期待|终于", text):
        positive += 1
    if re.search(r"震撼|太帅|好帅|帅炸|燃|热血|绝了|炸裂|牛逼|有生命力|看哭|开眼|起鸡皮疙瘩|有功夫|气势.*足|鼓点.*(强|震撼|带劲)|整齐|阳刚|英姿|传承下去", text):
        positive += 2
    if re.search(r"(上春晚|全国看到|让更多人看到|走出去|出圈|火起来|发扬光大|继续传承)", text):
        positive += 2
    if re.search(r"(但是|但|不过|然而|可是|却|只是).*(英歌|英歌舞|传统文化|非遗).*(能|一定|想|值得|应该|必须|可以).*(爬起来|看|看到|支持|传承|出圈|火|上春晚)", text):
        positive += 3
    if re.search(r"华夏.*活过来|活过来.*华夏|青山.*妩媚|料青山.*如是|文化自信|文艺复兴|只此青绿|千里江山|国风.*(美|绝|高级)|舞美.*(好|美|绝)|配色.*(好|美|舒服)|审美.*(好|高级|绝)", text):
        positive += 3
    if re.search(r"(超级)?漂亮|好看|精致|想买|值得买|抢手|爆款|太热门", text):
        positive += 2
    if re.search(r"(漂亮|好看|精致|想买|值得买).*(抢|没抢上|抢不到|一个多月)", text) and not re.search(r"预约名额|名额被抢|抢掉|黄牛|倒卖|加价|正常想逛", text):
        positive += 3
    if re.search(r"不是我们的|被偷|抢走|文化被偷|翻译.*争议|韩国.*农历|担心.*误读", text):
        negative += 1
    if re.search(r"太贵|价格.*高|价格.*贵|价格.*不需要|价格.*劝退|没舍得买|买不起|不需要|不划算|不值得|不值|下不去手|割韭菜|抄袭|质量差|过度商业化|不配|丢人|恶心|无语", text):
        negative += 2
    if re.search(r"(价格|售价|定价|卖|要)\s*[0-9０-９]{1,5}\s*(元|块|￥)?", text) and re.search(r"不需要|劝退|不值|不划算|下不去手|买不起|瞬间|算了|放弃", text):
        negative += 3
    if re.search(r"坏处|预约名额.*抢|抢.*预约名额|名额.*被.*抢|门票.*(抢|约不上|难约)|正常想逛.*抢|抢掉|黄牛|倒卖|代购|加价", text):
        negative += 4
    return positive, negative


def _strong_negative_context(text: str) -> bool:
    return bool(re.search(r"坏处|预约名额.*抢|抢.*预约名额|名额.*被.*抢|门票.*(抢|约不上|难约)|正常想逛.*抢|抢掉|黄牛|倒卖|代购|加价", text))


def _consumer_negative_context(text: str) -> bool:
    return bool(re.search(r"(价格|售价|定价|卖|要)\s*[0-9０-９]{1,5}\s*(元|块|￥)?", text)) and bool(re.search(r"不需要|劝退|不值|不划算|下不去手|买不起|瞬间|算了|放弃", text))


def _positive_purchase_context(text: str) -> bool:
    return bool(re.search(r"(漂亮|好看|精致|想买|值得买).*(抢|没抢上|抢不到|一个多月)", text)) and not _strong_negative_context(text)


def _contrast_neutral_context(text: str) -> bool:
    return bool(re.search(r"(没看过|没看懂|看不懂|不熟|不了解).{0,24}(但是|但|不过|然而|可是|却|只是).{0,32}(震惊|备受震惊|记住|印象|有点意思|还行)", text))


def _literary_quote_neutral_context(text: str) -> bool:
    compact = re.sub(r"[\s，,。！？!?.；;：:、]+", "", str(text or ""))
    return compact in {"小山重叠金明灭"}


def _cultural_performance_positive_context(text: str) -> bool:
    return bool(re.search(r"华夏.*活过来|活过来.*华夏|青山.*妩媚|料青山.*如是|文化自信|文艺复兴|只此青绿|千里江山|国风.*(美|绝|高级)|舞美.*(好|美|绝)|配色.*(好|美|舒服)|审美.*(好|高级|绝)", text))


def _split_clauses(text: str) -> list[str]:
    marked = re.sub(r"(但是|但|不过|然而|可是|却|只是)", r"，\1", str(text or ""))
    return [item.strip() for item in re.split(r"[，,。；;！!？?\n\r]+", marked) if item.strip()]


def _is_contrast_clause(clause: str) -> bool:
    return bool(re.match(r"^(但是|但|不过|然而|可是|却|只是)", clause))


def _score_words(text: str) -> tuple[float, float]:
    return float(_count_hits(text, POSITIVE_WORDS)), float(_count_hits(text, NEGATIVE_WORDS))


def _score_text_evidence(text: str) -> tuple[float, float]:
    clauses = _split_clauses(text)
    if not clauses:
        pos_words, neg_words = _score_words(text)
        pos_boost, neg_boost = _phrase_boost(text)
        return pos_words + pos_boost, neg_words + neg_boost

    positive = 0.0
    negative = 0.0
    contrast_negative = False
    repeated_positive = 0
    repeated_negative = 0

    for index, clause in enumerate(clauses):
        pos_words, neg_words = _score_words(clause)
        pos_boost, neg_boost = _phrase_boost(clause)
        clause_positive = pos_words + pos_boost
        clause_negative = neg_words + neg_boost
        weight = (1 + min(index, 3) * 0.08) * (1.85 if _is_contrast_clause(clause) else 1)
        positive += clause_positive * weight
        negative += clause_negative * weight
        if clause_positive >= 1:
            repeated_positive += 1
        if clause_negative >= 1:
            repeated_negative += 1
        if _is_contrast_clause(clause) and clause_negative >= clause_positive:
            contrast_negative = True

    whole_positive, whole_negative = _phrase_boost(text)
    positive += whole_positive * 0.35
    negative += whole_negative * 0.45
    if contrast_negative:
        negative += 1.6
    if repeated_negative >= 2:
        negative += 1.4
    if repeated_positive >= 2:
        positive += 1.1
    if _consumer_negative_context(text):
        negative += 2.8
    return positive, negative


def _lexicon_signal(text: str) -> dict:
    positive, negative = _score_text_evidence(text)
    total = max(positive + negative, 1)
    if positive > negative:
        return {"label": "positive", "strength": min(1.0, (positive - negative) / total), "positive": positive, "negative": negative}
    if negative > positive:
        return {"label": "negative", "strength": min(1.0, (negative - positive) / total), "positive": positive, "negative": negative}
    return {"label": "neutral", "strength": 0.0, "positive": positive, "negative": negative}


def _is_low_information(text: str) -> bool:
    compact = re.sub(r"\s+", "", str(text or ""))
    if not compact:
        return True
    if re.fullmatch(r"(\[?(doge|call|允悲|笑cry|哈哈|哈哈哈|嘻嘻|666|good|ok|回复|转发)\]?)+", compact, flags=re.I):
        return True
    if len(compact) <= 2:
        return True
    return False


def _looks_like_question_or_fact(text: str) -> bool:
    compact = str(text or "").strip()
    if not compact:
        return True
    if re.search(r"[?？]$", compact):
        return True
    if re.search(r"^(现在|这个是|这是|不是|其实|如果|有没有|为什么|怎么|哪里|谁|冷知识|地图|资料|出处)", compact):
        return True
    return False


def _rule_sentiment(text: str) -> dict:
    if _is_low_information(text):
        return {"text": text, "label": "neutral", "score": 0.55}
    signal = _lexicon_signal(text)
    if signal["label"] == "positive":
        return {"text": text, "label": "positive", "score": round(0.58 + signal["strength"] * 0.36, 4)}
    if signal["label"] == "negative":
        return {"text": text, "label": "negative", "score": round(0.58 + signal["strength"] * 0.36, 4)}
    return {"text": text, "label": "neutral", "score": 0.55}


def _calibrate_item(item: dict) -> dict:
    text = str(item.get("text", ""))
    if _is_low_information(text):
        return {**item, "label": "neutral", "score": 0.55}

    signal = _lexicon_signal(text)
    label = str(item.get("label", "neutral"))
    score = float(item.get("score", 0.55))

    if _strong_negative_context(text):
        return {**item, "label": "negative", "score": round(max(0.86, min(score, 0.94)), 4)}

    if _consumer_negative_context(text):
        return {**item, "label": "negative", "score": round(max(0.82, min(score, 0.94)), 4)}

    if _contrast_neutral_context(text):
        return {**item, "label": "neutral", "score": round(max(0.72, min(score, 0.88)), 4)}

    if _literary_quote_neutral_context(text):
        return {**item, "label": "neutral", "score": 0.76}

    if _cultural_performance_positive_context(text):
        return {**item, "label": "positive", "score": round(max(0.86, score), 4)}

    if _positive_purchase_context(text):
        return {**item, "label": "positive", "score": round(max(0.82, score), 4)}

    if signal["label"] == "neutral":
        if label == "positive" and (_looks_like_question_or_fact(text) or score < 0.65):
            return {**item, "label": "neutral", "score": round(max(0.56, min(score, 0.72)), 4)}
        if label == "negative" and (_looks_like_question_or_fact(text) or score < 0.88):
            return {**item, "label": "neutral", "score": round(max(0.56, min(score, 0.72)), 4)}
        return item

    if label == "neutral" and signal["strength"] >= 0.25:
        return {**item, "label": signal["label"], "score": round(max(score, 0.68 + signal["strength"] * 0.2), 4)}

    if label != signal["label"] and signal["strength"] >= 0.65 and score < 0.9:
        return {**item, "label": signal["label"], "score": round(max(0.68, (score + 0.72 + signal["strength"] * 0.18) / 2), 4)}

    if label == "negative" and signal["positive"] > 0 and signal["negative"] == 0 and score < 0.94:
        return {**item, "label": "positive", "score": round(max(0.68, 0.65 + signal["strength"] * 0.25), 4)}

    return item


def _normalize_label(label: str, score: float) -> str:
    value = label.lower()
    if score < 0.58:
        return "neutral"
    if "positive" in value or "pos" in value or value.endswith("_1") or value in {"1", "label_1"}:
        return "positive"
    if "negative" in value or "neg" in value or value.endswith("_0") or value in {"0", "label_0"}:
        return "negative"
    return "neutral"


def _snownlp_sentiment(text: str) -> dict:
    from snownlp import SnowNLP  # type: ignore

    positive_threshold = float(os.getenv("SNOWNLP_POSITIVE_THRESHOLD", "0.60"))
    negative_threshold = float(os.getenv("SNOWNLP_NEGATIVE_THRESHOLD", "0.36"))
    probability = float(SnowNLP(text[:512]).sentiments)

    if probability >= positive_threshold:
        return {"text": text, "label": "positive", "score": round(probability, 4)}
    if probability <= negative_threshold:
        return {"text": text, "label": "negative", "score": round(1 - probability, 4)}

    neutral_score = 1 - min(abs(probability - 0.5) * 2, 1)
    return {"text": text, "label": "neutral", "score": round(max(neutral_score, 0.5), 4)}


def _analyze_with_snownlp(texts: list[str]) -> list[dict]:
    return [_snownlp_sentiment(text) for text in texts]


def _analyze_with_bert(texts: list[str], batch_size: int) -> list[dict]:
    classifier = get_sentiment_pipeline()
    if classifier is None:
        raise RuntimeError("BERT sentiment pipeline is unavailable")

    items = []
    for start in range(0, len(texts), batch_size):
        batch = texts[start:start + batch_size]
        predictions = classifier([text[:512] for text in batch])
        for text, prediction in zip(batch, predictions):
            score = float(prediction.get("score", 0.0))
            label = _normalize_label(str(prediction.get("label", "")), score)
            items.append({"text": text, "label": label, "score": round(score, 4)})
    return items


def analyze_sentiment(texts: list[str], batch_size: int = 32) -> dict:
    if not texts:
        return {
            "distribution": {"positive": 0, "neutral": 0, "negative": 0},
            "negativeRate": 0,
            "items": [],
            "typicalComments": {"positive": [], "neutral": [], "negative": []},
            "mode": "fallback",
        }

    engine = os.getenv("SENTIMENT_ENGINE", "bert").strip().lower()
    mode = "fallback"

    try:
        if engine == "bert":
            items = _analyze_with_bert(texts, batch_size)
            mode = "bert"
        elif engine == "snownlp":
            items = _analyze_with_snownlp(texts)
            mode = "snownlp"
        else:
            items = [_rule_sentiment(text) for text in texts]
            mode = "fallback"
    except Exception:
        if engine != "snownlp" and snownlp_available():
            try:
                items = _analyze_with_snownlp(texts)
                mode = "snownlp"
            except Exception:
                items = [_rule_sentiment(text) for text in texts]
                mode = "fallback"
        else:
            items = [_rule_sentiment(text) for text in texts]
            mode = "fallback"

    items = [_calibrate_item(item) for item in items]

    counts = defaultdict(int)
    typical: dict[str, list[str]] = {"positive": [], "neutral": [], "negative": []}
    for item in items:
        label = item["label"]
        counts[label] += 1
        if len(typical[label]) < 5:
            typical[label].append(item["text"])

    total = max(len(items), 1)
    distribution = {
        "positive": round(counts["positive"] / total * 100, 2),
        "neutral": round(counts["neutral"] / total * 100, 2),
        "negative": round(counts["negative"] / total * 100, 2),
    }

    max_items = int(os.getenv("SENTIMENT_RETURN_ITEMS_MAX", "20000"))

    return {
        "distribution": distribution,
        "negativeRate": distribution["negative"],
        "items": items[:max_items],
        "typicalComments": typical,
        "mode": mode,
    }


def warmup_sentiment_model() -> dict:
    engine = os.getenv("SENTIMENT_ENGINE", "bert").strip().lower()
    if engine == "bert":
        classifier = get_sentiment_pipeline()
        if classifier is None and snownlp_available():
            return {
                "ok": True,
                "mode": "snownlp",
                "engine": "bert",
                "fallbackEngine": "snownlp",
                "reason": "BERT sentiment pipeline is unavailable; SnowNLP model fallback is ready.",
            }
        return {
            "ok": classifier is not None,
            "mode": "bert" if classifier is not None else "unavailable",
            "engine": "bert",
        }
    if engine == "snownlp":
        ready = snownlp_available()
        return {
            "ok": ready,
            "mode": "snownlp" if ready else "unavailable",
            "engine": "snownlp",
        }
    return {
        "ok": True,
        "mode": "fallback",
        "engine": engine or "fallback",
    }
