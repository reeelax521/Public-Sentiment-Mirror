import os

from fastapi import FastAPI

from schemas.request_schema import AnalyzeRequest, TextOnlyRequest
from schemas.response_schema import AnalyzeResponse
from services.analysis_pipeline import analyze_payload
from services.cleaning_service import clean_texts
from services.clustering_service import run_kmeans_clustering
from services.embedding_service import encode_texts
from services.sentiment_service import analyze_sentiment
from services.sentiment_service import snownlp_available
from services.sentiment_service import warmup_sentiment_model
from services.topic_service import run_bertopic

app = FastAPI(title="Public Sentiment Mirror NLP Service", version="0.1.0")


@app.get("/health")
def health():
    return {
        "ok": True,
        "service": "nlp_service",
        "sentimentEngine": os.getenv("SENTIMENT_ENGINE", "bert"),
        "snownlpAvailable": snownlp_available(),
    }


@app.get("/warmup")
def warmup():
    sentiment = warmup_sentiment_model()
    return {
        "ok": bool(sentiment.get("ok")),
        "service": "nlp_service",
        "sentiment": sentiment,
    }


@app.post("/analyze", response_model=AnalyzeResponse)
def analyze(request: AnalyzeRequest):
    return analyze_payload(request)


@app.post("/sentiment")
def sentiment(request: TextOnlyRequest):
    cleaned = clean_texts(request.texts)
    return analyze_sentiment(cleaned.texts)


@app.post("/clusters")
def clusters(request: TextOnlyRequest):
    cleaned = clean_texts(request.texts)
    embeddings, mode = encode_texts(cleaned.texts)
    return {
        "taskId": request.taskId,
        "mode": mode,
        "clusters": run_kmeans_clustering(cleaned.texts, embeddings),
    }


@app.post("/topics")
def topics(request: TextOnlyRequest):
    cleaned = clean_texts(request.texts)
    embeddings, mode = encode_texts(cleaned.texts)
    return {
        "taskId": request.taskId,
        "mode": mode,
        "topics": run_bertopic(cleaned.texts, embeddings),
    }
