import re
from collections import Counter


URL_PATTERN = re.compile(r"https?://\S+|www\.\S+")
SPACE_PATTERN = re.compile(r"\s+")
BRACKET_TOKEN_PATTERN = re.compile(r"\[([^\[\]]{1,24})\]")
LATIN_WORD_PATTERN = re.compile(r"[a-zA-Z][a-zA-Z0-9]*")

STOPWORDS = {
    "的", "了", "和", "是", "在", "就", "都", "而", "及", "与", "或", "一个", "没有", "我们", "你们", "他们",
    "这个", "那个", "这些", "那些", "什么", "因为", "所以", "如果", "但是", "不过", "然后", "就是", "还是",
    "可以", "应该", "比较", "非常", "真的", "感觉", "觉得", "知道", "可能", "现在", "最后", "其实", "完全",
    "需要", "那么", "怎么", "不是", "不能", "不会", "以后", "出来", "起来", "下来", "里面", "这里", "那里", "对于",
    "关于", "通过", "更多", "很多", "主要", "下面", "有人", "大家", "内容", "观点", "用户", "网友", "平台",
    "媒体", "来源", "正文", "标题", "评论", "回复", "视频", "弹幕", "官方", "b站", "微博", "新浪", "新闻",
    "打开太阳", "bgm", "发来", "贺电", "这是", "super", "up", "bip",
}

ENGLISH_STOPWORDS = {
    "the", "and", "for", "with", "from", "this", "that", "these", "those", "you", "your", "are", "was", "were",
    "have", "has", "had", "will", "would", "could", "should", "not", "but", "all", "any", "can", "our", "their",
    "about", "into", "over", "under", "after", "before", "very", "more", "less", "just", "also", "then", "than",
    "new", "year", "happy", "official", "save", "world", "remote", "control", "everything", "want", "wants",
    "bgm", "music", "video", "bilibili", "sakura", "ouo", "lunar",
}

BLOCKED_LATIN_TOKENS = {"doge", "call", "haha", "hhh", "xswl", "awsl", "lol", "official", "bgm", "bilibili", "sakura", "ouo", "super", "up", "bip", "qbdswnrhhh", "qbdswnrhhh1", "xixi0311", "movae0218"}
NEUTRAL_EMOJI_TOKENS = {"doge", "call", "打call", "允悲", "笑cry", "二哈", "摊手", "吃瓜", "裂开", "苦涩", "泪", "泪目", "哈哈", "哈哈哈"}

DOMAIN_PHRASES = [
    "春节申遗", "申遗成功", "春节", "农历新年", "中国新年", "传统文化", "文化遗产", "世界遗产", "非物质文化遗产",
    "非遗", "申遗", "传承", "文化自信", "联合国教科文组织", "中轴线", "北京中轴线", "英歌舞", "潮汕",
    "民俗", "民间艺术", "表演", "舞蹈", "鼓点", "春晚", "保护", "文化认同", "翻译争议",
    "剧情", "角色", "特效", "反派", "英雄", "观影体验", "口碑", "钢铁侠", "美国队长", "复仇者联盟",
    "国事访问", "访华", "外交", "中美关系", "经贸合作", "合作共赢", "和平发展", "会晤", "谈判",
    "国家博物馆", "国博", "凤冠冰箱贴", "冰箱贴", "文创产品", "文创", "凤冠", "爆款", "热卖",
    "购买体验", "预约名额", "参观体验", "黄牛", "倒卖", "加价",
]

ENGLISH_PHRASE_WHITELIST = {
    "chinese new year": "Chinese New Year",
    "happy chinese new year": "Happy Chinese New Year",
    "spring festival": "Spring Festival",
    "world heritage": "World Heritage",
    "unesco": "UNESCO",
    "lunar new year": "Lunar New Year",
}


def _compact_token(value: str) -> str:
    return re.sub(r"[\s_~-]+", "", str(value or "")).strip().lower()


def normalize_text(text: str) -> str:
    text = URL_PATTERN.sub(" ", str(text or ""))
    text = BRACKET_TOKEN_PATTERN.sub(lambda match: " " if _compact_token(match.group(1)) in NEUTRAL_EMOJI_TOKENS else " ", text)
    text = re.sub(r"(^|[\s,，。?!？！:：])doge(?=$|[\s,，。?!？！:：])", " ", text, flags=re.I)
    text = re.sub(r"(^|[\s,，。?!？！:：])(?:打\s*)?call(?=$|[\s,，。?!？！:：])", " ", text, flags=re.I)
    return SPACE_PATTERN.sub(" ", text).strip()


def safe_percentage(count: int, total: int) -> float:
    if total <= 0:
        return 0.0
    return round(count / total * 100, 2)


def _valid_chinese_token(token: str) -> bool:
    if token in STOPWORDS:
        return False
    if len(token) < 2 or len(token) > 8:
        return token in DOMAIN_PHRASES
    if len(token) > 6 and token not in DOMAIN_PHRASES:
        return False
    if len(token) >= 5 and re.search(r"[的和与于在之]", token) and token not in DOMAIN_PHRASES:
        return False
    if re.search(r"(.)\1{2,}", token):
        return False
    if len(token) == 2 and token[0] == token[1]:
        return False
    if token in {"回复", "评论", "视频", "弹幕", "平台", "用户", "网友", "官方"}:
        return False
    return True


def _valid_latin_token(token: str) -> bool:
    lower = token.lower()
    if lower in ENGLISH_STOPWORDS or lower in BLOCKED_LATIN_TOKENS:
        return False
    return len(lower) >= 3 and not lower.isdigit()


def _segment_chinese(text: str) -> list[str]:
    try:
        import jieba  # type: ignore

        return [item.strip() for item in jieba.lcut(text) if item.strip()]
    except Exception:
        return re.findall(r"[\u4e00-\u9fa5]{2,8}", text)


def english_phrase_counts(texts: list[str], limit: int = 12) -> list[tuple[str, str, int]]:
    counter: Counter[str] = Counter()
    for text in texts:
        lower_text = normalize_text(text).lower()
        for phrase in ENGLISH_PHRASE_WHITELIST:
            count = lower_text.count(phrase)
            if count:
                counter[phrase] += count

        words = [word.lower() for word in LATIN_WORD_PATTERN.findall(lower_text) if _valid_latin_token(word)]
        for size in range(4, 1, -1):
            for index in range(0, max(len(words) - size + 1, 0)):
                phrase_words = words[index:index + size]
                phrase = " ".join(phrase_words)
                if len(phrase) >= 7 and not any(word in ENGLISH_STOPWORDS for word in phrase_words):
                    counter[phrase] += 1

    selected: list[tuple[str, str, int]] = []
    for phrase, count in sorted(counter.items(), key=lambda item: (-item[1], -len(item[0].split()), item[0])):
        if count < 2 and phrase not in ENGLISH_PHRASE_WHITELIST:
            continue
        if any(existing == phrase or existing in phrase or phrase in existing for existing, _, _ in selected):
            continue
        display = ENGLISH_PHRASE_WHITELIST.get(phrase, " ".join(part.capitalize() for part in phrase.split()))
        selected.append((phrase, display, int(count)))
        if len(selected) >= limit:
            break
    return selected


def tokenize(text: str, suppressed_terms: set[str] | None = None) -> list[str]:
    text = normalize_text(text)
    suppressed_terms = suppressed_terms or set()
    tokens: list[str] = []

    for phrase in DOMAIN_PHRASES:
        count = text.count(phrase)
        if count:
            tokens.extend([phrase] * count)

    for token in _segment_chinese(text):
        if token in suppressed_terms:
            continue
        if re.fullmatch(r"[\u4e00-\u9fa5]+", token) and _valid_chinese_token(token):
            tokens.append(token)

    for token in LATIN_WORD_PATTERN.findall(text):
        lower = token.lower()
        if lower in suppressed_terms:
            continue
        if _valid_latin_token(lower):
            tokens.append(lower)

    return tokens


def _minimum_count(total_texts: int) -> int:
    if total_texts >= 1000:
        return max(12, round(total_texts * 0.006))
    if total_texts >= 100:
        return 2
    return 1


def _is_useful_ranked_word(word: str) -> bool:
    lower = word.lower()
    if " " in lower:
        return lower in ENGLISH_PHRASE_WHITELIST or not any(part in ENGLISH_STOPWORDS or part in BLOCKED_LATIN_TOKENS for part in lower.split())
    if re.fullmatch(r"[\u4e00-\u9fa5]+", word):
        return _valid_chinese_token(word)
    if re.fullmatch(r"[a-z0-9]+", lower):
        return _valid_latin_token(lower)
    return False


def ranked_terms(counter: Counter[str], limit: int, total_texts: int = 0) -> list[tuple[str, int]]:
    ranked = sorted(counter.items(), key=lambda item: (-item[1], -len(item[0]), item[0]))
    selected: list[tuple[str, int]] = []
    min_count = _minimum_count(total_texts)
    for word, count in ranked:
        if count < min_count or not _is_useful_ranked_word(word):
            continue
        if any(existing != word and word in existing and existing_count >= count * 0.75 for existing, existing_count in selected):
            continue
        if len(word) <= 2 and any(len(existing) > len(word) and word in existing and existing_count >= count for existing, existing_count in selected):
            continue
        selected.append((word, count))
        if len(selected) >= limit:
            break
    return selected


def top_terms(texts: list[str], limit: int = 8) -> list[str]:
    counter: Counter[str] = Counter()
    phrases = english_phrase_counts(texts, min(limit, 12))
    suppressed = {part for phrase, _, _ in phrases for part in phrase.split()}
    for text in texts:
        counter.update(tokenize(text, suppressed))
    for _, display, count in phrases:
        counter[display] = max(counter[display], count)
    return [word for word, _ in ranked_terms(counter, limit, len(texts))]


def keyword_counts(texts: list[str], limit: int = 30) -> list[dict[str, int]]:
    counter: Counter[str] = Counter()
    phrases = english_phrase_counts(texts, min(limit, 12))
    suppressed = {part for phrase, _, _ in phrases for part in phrase.split()}
    for text in texts:
        counter.update(tokenize(text, suppressed))
    for _, display, count in phrases:
        counter[display] = max(counter[display], count)
    return [{"word": word, "count": int(count)} for word, count in ranked_terms(counter, limit, len(texts))]
