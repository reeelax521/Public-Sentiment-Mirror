from typing import Any, Optional

from pydantic import BaseModel, Field


class MetadataItem(BaseModel):
    platform: Optional[str] = None
    createdAt: Optional[str] = None
    likeCount: int = 0
    repostCount: int = 0
    commentCount: int = 0
    objectName: Optional[str] = None
    rating: Optional[float] = None
    extra: dict[str, Any] = Field(default_factory=dict)


class AnalyzeRequest(BaseModel):
    taskId: str = "task_local"
    texts: list[str] = Field(default_factory=list)
    metadata: list[MetadataItem] = Field(default_factory=list)


class TextOnlyRequest(BaseModel):
    taskId: str = "task_local"
    texts: list[str] = Field(default_factory=list)
    metadata: list[MetadataItem] = Field(default_factory=list)
