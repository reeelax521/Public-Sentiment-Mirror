from typing import Literal

from pydantic import BaseModel, Field


SentimentLabel = Literal["positive", "neutral", "negative"]
RiskLevel = Literal["low", "medium", "high", "critical"]


class Overview(BaseModel):
    totalTexts: int
    validTexts: int
    removedDuplicates: int
    removedEmpty: int


class KeywordItem(BaseModel):
    word: str
    count: int


class SentimentItem(BaseModel):
    text: str
    label: SentimentLabel
    score: float


class SentimentResult(BaseModel):
    distribution: dict[SentimentLabel, float]
    negativeRate: float
    items: list[SentimentItem] = Field(default_factory=list)
    typicalComments: dict[SentimentLabel, list[str]] = Field(default_factory=lambda: {
        "positive": [],
        "neutral": [],
        "negative": [],
    })
    mode: str = "fallback"


class ClusterItem(BaseModel):
    clusterId: int
    label: str
    size: int
    percentage: float
    topTerms: list[str] = Field(default_factory=list)
    representativeTexts: list[str] = Field(default_factory=list)
    coordinates: list[dict[str, float | int | str]] = Field(default_factory=list)


class TopicItem(BaseModel):
    topicId: int
    name: str
    size: int
    percentage: float
    keywords: list[str] = Field(default_factory=list)
    representativeTexts: list[str] = Field(default_factory=list)


class TrendPoint(BaseModel):
    date: str
    heat: float
    count: int
    negativeRate: float


class RiskResult(BaseModel):
    riskLevel: RiskLevel
    riskScore: float
    reason: str


class AnalyzeResponse(BaseModel):
    taskId: str
    overview: Overview
    keywords: list[KeywordItem] = Field(default_factory=list)
    sentiment: SentimentResult
    clusters: list[ClusterItem] = Field(default_factory=list)
    topics: list[TopicItem] = Field(default_factory=list)
    trend: list[TrendPoint] = Field(default_factory=list)
    risk: RiskResult
    mode: str = "fallback"
    warnings: list[str] = Field(default_factory=list)
