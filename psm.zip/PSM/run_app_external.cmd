@echo off
cd /d E:\undergraduate\Web\PSM\web
echo Starting Public Sentiment Mirror for LAN access...
echo.
echo This mode listens on 0.0.0.0:3000.
echo Other devices on the same network can visit:
echo   http://YOUR_COMPUTER_IP:3000
echo.
npm run dev -- -H 0.0.0.0 -p 3000
echo.
echo Next.js dev server has stopped. Press any key to close this window.
pause > nul
